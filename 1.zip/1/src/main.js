/**
 * ============================================================================
 * src/main.js
 * ============================================================================
 *
 * PROPÓSITO
 *   Punto de entrada de la aplicación Huanta Segura. Inicializa el sistema,
 *   inyecta las secciones en el DOM, registra los módulos y arranca la app.
 *
 * RESPONSABILIDADES
 *   - Importar los estilos globales.
 *   - Inicializar el DataStore con los datos semilla.
 *   - Restaurar preferencias del usuario (tema, densidad, sidebar).
 *   - Inyectar el HTML de cada sección en el contenedor principal.
 *   - Inicializar los módulos de UI (toast, modal, sidebar, router).
 *   - Registrar las secciones y arrancar la navegación.
 *
 * DEPENDENCIAS
 *   - styles/main.css         → variables, reset, layout, tipografía.
 *   - styles/components.css   → botones, panel, tabla, badge, modal, toast.
 *   - styles/sections.css     → estilos específicos por sección.
 *   - core/datastore.js       → capa de datos.
 *   - core/router.js          → navegación entre secciones.
 *   - core/utils.js           → helpers generales.
 *   - core/session.js         → sesión y roles.
 *   - ui/toast.js             → notificaciones flotantes.
 *   - ui/modal.js             → modal genérico.
 *   - ui/sidebar.js           → comportamiento de la barra lateral.
 *   - data/seed.js            → datos de demostración.
 *   - sections/*.js           → las 12 secciones.
 *
 * USADO POR
 *   - index.html              → <script type="module" src="/src/main.js">
 *
 * EXPORTA
 *   - Nada. Es el punto de entrada; se ejecuta al cargar.
 *
 * EVENTOS
 *   - "section:change"        → notifica el cambio de sección.
 *   - "datastore:change"      → notifica cambios en los datos.
 */

import "@styles/main.css";
import "@styles/components.css";
import "@styles/sections.css";

import { $, $$ } from "@core/utils.js";
import { DataStore } from "@core/datastore.js";
import { Session } from "@core/session.js";
import { Router } from "@core/router.js";
import { Events } from "@core/events.js";

import { Toast } from "@ui/toast.js";
import { Modal } from "@ui/modal.js";
import { Sidebar } from "@ui/sidebar.js";

import { seedData } from "@data/seed.js";

import Inicio from "@sections/inicio.js";
import Registrar from "@sections/registrar.js";
import Registros from "@sections/registros.js";
import Estadisticas from "@sections/estadisticas.js";
import Mapa from "@sections/mapa.js";
import Informes from "@sections/informes.js";
import Comparativas from "@sections/comparativas.js";
import Importar from "@sections/importar.js";
import Papelera from "@sections/papelera.js";
import Historial from "@sections/historial.js";
import Administracion from "@sections/administracion.js";
import Cuenta from "@sections/cuenta.js";

const SECTIONS = [
    Inicio,
    Registrar,
    Registros,
    Estadisticas,
    Mapa,
    Informes,
    Comparativas,
    Importar,
    Papelera,
    Historial,
    Administracion,
    Cuenta,
];

const STORAGE_PREFS = {
    theme: "huanta-segura:theme",
    density: "huanta-segura:density",
    sidebar: "huanta-segura:sidebar",
};

function injectSections() {
    const main = $("#mainContent");
    if (!main) return;
    const html = SECTIONS
        .map((section) => section.template || "")
        .filter(Boolean)
        .join("\n");
    main.insertAdjacentHTML("afterbegin", html);
}

function restorePreferences() {
    const theme = localStorage.getItem(STORAGE_PREFS.theme) || "light";
    const density = localStorage.getItem(STORAGE_PREFS.density) || "comfortable";

    document.body.classList.remove("theme-dark");
    if (theme === "dark") {
        document.body.classList.add("theme-dark");
    } else if (theme === "system") {
        if (window.matchMedia("(prefers-color-scheme: dark)").matches) {
            document.body.classList.add("theme-dark");
        }
    }

    document.body.classList.toggle("density-compact", density === "compact");
}

function setCurrentDate() {
    const el = $("#currentDate");
    if (!el) return;
    const now = new Date();
    const formatted = now.toLocaleDateString("es-PE", {
        weekday: "long",
        day: "numeric",
        month: "long",
        year: "numeric",
    });
    const span = el.querySelector("span");
    if (span) {
        span.textContent = formatted.charAt(0).toUpperCase() + formatted.slice(1);
    }
}

function setFooterYear() {
    const el = $("#footerYear");
    if (el) el.textContent = `© ${new Date().getFullYear()}`;
}

function updateUserHeader() {
    const session = Session.get();
    const user = session.userId ? DataStore.users.get(session.userId) : null;
    const name = user?.name || "Administrador";
    const roleLabel = Session.roleLabel();
    const initials = name
        .split(/\s+/)
        .map((part) => part[0])
        .slice(0, 2)
        .join("")
        .toUpperCase();

    const avatarEl = $("#userAvatar");
    const nameEl = $("#userName");
    const roleEl = $("#userRole");

    if (avatarEl) avatarEl.textContent = initials;
    if (nameEl) nameEl.textContent = name;
    if (roleEl) roleEl.textContent = roleLabel;
}

function bootstrap() {
    /* 1. Datos */
    DataStore.init(seedData);

    /* 2. Preferencias visuales */
    restorePreferences();

    /* 3. Estructura HTML de secciones */
    injectSections();

    /* 4. UI base */
    Toast.init();
    Modal.init();
    Sidebar.init();

    /* 5. Cabecera */
    setCurrentDate();
    setFooterYear();
    updateUserHeader();

    /* 6. Secciones */
    SECTIONS.forEach((section) => {
        if (typeof section.init === "function") section.init();
    });

    /* 7. Router (después de que todas las secciones existan) */
    Router.init(SECTIONS);

    /* 8. Reacción a cambios globales */
    Events.on("datastore:change", () => {
        const current = Router.current();
        const section = SECTIONS.find((s) => s.id === current);
        if (section && typeof section.render === "function") section.render();
    });

    Events.on("session:change", () => {
        updateUserHeader();
    });

    /* 9. Redibujado al entrar a una sección */
    Events.on("section:change", ({ id }) => {
        const section = SECTIONS.find((s) => s.id === id);
        if (section && typeof section.render === "function") section.render();
    });

    /* 10. Herramientas de desarrollo en consola */
    window.HuantaSegura = {
        DataStore,
        Session,
        Router,
        Toast,
        Modal,
        Events,
        reset: () => {
            DataStore.reset(seedData);
            location.reload();
        },
        setRole: (role) => {
            Session.setRole(role);
            Toast.info("Rol cambiado", `Ahora trabajas como ${Session.roleLabel()}.`);
        },
    };

    console.info(
        "%cHuanta Segura",
        "background:#4f46e5;color:#fff;padding:4px 8px;border-radius:4px;font-weight:bold",
        "Aplicación lista. Usa `HuantaSegura.setRole('operario')` para probar otros roles."
    );
}

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", bootstrap);
} else {
    bootstrap();
}