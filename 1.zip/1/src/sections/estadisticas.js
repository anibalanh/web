/**
 * ============================================================================
 * src/sections/estadisticas.js
 * ============================================================================
 *
 * PROPÓSITO
 *   Sección "Estadísticas": análisis cuantitativo de las incidencias
 *   registradas. Ofrece indicadores del periodo, evolución temporal,
 *   distribución por categorías, distribución por zona y una tabla resumen
 *   con porcentajes.
 *
 * RESPONSABILIDADES
 *   - Aplicar filtros por rango de fechas, zona y tipo.
 *   - Calcular indicadores: total, tipo más frecuente y zona con más casos.
 *   - Dibujar gráfico de barras por mes (Chart.js).
 *   - Dibujar gráfico horizontal por tipo.
 *   - Dibujar gráfico horizontal por zona.
 *   - Renderizar tabla con cantidad y porcentaje por categoría.
 *   - Reaccionar a cambios en los datos y al entrar a la sección.
 *
 * DEPENDENCIAS
 *   - core/datastore.js    → incidencias, tipos, zonas.
 *   - core/events.js       → escucha "section:change" y "datastore:change".
 *   - core/utils.js        → helpers de fechas, agrupación, DOM.
 *   - ui/toast.js          → avisos al aplicar filtros.
 *
 * USADO POR
 *   - main.js              → registra la sección al arrancar.
 *
 * EXPORTA
 *   - default              → objeto de sección con id, label, template,
 *                            init() y render().
 *
 * EVENTOS
 *   - Escucha: "section:change"    → re-render al entrar a "estadisticas".
 *   - Escucha: "datastore:change"  → re-render al cambiar datos.
 */

import { DataStore } from "@core/datastore.js";
import { Events } from "@core/events.js";
import {
    $,
    escapeHTML,
    groupBy,
    monthKey,
    monthLabel,
} from "@core/utils.js";
import { Toast } from "@ui/toast.js";

/* ---------------------------------------------------------------------------
 * Estado de la vista
 * ------------------------------------------------------------------------- */

const state = {
    dateFrom: "",
    dateTo: "",
    zone: "",
    type: "",
};

/* ---------------------------------------------------------------------------
 * Instancias de gráficos
 * ------------------------------------------------------------------------- */

let timelineChart = null;
let categoryChart = null;
let zoneChart = null;

/* ---------------------------------------------------------------------------
 * Plantilla HTML
 * ------------------------------------------------------------------------- */

const template = `
<section class="page-section" id="section-estadisticas" data-section="estadisticas" aria-labelledby="title-estadisticas" hidden>
    <div class="page-heading">
        <div>
            <div class="eyebrow">ANÁLISIS CUANTITATIVO</div>
            <h1 id="title-estadisticas">Estadísticas</h1>
            <p>Examina la distribución y evolución de las incidencias registradas.</p>
        </div>
    </div>

    <article class="panel analysis-filters-panel">
        <div class="panel-header">
            <div>
                <h2>Parámetros de análisis</h2>
                <p>Define el conjunto de datos que deseas estudiar.</p>
            </div>
        </div>
        <div class="analysis-filter-grid">
            <div class="form-field">
                <label for="statsDateFrom">Fecha inicial</label>
                <input type="date" id="statsDateFrom">
            </div>
            <div class="form-field">
                <label for="statsDateTo">Fecha final</label>
                <input type="date" id="statsDateTo">
            </div>
            <div class="form-field">
                <label for="statsZone">Zona</label>
                <select id="statsZone">
                    <option value="">Todas las zonas</option>
                </select>
            </div>
            <div class="form-field">
                <label for="statsType">Tipo de incidencia</label>
                <select id="statsType">
                    <option value="">Todos los tipos</option>
                </select>
            </div>
            <div class="form-field analysis-filter-action">
                <button type="button" class="button button-primary button-block" id="applyStatsFilters">
                    <i class="fa-solid fa-chart-line"></i> Analizar datos
                </button>
            </div>
        </div>
    </article>

    <div class="stats-summary-grid">
        <article class="stats-summary-card">
            <span class="stats-summary-label">Total del periodo</span>
            <strong id="statsTotal">0</strong>
            <span>Incidencias incluidas en el análisis</span>
        </article>
        <article class="stats-summary-card">
            <span class="stats-summary-label">Tipo más frecuente</span>
            <strong id="statsTopType">—</strong>
            <span>Según el número de registros</span>
        </article>
        <article class="stats-summary-card">
            <span class="stats-summary-label">Zona con más registros</span>
            <strong id="statsTopZone">—</strong>
            <span>Según la distribución territorial registrada</span>
        </article>
    </div>

    <div class="analysis-grid">
        <article class="panel">
            <div class="panel-header">
                <div>
                    <h2>Evolución temporal</h2>
                    <p>Incidencias por mes dentro del periodo seleccionado.</p>
                </div>
            </div>
            <div class="chart-container chart-container-large" id="statsTimelineChart">
                <div class="empty-chart">
                    <i class="fa-solid fa-chart-column"></i>
                    <span>Selecciona un periodo para analizar los datos.</span>
                </div>
            </div>
        </article>

        <article class="panel">
            <div class="panel-header">
                <div>
                    <h2>Distribución por categorías</h2>
                    <p>Frecuencia de cada tipo de incidencia.</p>
                </div>
            </div>
            <div class="chart-container" id="statsCategoryChart">
                <div class="empty-chart">
                    <i class="fa-solid fa-chart-bar"></i>
                    <span>Sin datos para analizar.</span>
                </div>
            </div>
        </article>
    </div>

    <div class="analysis-grid">
        <article class="panel">
            <div class="panel-header">
                <div>
                    <h2>Distribución por zonas</h2>
                    <p>Volumen de registros según la zona.</p>
                </div>
            </div>
            <div class="chart-container" id="statsZoneChart">
                <div class="empty-chart">
                    <i class="fa-solid fa-chart-bar"></i>
                    <span>Sin datos para analizar.</span>
                </div>
            </div>
        </article>

        <article class="panel">
            <div class="panel-header">
                <div>
                    <h2>Composición de los registros</h2>
                    <p>Resumen numérico por categoría.</p>
                </div>
            </div>
            <div class="table-wrapper">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th scope="col">Categoría</th>
                            <th scope="col">Cantidad</th>
                            <th scope="col">Porcentaje</th>
                        </tr>
                    </thead>
                    <tbody id="statsCategoryTable">
                        <tr>
                            <td colspan="3" class="table-empty">Sin datos disponibles.</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </article>
    </div>
</section>
`;

/* ---------------------------------------------------------------------------
 * Filtrado
 * ------------------------------------------------------------------------- */

function filterIncidents() {
    return DataStore.incidents.list().filter((incident) => {
        if (state.dateFrom && incident.date < state.dateFrom) return false;
        if (state.dateTo && incident.date > state.dateTo) return false;
        if (state.zone && incident.zone !== state.zone) return false;
        if (state.type && incident.type !== state.type) return false;
        return true;
    });
}

/* ---------------------------------------------------------------------------
 * Indicadores del periodo
 * ------------------------------------------------------------------------- */

function renderSummary(list) {
    const totalEl = $("#statsTotal");
    const topTypeEl = $("#statsTopType");
    const topZoneEl = $("#statsTopZone");

    if (totalEl) totalEl.textContent = list.length;

    const byType = groupBy(list, (incident) => incident.type);
    const topType = Object.entries(byType)
        .sort((a, b) => b[1].length - a[1].length)[0];
    if (topTypeEl) topTypeEl.textContent = topType ? topType[0] : "—";

    const byZone = groupBy(list, (incident) => incident.zone);
    const topZone = Object.entries(byZone)
        .sort((a, b) => b[1].length - a[1].length)[0];
    if (topZoneEl) topZoneEl.textContent = topZone ? topZone[0] : "—";
}

/* ---------------------------------------------------------------------------
 * Gráfico de evolución temporal
 * ------------------------------------------------------------------------- */

function renderTimeline(list) {
    const container = $("#statsTimelineChart");
    if (!container) return;

    if (!list.length) {
        container.innerHTML = `
            <div class="empty-chart">
                <i class="fa-solid fa-chart-column"></i>
                <span>Sin datos para el periodo seleccionado.</span>
            </div>
        `;
        if (timelineChart) { timelineChart.destroy(); timelineChart = null; }
        return;
    }

    const byMonth = groupBy(list, (incident) => monthKey(incident.date));
    const keys = Object.keys(byMonth).sort();
    const counts = keys.map((key) => byMonth[key].length);

    container.innerHTML = '<canvas></canvas>';
    const canvas = container.querySelector("canvas");
    if (!canvas) return;

    if (timelineChart) { timelineChart.destroy(); timelineChart = null; }

    timelineChart = new Chart(canvas, {
        type: "bar",
        data: {
            labels: keys.map(monthLabel),
            datasets: [{
                label: "Incidencias",
                data: counts,
                backgroundColor: "#4f46e5",
                borderRadius: 6,
                maxBarThickness: 40,
            }],
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: {
                    grid: { display: false },
                    ticks: { color: "#8a94a6", font: { size: 10 } },
                },
                y: {
                    beginAtZero: true,
                    ticks: { color: "#8a94a6", font: { size: 10 }, precision: 0 },
                    grid: { color: "#eef1f6" },
                },
            },
        },
    });
}

/* ---------------------------------------------------------------------------
 * Gráfico por categoría
 * ------------------------------------------------------------------------- */

function renderCategoryChart(list) {
    const container = $("#statsCategoryChart");
    if (!container) return;

    const byType = groupBy(list, (incident) => incident.type);
    const entries = Object.entries(byType)
        .map(([name, arr]) => ({ name, count: arr.length }))
        .sort((a, b) => b.count - a.count);

    if (!entries.length) {
        container.innerHTML = `
            <div class="empty-chart">
                <i class="fa-solid fa-chart-bar"></i>
                <span>Sin datos para analizar.</span>
            </div>
        `;
        if (categoryChart) { categoryChart.destroy(); categoryChart = null; }
        return;
    }

    container.innerHTML = '<canvas></canvas>';
    const canvas = container.querySelector("canvas");
    if (!canvas) return;

    if (categoryChart) { categoryChart.destroy(); categoryChart = null; }

    categoryChart = new Chart(canvas, {
        type: "bar",
        data: {
            labels: entries.map((entry) => entry.name),
            datasets: [{
                label: "Incidencias",
                data: entries.map((entry) => entry.count),
                backgroundColor: "#7c3aed",
                borderRadius: 5,
            }],
        },
        options: {
            indexAxis: "y",
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: {
                    beginAtZero: true,
                    ticks: { color: "#8a94a6", font: { size: 10 }, precision: 0 },
                    grid: { color: "#eef1f6" },
                },
                y: {
                    grid: { display: false },
                    ticks: { color: "#8a94a6", font: { size: 10 } },
                },
            },
        },
    });
}

/* ---------------------------------------------------------------------------
 * Gráfico por zona
 * ------------------------------------------------------------------------- */

function renderZoneChart(list) {
    const container = $("#statsZoneChart");
    if (!container) return;

    const byZone = groupBy(list, (incident) => incident.zone);
    const entries = Object.entries(byZone)
        .map(([name, arr]) => ({ name, count: arr.length }))
        .sort((a, b) => b.count - a.count);

    if (!entries.length) {
        container.innerHTML = `
            <div class="empty-chart">
                <i class="fa-solid fa-chart-bar"></i>
                <span>Sin datos para analizar.</span>
            </div>
        `;
        if (zoneChart) { zoneChart.destroy(); zoneChart = null; }
        return;
    }

    container.innerHTML = '<canvas></canvas>';
    const canvas = container.querySelector("canvas");
    if (!canvas) return;

    if (zoneChart) { zoneChart.destroy(); zoneChart = null; }

    zoneChart = new Chart(canvas, {
        type: "bar",
        data: {
            labels: entries.map((entry) => entry.name),
            datasets: [{
                label: "Incidencias",
                data: entries.map((entry) => entry.count),
                backgroundColor: "#15805d",
                borderRadius: 5,
            }],
        },
        options: {
            indexAxis: "y",
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: {
                    beginAtZero: true,
                    ticks: { color: "#8a94a6", font: { size: 10 }, precision: 0 },
                    grid: { color: "#eef1f6" },
                },
                y: {
                    grid: { display: false },
                    ticks: { color: "#8a94a6", font: { size: 10 } },
                },
            },
        },
    });
}

/* ---------------------------------------------------------------------------
 * Tabla resumen por categoría
 * ------------------------------------------------------------------------- */

function renderTable(list) {
    const tbody = $("#statsCategoryTable");
    if (!tbody) return;

    const total = list.length;
    const byType = groupBy(list, (incident) => incident.type);
    const entries = Object.entries(byType)
        .map(([name, arr]) => ({ name, count: arr.length }))
        .sort((a, b) => b.count - a.count);

    if (!entries.length) {
        tbody.innerHTML = `
            <tr>
                <td colspan="3" class="table-empty">Sin datos disponibles.</td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = entries.map((entry) => `
        <tr>
            <td>${escapeHTML(entry.name)}</td>
            <td>${entry.count}</td>
            <td>${total ? Math.round((entry.count / total) * 100) : 0}%</td>
        </tr>
    `).join("");
}

/* ---------------------------------------------------------------------------
 * Filtros
 * ------------------------------------------------------------------------- */

function fillFilters() {
    const zoneSelect = $("#statsZone");
    const typeSelect = $("#statsType");

    if (zoneSelect) {
        const zones = DataStore.zones.active().map((zone) => zone.name);
        zoneSelect.innerHTML =
            `<option value="">Todas las zonas</option>` +
            zones.map((name) => `<option value="${escapeHTML(name)}">${escapeHTML(name)}</option>`).join("");
    }
    if (typeSelect) {
        const types = DataStore.types.active().map((type) => type.name);
        typeSelect.innerHTML =
            `<option value="">Todos los tipos</option>` +
            types.map((name) => `<option value="${escapeHTML(name)}">${escapeHTML(name)}</option>`).join("");
    }
}

/* ---------------------------------------------------------------------------
 * Render completo
 * ------------------------------------------------------------------------- */

function render() {
    const list = filterIncidents();
    renderSummary(list);
    renderTimeline(list);
    renderCategoryChart(list);
    renderZoneChart(list);
    renderTable(list);
}

/* ---------------------------------------------------------------------------
 * Inicialización
 * ------------------------------------------------------------------------- */

function init() {
    fillFilters();

    const applyBtn = $("#applyStatsFilters");
    if (applyBtn) {
        applyBtn.addEventListener("click", () => {
            state.dateFrom = $("#statsDateFrom")?.value || "";
            state.dateTo = $("#statsDateTo")?.value || "";
            state.zone = $("#statsZone")?.value || "";
            state.type = $("#statsType")?.value || "";
            render();
            Toast.info("Análisis actualizado", "Se aplicaron los filtros seleccionados.");
        });
    }

    Events.on("section:change", ({ id }) => {
        if (id === "estadisticas") {
            fillFilters();
            render();
        }
    });

    Events.on("datastore:change", () => {
        const section = document.getElementById("section-estadisticas");
        if (section && section.classList.contains("active")) {
            render();
        }
    });
}

/* ---------------------------------------------------------------------------
 * Exportación
 * ------------------------------------------------------------------------- */

export default {
    id: "estadisticas",
    label: "Estadísticas",
    template,
    init,
    render,
};