/**
 * ============================================================================
 * src/sections/registros.js
 * ============================================================================
 *
 * PROPÓSITO
 *   Sección "Registros": listado consultable de incidencias con búsqueda,
 *   filtros por tipo, zona y rango de fechas, paginación, y acciones por
 *   fila (ver detalle, editar, eliminar). También permite exportar los
 *   resultados filtrados a CSV.
 *
 * RESPONSABILIDADES
 *   - Renderizar la tabla paginada de incidencias.
 *   - Aplicar búsqueda y filtros combinados.
 *   - Mostrar el detalle de una incidencia en un modal.
 *   - Abrir el editor de incidencia en un modal.
 *   - Mover incidencias a la papelera con confirmación previa.
 *   - Exportar los registros filtrados a CSV.
 *   - Reaccionar a cambios en los datos y al entrar a la sección.
 *
 * DEPENDENCIAS
 *   - core/datastore.js    → incidencias, usuarios, tipos, zonas, auditoría.
 *   - core/permissions.js  → capacidades según rol.
 *   - core/events.js       → escucha "section:change" y "datastore:change".
 *   - core/utils.js        → helpers de fechas, orden, DOM, CSV.
 *   - ui/toast.js          → notificaciones.
 *   - ui/modal.js          → modal de detalle, editor y confirmación.
 *   - ui/forms.js          → helpers de formulario en el editor.
 *   - core/validators.js   → validación del editor.
 *
 * USADO POR
 *   - main.js              → registra la sección al arrancar.
 *   - sections/inicio.js   → llama a openDetail(id) desde la tabla reciente.
 *
 * EXPORTA
 *   - default              → objeto de sección con id, label, template,
 *                            init(), render(), openDetail(id) y openEditor(id).
 *
 * EVENTOS
 *   - Escucha: "section:change"    → re-render al entrar a "registros".
 *   - Escucha: "datastore:change"  → re-render cuando cambian los datos.
 */

import { DataStore } from "@core/datastore.js";
import { Permissions } from "@core/permissions.js";
import { Events } from "@core/events.js";
import { Validators } from "@core/validators.js";
import {
    $,
    escapeHTML,
    formatDate,
    formatDateTime,
    sortBy,
    toCSV,
    downloadFile,
    todayISO,
} from "@core/utils.js";
import { Toast } from "@ui/toast.js";
import { Modal } from "@ui/modal.js";
import { Forms } from "@ui/forms.js";

/* ---------------------------------------------------------------------------
 * Estado de la vista
 * ------------------------------------------------------------------------- */

const state = {
    search: "",
    type: "",
    zone: "",
    dateFrom: "",
    dateTo: "",
    page: 1,
    pageSize: 10,
};

/* ---------------------------------------------------------------------------
 * Plantilla HTML
 * ------------------------------------------------------------------------- */

const template = `
<section class="page-section" id="section-registros" data-section="registros" aria-labelledby="title-registros" hidden>
    <div class="page-heading">
        <div>
            <div class="eyebrow">BASE DE DATOS</div>
            <h1 id="title-registros">Registros</h1>
            <p>Consulta y administra las incidencias almacenadas en el sistema.</p>
        </div>
        <button type="button" class="button button-primary" data-section-link="registrar">
            <i class="fa-solid fa-plus"></i> Nuevo registro
        </button>
    </div>

    <div class="records-summary">
        <div>
            <span class="records-summary-label">Resultados encontrados</span>
            <strong id="recordsResultCount">0 registros</strong>
        </div>
        <div>
            <span class="records-summary-label">Selección actual</span>
            <strong id="recordsFilterSummary">Todos los registros</strong>
        </div>
    </div>

    <article class="panel filters-panel">
        <div class="panel-header">
            <div>
                <h2>Buscar y filtrar</h2>
                <p>Refina la consulta según los datos disponibles.</p>
            </div>
            <button type="button" class="text-button" id="clearRecordFilters">Restablecer filtros</button>
        </div>
        <div class="filters-grid">
            <div class="form-field filter-search">
                <label for="recordsSearch">Búsqueda</label>
                <div class="input-with-icon">
                    <i class="fa-solid fa-magnifying-glass"></i>
                    <input type="search" id="recordsSearch" placeholder="Código, título o descripción...">
                </div>
            </div>
            <div class="form-field">
                <label for="recordsTypeFilter">Tipo</label>
                <select id="recordsTypeFilter">
                    <option value="">Todos los tipos</option>
                </select>
            </div>
            <div class="form-field">
                <label for="recordsZoneFilter">Zona</label>
                <select id="recordsZoneFilter">
                    <option value="">Todas las zonas</option>
                </select>
            </div>
            <div class="form-field">
                <label for="recordsDateFrom">Desde</label>
                <input type="date" id="recordsDateFrom">
            </div>
            <div class="form-field">
                <label for="recordsDateTo">Hasta</label>
                <input type="date" id="recordsDateTo">
            </div>
        </div>
    </article>

    <article class="panel records-table-panel">
        <div class="table-toolbar">
            <div class="table-toolbar-left">
                <span class="table-title">Listado de incidencias</span>
                <span class="table-subtitle" id="recordsTableSubtitle">Datos registrados en el sistema</span>
            </div>
            <div class="table-toolbar-right">
                <label for="recordsPageSize" class="compact-label">Mostrar</label>
                <select id="recordsPageSize" class="select-control">
                    <option value="10">10</option>
                    <option value="25">25</option>
                    <option value="50">50</option>
                </select>
                <button type="button" class="button button-secondary button-small" id="exportRecordsCsv">
                    <i class="fa-solid fa-download"></i> Exportar CSV
                </button>
            </div>
        </div>

        <div class="table-wrapper">
            <table class="data-table">
                <thead>
                    <tr>
                        <th scope="col">Código</th>
                        <th scope="col">Incidencia</th>
                        <th scope="col">Tipo</th>
                        <th scope="col">Zona</th>
                        <th scope="col">Fecha del hecho</th>
                        <th scope="col">Registrado por</th>
                        <th scope="col">Acciones</th>
                    </tr>
                </thead>
                <tbody id="recordsTableBody">
                    <tr>
                        <td colspan="7" class="table-empty">No hay registros disponibles.</td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="table-pagination">
            <span id="recordsPaginationInfo">Mostrando 0 registros</span>
            <div class="pagination-controls">
                <button type="button" class="icon-button" id="recordsPrevPage" aria-label="Página anterior" disabled>
                    <i class="fa-solid fa-chevron-left"></i>
                </button>
                <span id="recordsPageIndicator">1 / 1</span>
                <button type="button" class="icon-button" id="recordsNextPage" aria-label="Página siguiente" disabled>
                    <i class="fa-solid fa-chevron-right"></i>
                </button>
            </div>
        </div>
    </article>
</section>
`;

/* ---------------------------------------------------------------------------
 * Filtrado
 * ------------------------------------------------------------------------- */

function filterIncidents() {
    const query = state.search.trim().toLowerCase();
    return DataStore.incidents.list().filter((incident) => {
        if (query) {
            const haystack = [
                incident.code,
                incident.type,
                incident.zone,
                incident.title,
                incident.description,
            ].join(" ").toLowerCase();
            if (!haystack.includes(query)) return false;
        }
        if (state.type && incident.type !== state.type) return false;
        if (state.zone && incident.zone !== state.zone) return false;
        if (state.dateFrom && incident.date < state.dateFrom) return false;
        if (state.dateTo && incident.date > state.dateTo) return false;
        return true;
    });
}

/* ---------------------------------------------------------------------------
 * Render de la tabla
 * ------------------------------------------------------------------------- */

function renderTable() {
    const filtered = sortBy(
        filterIncidents(),
        (incident) => `${incident.date} ${incident.time || ""}`,
        "desc"
    );

    const total = filtered.length;
    const totalPages = Math.max(1, Math.ceil(total / state.pageSize));
    if (state.page > totalPages) state.page = totalPages;
    if (state.page < 1) state.page = 1;

    const start = (state.page - 1) * state.pageSize;
    const pageItems = filtered.slice(start, start + state.pageSize);

    /* Cabeceras resumen */
    const countEl = $("#recordsResultCount");
    const filterEl = $("#recordsFilterSummary");
    const subtitleEl = $("#recordsTableSubtitle");

    if (countEl) countEl.textContent = `${total} ${total === 1 ? "registro" : "registros"}`;
    if (filterEl) filterEl.textContent = buildFilterSummary();
    if (subtitleEl) {
        subtitleEl.textContent = total
            ? `Mostrando ${start + 1}–${Math.min(start + state.pageSize, total)} de ${total}`
            : "Sin resultados para los filtros aplicados";
    }

    /* Cuerpo */
    const tbody = $("#recordsTableBody");
    if (!tbody) return;

    if (!pageItems.length) {
        tbody.innerHTML = `
            <tr>
                <td colspan="7" class="table-empty">No hay registros que coincidan con los filtros.</td>
            </tr>
        `;
    } else {
        tbody.innerHTML = pageItems.map((incident) => rowTemplate(incident)).join("");
        bindRowActions(tbody);
    }

    /* Paginación */
    const paginationInfo = $("#recordsPaginationInfo");
    const indicator = $("#recordsPageIndicator");
    const prevBtn = $("#recordsPrevPage");
    const nextBtn = $("#recordsNextPage");

    if (paginationInfo) {
        paginationInfo.textContent = total
            ? `Mostrando ${start + 1}–${Math.min(start + state.pageSize, total)} de ${total} registros`
            : "Sin registros";
    }
    if (indicator) indicator.textContent = `${state.page} / ${totalPages}`;
    if (prevBtn) prevBtn.disabled = state.page <= 1;
    if (nextBtn) nextBtn.disabled = state.page >= totalPages;
}

function rowTemplate(incident) {
    const user = DataStore.users.get(incident.createdBy);
    const canEdit = Permissions.can("incident.update");
    const canDelete = Permissions.can("incident.delete");

    return `
        <tr>
            <td><span class="table-code">${escapeHTML(incident.code)}</span></td>
            <td>
                <span class="table-primary-text">${escapeHTML(incident.title || incident.type)}</span>
                <span class="table-secondary-text">${escapeHTML((incident.description || "").slice(0, 70))}</span>
            </td>
            <td><span class="category-badge">${escapeHTML(incident.type)}</span></td>
            <td>${escapeHTML(incident.zone)}</td>
            <td>${formatDate(incident.date)}</td>
            <td>${escapeHTML(user ? user.name : "—")}</td>
            <td>
                <div class="table-actions">
                    <button type="button" class="table-action-button" data-view="${escapeHTML(incident.id)}" title="Ver detalle">
                        <i class="fa-regular fa-eye"></i>
                    </button>
                    ${canEdit ? `
                        <button type="button" class="table-action-button" data-edit="${escapeHTML(incident.id)}" title="Editar">
                            <i class="fa-solid fa-pen"></i>
                        </button>
                    ` : ""}
                    ${canDelete ? `
                        <button type="button" class="table-action-button danger" data-delete="${escapeHTML(incident.id)}" title="Eliminar">
                            <i class="fa-regular fa-trash-can"></i>
                        </button>
                    ` : ""}
                </div>
            </td>
        </tr>
    `;
}

function bindRowActions(root) {
    root.querySelectorAll("[data-view]").forEach((button) => {
        button.addEventListener("click", () => openDetail(button.dataset.view));
    });
    root.querySelectorAll("[data-edit]").forEach((button) => {
        button.addEventListener("click", () => openEditor(button.dataset.edit));
    });
    root.querySelectorAll("[data-delete]").forEach((button) => {
        button.addEventListener("click", () => confirmDelete(button.dataset.delete));
    });
}

function buildFilterSummary() {
    const parts = [];
    if (state.type) parts.push(`Tipo: ${state.type}`);
    if (state.zone) parts.push(`Zona: ${state.zone}`);
    if (state.dateFrom) parts.push(`Desde: ${formatDate(state.dateFrom)}`);
    if (state.dateTo) parts.push(`Hasta: ${formatDate(state.dateTo)}`);
    if (state.search) parts.push(`Búsqueda: "${state.search}"`);
    return parts.length ? parts.join(" · ") : "Todos los registros";
}

/* ---------------------------------------------------------------------------
 * Modal de detalle
 * ------------------------------------------------------------------------- */

function openDetail(id) {
    const incident = DataStore.incidents.get(id);
    if (!incident) {
        Toast.error("Incidencia no encontrada");
        return;
    }

    const user = DataStore.users.get(incident.createdBy);
    const body = `
        <div class="modal-detail-grid">
            <div class="modal-detail-item">
                <span>Código</span>
                <strong>${escapeHTML(incident.code)}</strong>
            </div>
            <div class="modal-detail-item">
                <span>Tipo</span>
                <strong>${escapeHTML(incident.type)}</strong>
            </div>
            <div class="modal-detail-item">
                <span>Zona</span>
                <strong>${escapeHTML(incident.zone)}</strong>
            </div>
            <div class="modal-detail-item">
                <span>Fecha del hecho</span>
                <strong>${formatDate(incident.date)} ${escapeHTML(incident.time || "")}</strong>
            </div>
            <div class="modal-detail-item">
                <span>Clasificación</span>
                <strong>${escapeHTML(incident.severity || "Sin clasificar")}</strong>
            </div>
            <div class="modal-detail-item">
                <span>Fuente</span>
                <strong>${escapeHTML(incident.source || "—")}</strong>
            </div>
            <div class="modal-detail-item full">
                <span>Título</span>
                <strong>${escapeHTML(incident.title || "—")}</strong>
            </div>
            <div class="modal-detail-item full">
                <span>Descripción</span>
                <strong>${escapeHTML(incident.description || "—")}</strong>
            </div>
            ${incident.observations ? `
                <div class="modal-detail-item full">
                    <span>Observaciones</span>
                    <strong>${escapeHTML(incident.observations)}</strong>
                </div>
            ` : ""}
            <div class="modal-detail-item">
                <span>Registrado por</span>
                <strong>${escapeHTML(user ? user.name : "—")}</strong>
            </div>
            <div class="modal-detail-item">
                <span>Creado</span>
                <strong>${formatDateTime(incident.createdAt)}</strong>
            </div>
        </div>
    `;

    const canEdit = Permissions.can("incident.update");
    const footer = `
        <button type="button" class="button button-secondary" data-modal-close>Cerrar</button>
        ${canEdit ? `
            <button type="button" class="button button-primary" id="modalEditIncident">
                <i class="fa-solid fa-pen"></i> Editar
            </button>
        ` : ""}
    `;

    Modal.open({
        eyebrow: "DETALLE DE INCIDENCIA",
        title: incident.code,
        body,
        footer,
        onMount: ({ footer, close }) => {
            const editBtn = footer.querySelector("#modalEditIncident");
            if (editBtn) {
                editBtn.addEventListener("click", () => {
                    close();
                    openEditor(incident.id);
                });
            }
        },
    });
}

/* ---------------------------------------------------------------------------
 * Modal de edición
 * ------------------------------------------------------------------------- */

function openEditor(id) {
    const incident = DataStore.incidents.get(id);
    if (!incident) {
        Toast.error("Incidencia no encontrada");
        return;
    }

    const typeOptions = DataStore.types.active().map((type) =>
        `<option value="${escapeHTML(type.name)}" ${type.name === incident.type ? "selected" : ""}>${escapeHTML(type.name)}</option>`
    ).join("");

    const zoneOptions = DataStore.zones.active().map((zone) =>
        `<option value="${escapeHTML(zone.name)}" ${zone.name === incident.zone ? "selected" : ""}>${escapeHTML(zone.name)}</option>`
    ).join("");

    const body = `
        <form class="modal-form" id="editIncidentForm">
            <div class="form-grid">
                <div class="form-field">
                    <label for="editType">Tipo</label>
                    <select id="editType" required>${typeOptions}</select>
                    <small class="field-error" data-error-for="editType"></small>
                </div>
                <div class="form-field">
                    <label for="editDate">Fecha</label>
                    <input type="date" id="editDate" value="${escapeHTML(incident.date)}" required>
                    <small class="field-error" data-error-for="editDate"></small>
                </div>
                <div class="form-field">
                    <label for="editTime">Hora</label>
                    <input type="time" id="editTime" value="${escapeHTML(incident.time || "")}">
                </div>
                <div class="form-field">
                    <label for="editZone">Zona</label>
                    <select id="editZone" required>${zoneOptions}</select>
                    <small class="field-error" data-error-for="editZone"></small>
                </div>
                <div class="form-field form-field-full">
                    <label for="editTitle">Título</label>
                    <input type="text" id="editTitle" maxlength="180" value="${escapeHTML(incident.title || "")}" required>
                    <small class="field-error" data-error-for="editTitle"></small>
                </div>
                <div class="form-field form-field-full">
                    <label for="editDescription">Descripción</label>
                    <textarea id="editDescription" rows="4" maxlength="5000" required>${escapeHTML(incident.description || "")}</textarea>
                    <small class="field-error" data-error-for="editDescription"></small>
                </div>
                <div class="form-field">
                    <label for="editSeverity">Clasificación</label>
                    <select id="editSeverity">
                        <option value="">Sin clasificar</option>
                        <option value="Leve" ${incident.severity === "Leve" ? "selected" : ""}>Leve</option>
                        <option value="Moderada" ${incident.severity === "Moderada" ? "selected" : ""}>Moderada</option>
                        <option value="Grave" ${incident.severity === "Grave" ? "selected" : ""}>Grave</option>
                    </select>
                </div>
                <div class="form-field">
                    <label for="editSource">Fuente</label>
                    <select id="editSource">
                        <option value="">Seleccionar fuente</option>
                        ${["Registro directo", "Comunicación institucional", "Reporte ciudadano", "Documento o informe", "Otro"]
                            .map((option) => `<option value="${option}" ${incident.source === option ? "selected" : ""}>${option}</option>`)
                            .join("")}
                    </select>
                </div>
            </div>
        </form>
    `;

    const footer = `
        <button type="button" class="button button-secondary" data-modal-close>Cancelar</button>
        <button type="button" class="button button-primary" id="saveEditBtn">
            <i class="fa-solid fa-floppy-disk"></i> Guardar cambios
        </button>
    `;

    Modal.open({
        eyebrow: "EDITAR INCIDENCIA",
        title: incident.code,
        body,
        footer,
        onMount: ({ footer, close }) => {
            const saveBtn = footer.querySelector("#saveEditBtn");
            if (!saveBtn) return;

            saveBtn.addEventListener("click", () => {
                const patch = {
                    type: Forms.valueOf("editType"),
                    date: Forms.valueOf("editDate"),
                    time: Forms.valueOf("editTime"),
                    zone: Forms.valueOf("editZone"),
                    title: Forms.valueOf("editTitle"),
                    description: Forms.valueOf("editDescription"),
                    severity: Forms.valueOf("editSeverity"),
                    source: Forms.valueOf("editSource"),
                };

                const result = Validators.schema(
                    {
                        type: patch.type,
                        date: patch.date,
                        time: patch.time,
                        zone: patch.zone,
                        title: patch.title,
                        description: patch.description,
                    },
                    Validators.SCHEMAS.incident
                );

                /* Limpiar y aplicar errores al formulario del modal */
                ["editType", "editDate", "editTime", "editZone", "editTitle", "editDescription"]
                    .forEach((fieldId) => Forms.setFieldError(fieldId, ""));

                const fieldMap = {
                    type: "editType",
                    date: "editDate",
                    time: "editTime",
                    zone: "editZone",
                    title: "editTitle",
                    description: "editDescription",
                };

                Object.entries(result.errors).forEach(([field, message]) => {
                    Forms.setFieldError(fieldMap[field] || field, message);
                });

                if (!result.valid) {
                    Toast.warning("Revisa el formulario", "Hay campos obligatorios sin completar.");
                    return;
                }

                DataStore.incidents.update(incident.id, patch);
                DataStore.audit.log(
                    "update",
                    "incident",
                    incident.id,
                    `Actualización de incidencia ${incident.code}`,
                    { changes: patch }
                );

                Toast.success("Incidencia actualizada", incident.code);
                close();
                render();
            });
        },
    });
}

/* ---------------------------------------------------------------------------
 * Eliminación con confirmación
 * ------------------------------------------------------------------------- */

function confirmDelete(id) {
    const incident = DataStore.incidents.get(id);
    if (!incident) return;

    Modal.confirm({
        title: "Eliminar incidencia",
        message: `¿Deseas mover la incidencia ${incident.code} a la papelera? Podrás restaurarla después.`,
        confirmLabel: "Mover a papelera",
        danger: true,
        onConfirm: () => {
            DataStore.incidents.softDelete(id);
            DataStore.audit.log(
                "delete",
                "incident",
                id,
                `Envío a papelera de la incidencia ${incident.code}`
            );
            Toast.success("Incidencia eliminada", `${incident.code} se movió a la papelera.`);
            render();
        },
    });
}

/* ---------------------------------------------------------------------------
 * Exportación CSV
 * ------------------------------------------------------------------------- */

function exportCSV() {
    const rows = [
        ["Código", "Tipo", "Zona", "Fecha", "Hora", "Título", "Descripción", "Clasificación", "Fuente", "Registrado por"],
        ...filterIncidents().map((incident) => {
            const user = DataStore.users.get(incident.createdBy);
            return [
                incident.code,
                incident.type,
                incident.zone,
                incident.date,
                incident.time || "",
                incident.title || "",
                incident.description || "",
                incident.severity || "",
                incident.source || "",
                user ? user.name : "",
            ];
        }),
    ];

    downloadFile(toCSV(rows), `huanta-segura-registros-${todayISO()}.csv`);
    DataStore.audit.log(
        "export",
        "incident",
        null,
        `Exportación CSV de ${filterIncidents().length} registros`
    );
    Toast.success("Archivo exportado", "Se descargó el CSV con los registros filtrados.");
}

/* ---------------------------------------------------------------------------
 * Filtros y controles
 * ------------------------------------------------------------------------- */

function fillFilterOptions() {
    const typeSelect = $("#recordsTypeFilter");
    const zoneSelect = $("#recordsZoneFilter");

    if (typeSelect) {
        const types = DataStore.types.active().map((type) => type.name);
        typeSelect.innerHTML =
            `<option value="">Todos los tipos</option>` +
            types.map((name) => `<option value="${escapeHTML(name)}">${escapeHTML(name)}</option>`).join("");
    }
    if (zoneSelect) {
        const zones = DataStore.zones.active().map((zone) => zone.name);
        zoneSelect.innerHTML =
            `<option value="">Todas las zonas</option>` +
            zones.map((name) => `<option value="${escapeHTML(name)}">${escapeHTML(name)}</option>`).join("");
    }
}

function bindControls() {
    const searchInput = $("#recordsSearch");
    if (searchInput) {
        let timer = null;
        searchInput.addEventListener("input", (event) => {
            clearTimeout(timer);
            timer = setTimeout(() => {
                state.search = event.target.value;
                state.page = 1;
                renderTable();
            }, 200);
        });
    }

    const typeFilter = $("#recordsTypeFilter");
    if (typeFilter) {
        typeFilter.addEventListener("change", (event) => {
            state.type = event.target.value;
            state.page = 1;
            renderTable();
        });
    }

    const zoneFilter = $("#recordsZoneFilter");
    if (zoneFilter) {
        zoneFilter.addEventListener("change", (event) => {
            state.zone = event.target.value;
            state.page = 1;
            renderTable();
        });
    }

    const dateFrom = $("#recordsDateFrom");
    if (dateFrom) {
        dateFrom.addEventListener("change", (event) => {
            state.dateFrom = event.target.value;
            state.page = 1;
            renderTable();
        });
    }

    const dateTo = $("#recordsDateTo");
    if (dateTo) {
        dateTo.addEventListener("change", (event) => {
            state.dateTo = event.target.value;
            state.page = 1;
            renderTable();
        });
    }

    const pageSize = $("#recordsPageSize");
    if (pageSize) {
        pageSize.addEventListener("change", (event) => {
            state.pageSize = Number(event.target.value) || 10;
            state.page = 1;
            renderTable();
        });
    }

    const prevBtn = $("#recordsPrevPage");
    if (prevBtn) {
        prevBtn.addEventListener("click", () => {
            if (state.page > 1) {
                state.page -= 1;
                renderTable();
            }
        });
    }

    const nextBtn = $("#recordsNextPage");
    if (nextBtn) {
        nextBtn.addEventListener("click", () => {
            state.page += 1;
            renderTable();
        });
    }

    const clearBtn = $("#clearRecordFilters");
    if (clearBtn) {
        clearBtn.addEventListener("click", () => {
            state.search = "";
            state.type = "";
            state.zone = "";
            state.dateFrom = "";
            state.dateTo = "";
            state.page = 1;

            if (searchInput) searchInput.value = "";
            if (typeFilter) typeFilter.value = "";
            if (zoneFilter) zoneFilter.value = "";
            if (dateFrom) dateFrom.value = "";
            if (dateTo) dateTo.value = "";

            renderTable();
        });
    }

    const exportBtn = $("#exportRecordsCsv");
    if (exportBtn) {
        exportBtn.addEventListener("click", exportCSV);
    }
}

/* ---------------------------------------------------------------------------
 * Render completo
 * ------------------------------------------------------------------------- */

function render() {
    fillFilterOptions();
    renderTable();
}

/* ---------------------------------------------------------------------------
 * Inicialización
 * ------------------------------------------------------------------------- */

function init() {
    fillFilterOptions();
    bindControls();

    Events.on("section:change", ({ id }) => {
        if (id === "registros") render();
    });

    Events.on("datastore:change", () => {
        const section = document.getElementById("section-registros");
        if (section && section.classList.contains("active")) {
            renderTable();
        }
    });
}

/* ---------------------------------------------------------------------------
 * Exportación
 * ------------------------------------------------------------------------- */

export default {
    id: "registros",
    label: "Registros",
    template,
    init,
    render,
    openDetail,
    openEditor,
};