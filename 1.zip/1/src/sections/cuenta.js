/**
 * ============================================================================
 * src/sections/cuenta.js
 * ============================================================================
 *
 * PROPÓSITO
 *   Sección "Mi cuenta": consulta y configuración del perfil del usuario
 *   activo. Permite ajustar preferencias personales (idioma, apariencia,
 *   densidad de tablas) y cerrar la sesión. También expone un selector de
 *   rol de prueba útil durante el desarrollo y las demostraciones.
 *
 * RESPONSABILIDADES
 *   - Mostrar nombre, correo, rol, estado y último acceso del usuario.
 *   - Guardar preferencias personales: idioma, tema (claro/oscuro/sistema)
 *     y densidad de tablas (cómoda/compacta).
 *   - Aplicar las preferencias al <body> y persistirlas en localStorage.
 *   - Ofrecer un cierre de sesión con confirmación.
 *   - Exponer un selector de rol de demostración (solo para pruebas).
 *   - Reaccionar a cambios de sesión y al entrar a la sección.
 *
 * DEPENDENCIAS
 *   - core/datastore.js    → usuarios, sesión, auditoría.
 *   - core/session.js      → ROLES, cambio de rol y etiquetas.
 *   - core/events.js       → escucha "session:change" y "section:change".
 *   - core/utils.js        → helpers de DOM, formato de fechas, iniciales.
 *   - ui/toast.js          → notificaciones.
 *   - ui/modal.js          → confirmación de cierre de sesión.
 *
 * USADO POR
 *   - main.js              → registra la sección al arrancar.
 *
 * EXPORTA
 *   - default              → objeto de sección con id, label, template,
 *                            init() y render().
 *
 * EVENTOS
 *   - Escucha: "section:change"    → refresca el perfil al entrar.
 *   - Escucha: "session:change"    → refresca el perfil al cambiar de rol.
 */

import { DataStore } from "@core/datastore.js";
import { Session, ROLES } from "@core/session.js";
import { Events } from "@core/events.js";
import { $, escapeHTML, formatDateTime, buildInitials } from "@core/utils.js";
import { Toast } from "@ui/toast.js";
import { Modal } from "@ui/modal.js";

/* ---------------------------------------------------------------------------
 * Claves de almacenamiento de preferencias
 * ------------------------------------------------------------------------- */

const STORAGE_KEYS = {
    theme: "huanta-segura:theme",
    density: "huanta-segura:density",
    language: "huanta-segura:language",
};

/* ---------------------------------------------------------------------------
 * Plantilla HTML
 * ------------------------------------------------------------------------- */

const template = `
<section class="page-section" id="section-cuenta" data-section="cuenta" aria-labelledby="title-cuenta" hidden>
    <div class="page-heading">
        <div>
            <div class="eyebrow">PERFIL PERSONAL</div>
            <h1 id="title-cuenta">Mi cuenta</h1>
            <p>Consulta tu perfil y administra tus preferencias personales.</p>
        </div>
    </div>

    <div class="account-layout">
        <article class="panel account-profile-panel">
            <div class="account-profile-header">
                <div class="account-avatar" id="accountAvatar">AD</div>
                <div>
                    <h2 id="accountDisplayName">Administrador</h2>
                    <p id="accountDisplayEmail">Correo no disponible</p>
                    <span class="role-badge" id="accountRoleBadge">Administrador</span>
                </div>
            </div>
            <div class="account-divider"></div>
            <div class="account-information">
                <div class="account-info-item">
                    <span>Estado de la cuenta</span>
                    <strong id="accountStatus">Entorno de demostración</strong>
                </div>
                <div class="account-info-item">
                    <span>Último acceso</span>
                    <strong id="accountLastLogin">No disponible</strong>
                </div>
                <div class="account-info-item">
                    <span>Identificador</span>
                    <strong id="accountUserId">No asignado</strong>
                </div>
            </div>

            <div class="account-divider"></div>

            <div class="account-role-demo">
                <span class="compact-label">Rol de prueba (solo demostración)</span>
                <select id="accountRoleSelector" class="select-control" style="width:100%;margin-top:8px">
                    <option value="admin">Administrador</option>
                    <option value="operario">Operario</option>
                    <option value="consulta">Consulta</option>
                </select>
            </div>
        </article>

        <article class="panel account-preferences-panel">
            <div class="panel-header">
                <div>
                    <h2>Preferencias</h2>
                    <p>Opciones de visualización de tu cuenta.</p>
                </div>
            </div>
            <form id="accountPreferencesForm">
                <div class="form-field">
                    <label for="accountLanguage">Idioma</label>
                    <select id="accountLanguage">
                        <option value="es">Español</option>
                    </select>
                </div>
                <div class="form-field">
                    <label for="accountTheme">Apariencia</label>
                    <select id="accountTheme">
                        <option value="light">Claro</option>
                        <option value="dark">Oscuro</option>
                        <option value="system">Según el dispositivo</option>
                    </select>
                </div>
                <div class="form-field">
                    <label for="accountDensity">Densidad de tablas</label>
                    <select id="accountDensity">
                        <option value="comfortable">Cómoda</option>
                        <option value="compact">Compacta</option>
                    </select>
                </div>
                <div class="form-actions">
                    <button type="submit" class="button button-primary">
                        <i class="fa-solid fa-floppy-disk"></i> Guardar preferencias
                    </button>
                </div>
            </form>
            <div class="account-divider"></div>
            <div class="account-security">
                <div>
                    <h3>Sesión</h3>
                    <p>Cierra tu sesión cuando termines de trabajar en un dispositivo compartido.</p>
                </div>
                <button type="button" class="button button-danger-outline" id="signOutButton">
                    <i class="fa-solid fa-right-from-bracket"></i> Cerrar sesión
                </button>
            </div>
        </article>
    </div>
</section>
`;

/* ---------------------------------------------------------------------------
 * Aplicación de preferencias
 * ------------------------------------------------------------------------- */

function applyTheme(theme) {
    document.body.classList.remove("theme-dark");
    if (theme === "dark") {
        document.body.classList.add("theme-dark");
    } else if (theme === "system") {
        if (window.matchMedia("(prefers-color-scheme: dark)").matches) {
            document.body.classList.add("theme-dark");
        }
    }
}

function applyDensity(density) {
    document.body.classList.toggle("density-compact", density === "compact");
}

function loadPreferences() {
    let theme = "light";
    let density = "comfortable";
    let language = "es";

    try {
        theme = localStorage.getItem(STORAGE_KEYS.theme) || theme;
        density = localStorage.getItem(STORAGE_KEYS.density) || density;
        language = localStorage.getItem(STORAGE_KEYS.language) || language;
    } catch {
        /* localStorage no disponible: usar valores por defecto */
    }

    return { theme, density, language };
}

function persistPreferences(preferences) {
    try {
        localStorage.setItem(STORAGE_KEYS.theme, preferences.theme);
        localStorage.setItem(STORAGE_KEYS.density, preferences.density);
        localStorage.setItem(STORAGE_KEYS.language, preferences.language);
    } catch {
        /* Ignorar errores de almacenamiento */
    }
}

/* ---------------------------------------------------------------------------
 * Render del perfil
 * ------------------------------------------------------------------------- */

function renderProfile() {
    const session = Session.get();
    const user = session.userId ? DataStore.users.get(session.userId) : null;

    const name = user?.name || "Administrador";
    const email = user?.email || "admin@huanta.gob.pe";
    const roleKey = session.role || "admin";
    const roleLabel = ROLES[roleKey]?.label || roleKey;

    const avatarEl = $("#accountAvatar");
    if (avatarEl) avatarEl.textContent = buildInitials(name);

    const nameEl = $("#accountDisplayName");
    if (nameEl) nameEl.textContent = name;

    const emailEl = $("#accountDisplayEmail");
    if (emailEl) emailEl.textContent = email;

    const badgeEl = $("#accountRoleBadge");
    if (badgeEl) badgeEl.textContent = roleLabel;

    const statusEl = $("#accountStatus");
    if (statusEl) statusEl.textContent = "Entorno de demostración";

    const loginEl = $("#accountLastLogin");
    if (loginEl) loginEl.textContent = formatDateTime(new Date().toISOString());

    const idEl = $("#accountUserId");
    if (idEl) idEl.textContent = user?.id || "—";

    const roleSelector = $("#accountRoleSelector");
    if (roleSelector) roleSelector.value = roleKey;
}

/* ---------------------------------------------------------------------------
 * Render de preferencias
 * ------------------------------------------------------------------------- */

function renderPreferences() {
    const preferences = loadPreferences();

    const themeSelect = $("#accountTheme");
    if (themeSelect) themeSelect.value = preferences.theme;

    const densitySelect = $("#accountDensity");
    if (densitySelect) densitySelect.value = preferences.density;

    const languageSelect = $("#accountLanguage");
    if (languageSelect) languageSelect.value = preferences.language;

    applyTheme(preferences.theme);
    applyDensity(preferences.density);
}

/* ---------------------------------------------------------------------------
 * Guardar preferencias
 * ------------------------------------------------------------------------- */

function savePreferences(event) {
    event.preventDefault();

    const preferences = {
        theme: $("#accountTheme")?.value || "light",
        density: $("#accountDensity")?.value || "comfortable",
        language: $("#accountLanguage")?.value || "es",
    };

    persistPreferences(preferences);
    applyTheme(preferences.theme);
    applyDensity(preferences.density);

    DataStore.audit.log(
        "admin",
        "preferences",
        null,
        `Preferencias: tema ${preferences.theme}, densidad ${preferences.density}`
    );

    Toast.success("Preferencias guardadas", "Los cambios se aplicaron a tu cuenta.");
}

/* ---------------------------------------------------------------------------
 * Cierre de sesión
 * ------------------------------------------------------------------------- */

function signOut() {
    Modal.confirm({
        title: "Cerrar sesión",
        message: "¿Cerrar la sesión actual? En este entorno de demostración no se pierden datos.",
        confirmLabel: "Cerrar sesión",
        onConfirm: () => {
            Toast.info("Sesión cerrada", "En producción, se redirigiría al inicio de sesión.");
        },
    });
}

/* ---------------------------------------------------------------------------
 * Selector de rol (demostración)
 * ------------------------------------------------------------------------- */

function handleRoleChange(event) {
    const role = event.target.value;
    if (!ROLES[role]) return;
    Session.setRole(role);
    renderProfile();
    Toast.info("Rol cambiado", `Ahora trabajas como ${ROLES[role].label}.`);
}

/* ---------------------------------------------------------------------------
 * Render
 * ------------------------------------------------------------------------- */

function render() {
    renderProfile();
    renderPreferences();
}

/* ---------------------------------------------------------------------------
 * Inicialización
 * ------------------------------------------------------------------------- */

function init() {
    renderProfile();
    renderPreferences();

    const form = $("#accountPreferencesForm");
    if (form) form.addEventListener("submit", savePreferences);

    const signOutButton = $("#signOutButton");
    if (signOutButton) signOutButton.addEventListener("click", signOut);

    const roleSelector = $("#accountRoleSelector");
    if (roleSelector) roleSelector.addEventListener("change", handleRoleChange);

    Events.on("section:change", ({ id }) => {
        if (id === "cuenta") render();
    });

    Events.on("session:change", () => {
        renderProfile();
    });
}

/* ---------------------------------------------------------------------------
 * Exportación
 * ------------------------------------------------------------------------- */

export default {
    id: "cuenta",
    label: "Mi cuenta",
    template,
    init,
    render,
};