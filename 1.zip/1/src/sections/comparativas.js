/**
 * ============================================================================
 * src/sections/comparativas.js
 * ============================================================================
 *
 * PROPÓSITO
 *   Sección "Comparativas": contraste entre dos periodos, zonas o tipos de
 *   incidencia. Muestra diferencias absolutas, variaciones porcentuales y un
 *   desglose por categoría para identificar aumentos o reducciones.
 *
 * RESPONSABILIDADES
 *   - Rellenar los desplegables de zonas y tipos desde el DataStore.
 *   - Prellenar los periodos con el mes anterior y el mes actual.
 *   - Ejecutar la comparación según el criterio elegido (total, tipo, zona,
 *     día de la semana) y filtros opcionales.
 *   - Renderizar tarjetas resumen y tabla de detalle por categoría.
 *   - Registrar la operación en la auditoría.
 *   - Reaccionar al cambio de sección y a cambios en los datos.
 *
 * DEPENDENCIAS
 *   - core/datastore.js    → incidencias, tipos, zonas, auditoría.
 *   - core/events.js       → escucha "section:change" y "datastore:change".
 *   - core/utils.js        → helpers de fechas, agrupación, DOM.
 *   - ui/toast.js          → notificaciones.
 *
 * USADO POR
 *   - main.js              → registra la sección al arrancar.
 *
 * EXPORTA
 *   - default              → objeto de sección con id, label, template,
 *                            init() y render().
 *
 * EVENTOS
 *   - Escucha: "section:change"    → rellena filtros al entrar.
 *   - Escucha: "datastore:change"  → refresca filtros si cambian catálogos.
 */

import { DataStore } from "@core/datastore.js";
import { Events } from "@core/events.js";
import {
    $,
    escapeHTML,
    formatDate,
    groupBy,
} from "@core/utils.js";
import { Toast } from "@ui/toast.js";

/* ---------------------------------------------------------------------------
 * Plantilla HTML
 * ------------------------------------------------------------------------- */

const template = `
<section class="page-section" id="section-comparativas" data-section="comparativas" aria-labelledby="title-comparativas" hidden>
    <div class="page-heading">
        <div>
            <div class="eyebrow">ANÁLISIS COMPARATIVO</div>
            <h1 id="title-comparativas">Comparativas</h1>
            <p>Compara periodos, zonas y categorías utilizando los registros almacenados.</p>
        </div>
    </div>

    <article class="panel comparison-config-panel">
        <div class="panel-header">
            <div>
                <h2>Definir comparación</h2>
                <p>Selecciona dos conjuntos de datos comparables.</p>
            </div>
        </div>

        <form id="comparisonForm">
            <div class="comparison-periods">
                <div class="comparison-period comparison-period-a">
                    <div class="comparison-period-heading">
                        <span class="comparison-period-marker">A</span>
                        <div>
                            <h3>Periodo de referencia</h3>
                            <p>Primer intervalo de análisis.</p>
                        </div>
                    </div>
                    <div class="form-grid">
                        <div class="form-field">
                            <label for="comparisonAFrom">Desde</label>
                            <input type="date" id="comparisonAFrom" required>
                        </div>
                        <div class="form-field">
                            <label for="comparisonATo">Hasta</label>
                            <input type="date" id="comparisonATo" required>
                        </div>
                    </div>
                </div>

                <div class="comparison-period comparison-period-b">
                    <div class="comparison-period-heading">
                        <span class="comparison-period-marker">B</span>
                        <div>
                            <h3>Periodo a comparar</h3>
                            <p>Segundo intervalo de análisis.</p>
                        </div>
                    </div>
                    <div class="form-grid">
                        <div class="form-field">
                            <label for="comparisonBFrom">Desde</label>
                            <input type="date" id="comparisonBFrom" required>
                        </div>
                        <div class="form-field">
                            <label for="comparisonBTo">Hasta</label>
                            <input type="date" id="comparisonBTo" required>
                        </div>
                    </div>
                </div>
            </div>

            <div class="form-grid comparison-extra-filters">
                <div class="form-field">
                    <label for="comparisonDimension">Criterio principal</label>
                    <select id="comparisonDimension">
                        <option value="total">Total de incidencias</option>
                        <option value="type">Por tipo de incidencia</option>
                        <option value="zone">Por zona</option>
                        <option value="weekday">Por día de la semana</option>
                    </select>
                </div>
                <div class="form-field">
                    <label for="comparisonZone">Limitar a zona</label>
                    <select id="comparisonZone">
                        <option value="">Todas las zonas</option>
                    </select>
                </div>
                <div class="form-field">
                    <label for="comparisonType">Limitar a tipo</label>
                    <select id="comparisonType">
                        <option value="">Todos los tipos</option>
                    </select>
                </div>
            </div>

            <div class="form-actions">
                <button type="reset" class="button button-secondary">Restablecer</button>
                <button type="submit" class="button button-primary" id="runComparison">
                    <i class="fa-solid fa-code-compare"></i> Comparar periodos
                </button>
            </div>
        </form>
    </article>

    <div id="comparisonResults" class="comparison-results">
        <div class="comparison-empty panel">
            <div class="comparison-empty-icon">
                <i class="fa-solid fa-scale-balanced"></i>
            </div>
            <h2>Compara dos periodos</h2>
            <p>Los resultados mostrarán diferencias absolutas, variaciones porcentuales y cambios en la distribución de las incidencias.</p>
        </div>
    </div>
</section>
`;

/* ---------------------------------------------------------------------------
 * Utilidades de cálculo
 * ------------------------------------------------------------------------- */

const WEEKDAY_LABELS = ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];

function keyForDimension(incident, dimension) {
    if (dimension === "type") return incident.type;
    if (dimension === "zone") return incident.zone;
    if (dimension === "weekday") {
        const day = new Date(incident.date).getDay();
        return WEEKDAY_LABELS[day] || "—";
    }
    return "__total__";
}

function aggregate(list, from, to, dimension) {
    const inRange = list.filter((incident) => {
        if (from && incident.date < from) return false;
        if (to && incident.date > to) return false;
        return true;
    });

    if (dimension === "total") {
        return { total: inRange.length, breakdown: {} };
    }

    const grouped = groupBy(inRange, (incident) => keyForDimension(incident, dimension));
    const breakdown = {};
    Object.entries(grouped).forEach(([key, arr]) => {
        breakdown[key] = arr.length;
    });

    return { total: inRange.length, breakdown };
}

/* ---------------------------------------------------------------------------
 * Render de resultados
 * ------------------------------------------------------------------------- */

function renderResults(a, b, dimension, labelA, labelB) {
    const deltaTotal = b.total - a.total;
    const percent = a.total === 0
        ? (b.total === 0 ? 0 : 100)
        : Math.round((deltaTotal / a.total) * 100);

    const direction = deltaTotal > 0 ? "up" : deltaTotal < 0 ? "down" : "neutral";
    const sign = deltaTotal > 0 ? "+" : "";
    const arrow = direction === "up" ? "up" : direction === "down" ? "down" : "right";

    const keys = new Set([
        ...Object.keys(a.breakdown),
        ...Object.keys(b.breakdown),
    ]);

    const rows = Array.from(keys).map((key) => {
        const va = a.breakdown[key] || 0;
        const vb = b.breakdown[key] || 0;
        const delta = vb - va;
        const pct = va === 0
            ? (vb === 0 ? 0 : 100)
            : Math.round((delta / va) * 100);
        return { key, va, vb, delta, pct };
    }).sort((x, y) => y.vb - x.vb);

    const dimensionLabel = dimension === "type"
        ? "tipo"
        : dimension === "zone"
            ? "zona"
            : dimension === "weekday"
                ? "día de la semana"
                : "categoría";

    const results = $("#comparisonResults");
    if (!results) return;

    results.innerHTML = `
        <div class="comparison-result-grid">
            <article class="comparison-result-card">
                <span>Periodo A</span>
                <strong>${a.total}</strong>
                <small>${escapeHTML(labelA)}</small>
            </article>
            <article class="comparison-result-card">
                <span>Periodo B</span>
                <strong>${b.total}</strong>
                <small>${escapeHTML(labelB)}</small>
            </article>
            <article class="comparison-result-card">
                <span>Diferencia</span>
                <strong>${sign}${deltaTotal}</strong>
                <small class="comparison-delta ${direction}">
                    <i class="fa-solid fa-arrow-${arrow}"></i>
                    ${sign}${percent}% respecto a A
                </small>
            </article>
        </div>

        ${rows.length && dimension !== "total" ? `
            <article class="panel">
                <div class="panel-header">
                    <div>
                        <h2>Detalle por ${dimensionLabel}</h2>
                        <p>Comparación entre ambos periodos.</p>
                    </div>
                </div>
                <div class="table-wrapper">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Categoría</th>
                                <th>Periodo A</th>
                                <th>Periodo B</th>
                                <th>Diferencia</th>
                                <th>Variación</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${rows.map((row) => {
                                const cls = row.delta > 0 ? "up" : row.delta < 0 ? "down" : "neutral";
                                const s = row.delta > 0 ? "+" : "";
                                return `
                                    <tr>
                                        <td>${escapeHTML(row.key)}</td>
                                        <td>${row.va}</td>
                                        <td>${row.vb}</td>
                                        <td>${s}${row.delta}</td>
                                        <td><span class="comparison-delta ${cls}">${s}${row.pct}%</span></td>
                                    </tr>
                                `;
                            }).join("")}
                        </tbody>
                    </table>
                </div>
            </article>
        ` : ""}
    `;
}

/* ---------------------------------------------------------------------------
 * Ejecución de la comparación
 * ------------------------------------------------------------------------- */

function runComparison(event) {
    event.preventDefault();

    const aFrom = $("#comparisonAFrom")?.value || "";
    const aTo = $("#comparisonATo")?.value || "";
    const bFrom = $("#comparisonBFrom")?.value || "";
    const bTo = $("#comparisonBTo")?.value || "";

    if (!aFrom || !aTo || !bFrom || !bTo) {
        Toast.warning("Faltan fechas", "Completa los dos periodos para comparar.");
        return;
    }
    if (aFrom > aTo || bFrom > bTo) {
        Toast.error("Rango inválido", "La fecha inicial no puede ser mayor que la final.");
        return;
    }

    const dimension = $("#comparisonDimension")?.value || "total";
    const zoneFilter = $("#comparisonZone")?.value || "";
    const typeFilter = $("#comparisonType")?.value || "";

    let list = DataStore.incidents.list();
    if (zoneFilter) list = list.filter((incident) => incident.zone === zoneFilter);
    if (typeFilter) list = list.filter((incident) => incident.type === typeFilter);

    const a = aggregate(list, aFrom, aTo, dimension);
    const b = aggregate(list, bFrom, bTo, dimension);

    renderResults(
        a,
        b,
        dimension,
        `${formatDate(aFrom)} – ${formatDate(aTo)}`,
        `${formatDate(bFrom)} – ${formatDate(bTo)}`
    );

    DataStore.audit.log(
        "export",
        "comparison",
        null,
        `Comparación ${dimension} entre ${formatDate(aFrom)} y ${formatDate(bTo)}`
    );

    Toast.success("Comparación generada", `${a.total} vs ${b.total} incidencias.`);
}

/* ---------------------------------------------------------------------------
 * Filtros dinámicos
 * ------------------------------------------------------------------------- */

function fillFilters() {
    const zoneSelect = $("#comparisonZone");
    const typeSelect = $("#comparisonType");

    if (zoneSelect) {
        const zones = DataStore.zones.active().map((zone) => zone.name);
        zoneSelect.innerHTML =
            `<option value="">Todas las zonas</option>` +
            zones.map((name) => `<option value="${escapeHTML(name)}">${escapeHTML(name)}</option>`).join("");
    }
    if (typeSelect) {
        const types = DataStore.types.active().map((type) => type.name);
        typeSelect.innerHTML =
            `<option value="">Todos los tipos</option>` +
            types.map((name) => `<option value="${escapeHTML(name)}">${escapeHTML(name)}</option>`).join("");
    }
}

/* ---------------------------------------------------------------------------
 * Prellenado de fechas
 * ------------------------------------------------------------------------- */

function prefillDates() {
    const now = new Date();
    const iso = (date) => date.toISOString().slice(0, 10);

    const firstLastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const lastLastMonth = new Date(now.getFullYear(), now.getMonth(), 0);
    const firstThisMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const lastThisMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0);

    const aFrom = $("#comparisonAFrom");
    const aTo = $("#comparisonATo");
    const bFrom = $("#comparisonBFrom");
    const bTo = $("#comparisonBTo");

    if (aFrom && !aFrom.value) aFrom.value = iso(firstLastMonth);
    if (aTo && !aTo.value) aTo.value = iso(lastLastMonth);
    if (bFrom && !bFrom.value) bFrom.value = iso(firstThisMonth);
    if (bTo && !bTo.value) bTo.value = iso(lastThisMonth);
}

/* ---------------------------------------------------------------------------
 * Render
 * ------------------------------------------------------------------------- */

function render() {
    fillFilters();
    prefillDates();
}

/* ---------------------------------------------------------------------------
 * Inicialización
 * ------------------------------------------------------------------------- */

function init() {
    fillFilters();
    prefillDates();

    const form = $("#comparisonForm");
    if (form) form.addEventListener("submit", runComparison);

    Events.on("section:change", ({ id }) => {
        if (id === "comparativas") {
            fillFilters();
            prefillDates();
        }
    });

    Events.on("datastore:change", () => {
        const section = document.getElementById("section-comparativas");
        if (section && section.classList.contains("active")) {
            fillFilters();
        }
    });
}

/* ---------------------------------------------------------------------------
 * Exportación
 * ------------------------------------------------------------------------- */

export default {
    id: "comparativas",
    label: "Comparativas",
    template,
    init,
    render,
};