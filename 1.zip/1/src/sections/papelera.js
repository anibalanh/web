/**
 * ============================================================================
 * src/sections/papelera.js
 * ============================================================================
 *
 * PROPÓSITO
 *   Sección "Papelera": consulta de registros eliminados lógicamente. Permite
 *   buscar, filtrar por rango de fechas de eliminación, restaurar registros o
 *   eliminarlos de forma definitiva según los permisos del rol activo.
 *
 * RESPONSABILIDADES
 *   - Listar las incidencias que están en la papelera.
 *   - Aplicar búsqueda por código, título o tipo.
 *   - Filtrar por fecha de eliminación (desde / hasta).
 *   - Restaurar un registro con confirmación previa.
 *   - Eliminar definitivamente un registro con confirmación previa.
 *   - Registrar cada operación en la auditoría.
 *   - Reaccionar a cambios en los datos y al entrar a la sección.
 *
 * DEPENDENCIAS
 *   - core/datastore.js    → papelera, incidencias, usuarios, auditoría.
 *   - core/permissions.js  → capacidades de restaurar y eliminar.
 *   - core/events.js       → escucha "section:change" y "datastore:change".
 *   - core/utils.js        → helpers de fechas, orden, DOM.
 *   - ui/toast.js          → notificaciones.
 *   - ui/modal.js          → confirmaciones.
 *
 * USADO POR
 *   - main.js              → registra la sección al arrancar.
 *
 * EXPORTA
 *   - default              → objeto de sección con id, label, template,
 *                            init() y render().
 *
 * EVENTOS
 *   - Escucha: "section:change"    → re-render al entrar a "papelera".
 *   - Escucha: "datastore:change"  → re-render al cambiar datos.
 */

import { DataStore } from "@core/datastore.js";
import { Permissions } from "@core/permissions.js";
import { Events } from "@core/events.js";
import { $, escapeHTML, formatDate, formatDateTime, sortBy } from "@core/utils.js";
import { Toast } from "@ui/toast.js";
import { Modal } from "@ui/modal.js";

/* ---------------------------------------------------------------------------
 * Estado de filtros
 * ------------------------------------------------------------------------- */

const state = {
    search: "",
    deletedFrom: "",
    deletedTo: "",
};

/* ---------------------------------------------------------------------------
 * Plantilla HTML
 * ------------------------------------------------------------------------- */

const template = `
<section class="page-section" id="section-papelera" data-section="papelera" aria-labelledby="title-papelera" hidden>
    <div class="page-heading">
        <div>
            <div class="eyebrow">RECUPERACIÓN DE DATOS</div>
            <h1 id="title-papelera">Papelera</h1>
            <p>Consulta los registros eliminados y gestiona su posible recuperación.</p>
        </div>
    </div>

    <div class="notice notice-warning">
        <i class="fa-solid fa-triangle-exclamation"></i>
        <div>
            <strong>Zona de recuperación</strong>
            <p>La eliminación definitiva debe estar restringida a usuarios autorizados. Los registros recuperados deben conservar su trazabilidad.</p>
        </div>
    </div>

    <article class="panel">
        <div class="panel-header">
            <div>
                <h2>Registros eliminados</h2>
                <p>Información trasladada a la papelera.</p>
            </div>
            <span class="count-badge" id="trashCount">0 registros</span>
        </div>

        <div class="filters-grid trash-filters">
            <div class="form-field filter-search">
                <label for="trashSearch">Buscar en papelera</label>
                <div class="input-with-icon">
                    <i class="fa-solid fa-magnifying-glass"></i>
                    <input type="search" id="trashSearch" placeholder="Código, título o tipo...">
                </div>
            </div>
            <div class="form-field">
                <label for="trashDeletedFrom">Eliminado desde</label>
                <input type="date" id="trashDeletedFrom">
            </div>
            <div class="form-field">
                <label for="trashDeletedTo">Eliminado hasta</label>
                <input type="date" id="trashDeletedTo">
            </div>
        </div>

        <div class="table-wrapper">
            <table class="data-table">
                <thead>
                    <tr>
                        <th scope="col">Código</th>
                        <th scope="col">Incidencia</th>
                        <th scope="col">Tipo</th>
                        <th scope="col">Fecha del hecho</th>
                        <th scope="col">Eliminado por</th>
                        <th scope="col">Fecha de eliminación</th>
                        <th scope="col">Acciones</th>
                    </tr>
                </thead>
                <tbody id="trashTableBody">
                    <tr>
                        <td colspan="7" class="table-empty">La papelera está vacía.</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </article>
</section>
`;

/* ---------------------------------------------------------------------------
 * Filtrado
 * ------------------------------------------------------------------------- */

function filterTrash() {
    const query = state.search.trim().toLowerCase();

    return DataStore.trash.list().filter((incident) => {
        if (query) {
            const haystack = `${incident.code} ${incident.title || ""} ${incident.type}`.toLowerCase();
            if (!haystack.includes(query)) return false;
        }
        if (state.deletedFrom && incident.deletedAt) {
            if (incident.deletedAt.slice(0, 10) < state.deletedFrom) return false;
        }
        if (state.deletedTo && incident.deletedAt) {
            if (incident.deletedAt.slice(0, 10) > state.deletedTo) return false;
        }
        return true;
    });
}

/* ---------------------------------------------------------------------------
 * Render de la tabla
 * ------------------------------------------------------------------------- */

function renderTable() {
    const list = sortBy(filterTrash(), (incident) => incident.deletedAt || "", "desc");

    const countEl = $("#trashCount");
    if (countEl) {
        countEl.textContent = `${list.length} ${list.length === 1 ? "registro" : "registros"}`;
    }

    const tbody = $("#trashTableBody");
    if (!tbody) return;

    if (!list.length) {
        tbody.innerHTML = `
            <tr>
                <td colspan="7" class="table-empty">La papelera está vacía.</td>
            </tr>
        `;
        return;
    }

    const canRestore = Permissions.can("incident.restore");
    const canDelete = Permissions.can("trash.purge") || Permissions.can("incident.delete");

    tbody.innerHTML = list.map((incident) => {
        const deletedBy = DataStore.users.get(incident.deletedBy);
        return `
            <tr>
                <td><span class="table-code">${escapeHTML(incident.code)}</span></td>
                <td>
                    <span class="table-primary-text">${escapeHTML(incident.title || incident.type)}</span>
                    <span class="table-secondary-text">${escapeHTML((incident.description || "").slice(0, 60))}</span>
                </td>
                <td><span class="category-badge">${escapeHTML(incident.type)}</span></td>
                <td>${formatDate(incident.date)}</td>
                <td>${escapeHTML(deletedBy ? deletedBy.name : "—")}</td>
                <td>${formatDateTime(incident.deletedAt)}</td>
                <td>
                    <div class="table-actions">
                        ${canRestore ? `
                            <button type="button" class="table-action-button" data-restore="${escapeHTML(incident.id)}" title="Restaurar">
                                <i class="fa-solid fa-rotate-left"></i>
                            </button>
                        ` : ""}
                        ${canDelete ? `
                            <button type="button" class="table-action-button danger" data-hard="${escapeHTML(incident.id)}" title="Eliminar definitivamente">
                                <i class="fa-solid fa-trash"></i>
                            </button>
                        ` : ""}
                    </div>
                </td>
            </tr>
        `;
    }).join("");

    bindActions(tbody);
}

function bindActions(root) {
    root.querySelectorAll("[data-restore]").forEach((button) => {
        button.addEventListener("click", () => confirmRestore(button.dataset.restore));
    });
    root.querySelectorAll("[data-hard]").forEach((button) => {
        button.addEventListener("click", () => confirmHardDelete(button.dataset.hard));
    });
}

/* ---------------------------------------------------------------------------
 * Restaurar
 * ------------------------------------------------------------------------- */

function confirmRestore(id) {
    const incident = DataStore.trash.get(id);
    if (!incident) return;

    Modal.confirm({
        title: "Restaurar incidencia",
        message: `¿Deseas restaurar la incidencia ${incident.code}? Volverá al listado general.`,
        confirmLabel: "Restaurar",
        onConfirm: () => {
            DataStore.incidents.restore(id);
            DataStore.audit.log(
                "restore",
                "incident",
                id,
                `Restauración de la incidencia ${incident.code}`
            );
            Toast.success("Incidencia restaurada", `${incident.code} vuelve al listado.`);
            renderTable();
        },
    });
}

/* ---------------------------------------------------------------------------
 * Eliminar definitivamente
 * ------------------------------------------------------------------------- */

function confirmHardDelete(id) {
    const incident = DataStore.trash.get(id);
    if (!incident) return;

    Modal.confirm({
        title: "Eliminar definitivamente",
        message: `¿Eliminar la incidencia ${incident.code}? Esta acción no se puede deshacer.`,
        confirmLabel: "Eliminar definitivamente",
        danger: true,
        onConfirm: () => {
            DataStore.incidents.hardDelete(id);
            DataStore.audit.log(
                "delete",
                "incident",
                id,
                `Eliminación definitiva de la incidencia ${incident.code}`
            );
            Toast.success("Incidencia eliminada definitivamente", incident.code);
            renderTable();
        },
    });
}

/* ---------------------------------------------------------------------------
 * Render
 * ------------------------------------------------------------------------- */

function render() {
    renderTable();
}

/* ---------------------------------------------------------------------------
 * Inicialización
 * ------------------------------------------------------------------------- */

function init() {
    const search = $("#trashSearch");
    if (search) {
        let timer = null;
        search.addEventListener("input", (event) => {
            clearTimeout(timer);
            timer = setTimeout(() => {
                state.search = event.target.value;
                renderTable();
            }, 200);
        });
    }

    const fromInput = $("#trashDeletedFrom");
    if (fromInput) {
        fromInput.addEventListener("change", (event) => {
            state.deletedFrom = event.target.value;
            renderTable();
        });
    }

    const toInput = $("#trashDeletedTo");
    if (toInput) {
        toInput.addEventListener("change", (event) => {
            state.deletedTo = event.target.value;
            renderTable();
        });
    }

    Events.on("section:change", ({ id }) => {
        if (id === "papelera") renderTable();
    });

    Events.on("datastore:change", () => {
        const section = document.getElementById("section-papelera");
        if (section && section.classList.contains("active")) {
            renderTable();
        }
    });
}

/* ---------------------------------------------------------------------------
 * Exportación
 * ------------------------------------------------------------------------- */

export default {
    id: "papelera",
    label: "Papelera",
    template,
    init,
    render,
};