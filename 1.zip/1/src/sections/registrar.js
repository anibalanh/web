/**
 * ============================================================================
 * src/sections/registrar.js
 * ============================================================================
 *
 * PROPÓSITO
 *   Sección "Registrar incidencia": formulario de captura de una nueva
 *   incidencia con validaciones, campos obligatorios claros y guardado
 *   persistente en el DataStore.
 *
 * RESPONSABILIDADES
 *   - Renderizar el formulario organizado en tres bloques (información,
 *     descripción, datos complementarios).
 *   - Rellenar los desplegables de tipo y zona desde el DataStore.
 *   - Validar los campos obligatorios y mostrar errores bajo cada uno.
 *   - Guardar la incidencia, registrar auditoría y notificar al usuario.
 *   - Limpiar el formulario tras guardar o al pulsar "Limpiar".
 *   - Actualizar el contador de caracteres de la descripción.
 *
 * DEPENDENCIAS
 *   - core/datastore.js    → crear incidencia, leer tipos y zonas.
 *   - core/permissions.js  → comprobar capacidad "incident.create".
 *   - core/validators.js   → reglas y esquema de validación.
 *   - core/events.js       → escucha "section:change".
 *   - core/utils.js        → helpers y selección del DOM.
 *   - ui/toast.js          → notificaciones.
 *   - ui/forms.js          → mostrar errores, contador, reset.
 *
 * USADO POR
 *   - main.js              → registra la sección al arrancar.
 *
 * EXPORTA
 *   - default              → objeto de sección con id, label, template,
 *                            init(), render() y reset().
 *
 * EVENTOS
 *   - Escucha: "section:change"    → al entrar a "registrar" refresca
 *                                    desplegables y fecha por defecto.
 *   - Emite indirectamente "datastore:change" a través del DataStore.
 */

import { DataStore } from "@core/datastore.js";
import { Permissions } from "@core/permissions.js";
import { Validators } from "@core/validators.js";
import { Events } from "@core/events.js";
import { $, todayISO } from "@core/utils.js";
import { Toast } from "@ui/toast.js";
import { Forms } from "@ui/forms.js";

/* ---------------------------------------------------------------------------
 * Campos del formulario
 * ------------------------------------------------------------------------- */

const FIELDS = [
    "incidentType",
    "incidentDate",
    "incidentTime",
    "incidentZone",
    "incidentSector",
    "incidentSource",
    "incidentTitle",
    "incidentDescription",
    "incidentPlace",
    "incidentQuantity",
    "incidentObservations",
];

/* ---------------------------------------------------------------------------
 * Plantilla HTML de la sección
 * ------------------------------------------------------------------------- */

const template = `
<section class="page-section" id="section-registrar" data-section="registrar" aria-labelledby="title-registrar" hidden>
    <div class="page-heading">
        <div>
            <div class="eyebrow">CAPTURA DE INFORMACIÓN</div>
            <h1 id="title-registrar">Registrar incidencia</h1>
            <p>Incorpora la información del hecho de forma ordenada y verificable.</p>
        </div>
    </div>

    <form id="incidentForm" class="incident-form" novalidate>
        <div class="form-main-column">

            <article class="panel form-panel">
                <div class="form-section-heading">
                    <span class="form-step">01</span>
                    <div>
                        <h2>Información del incidente</h2>
                        <p>Clasificación y datos principales del registro.</p>
                    </div>
                </div>
                <div class="form-grid">
                    <div class="form-field">
                        <label for="incidentType">Tipo de incidencia <span class="required">*</span></label>
                        <select id="incidentType" name="type" required>
                            <option value="">Seleccionar tipo</option>
                        </select>
                        <small class="field-error" data-error-for="incidentType"></small>
                    </div>
                    <div class="form-field">
                        <label for="incidentDate">Fecha del hecho <span class="required">*</span></label>
                        <input type="date" id="incidentDate" name="date" required>
                        <small class="field-error" data-error-for="incidentDate"></small>
                    </div>
                    <div class="form-field">
                        <label for="incidentTime">Hora aproximada</label>
                        <input type="time" id="incidentTime" name="time">
                        <small class="field-error" data-error-for="incidentTime"></small>
                    </div>
                    <div class="form-field">
                        <label for="incidentZone">Zona <span class="required">*</span></label>
                        <select id="incidentZone" name="zone" required>
                            <option value="">Seleccionar zona</option>
                        </select>
                        <small class="field-error" data-error-for="incidentZone"></small>
                    </div>
                    <div class="form-field">
                        <label for="incidentSector">Sector o referencia</label>
                        <input type="text" id="incidentSector" name="sector" maxlength="150" placeholder="Barrio, sector o referencia">
                    </div>
                    <div class="form-field">
                        <label for="incidentSource">Fuente de información</label>
                        <select id="incidentSource" name="source">
                            <option value="">Seleccionar fuente</option>
                            <option value="Registro directo">Registro directo</option>
                            <option value="Comunicación institucional">Comunicación institucional</option>
                            <option value="Reporte ciudadano">Reporte ciudadano</option>
                            <option value="Documento o informe">Documento o informe</option>
                            <option value="Otro">Otro</option>
                        </select>
                    </div>
                </div>
            </article>

            <article class="panel form-panel">
                <div class="form-section-heading">
                    <span class="form-step">02</span>
                    <div>
                        <h2>Descripción del hecho</h2>
                        <p>Registra información objetiva y evita incluir datos personales innecesarios.</p>
                    </div>
                </div>
                <div class="form-field">
                    <label for="incidentTitle">Título descriptivo <span class="required">*</span></label>
                    <input type="text" id="incidentTitle" name="title" required maxlength="180" placeholder="Resumen breve de la incidencia">
                    <small class="field-error" data-error-for="incidentTitle"></small>
                </div>
                <div class="form-field">
                    <label for="incidentDescription">Descripción <span class="required">*</span></label>
                    <textarea id="incidentDescription" name="description" rows="6" required maxlength="5000" placeholder="Describe los hechos conocidos de manera clara y objetiva."></textarea>
                    <div class="field-meta">
                        <small class="field-error" data-error-for="incidentDescription"></small>
                        <small data-counter-for="incidentDescription">0 / 5000</small>
                    </div>
                </div>
            </article>

            <article class="panel form-panel">
                <div class="form-section-heading">
                    <span class="form-step">03</span>
                    <div>
                        <h2>Datos complementarios</h2>
                        <p>Información adicional útil para clasificar y analizar el registro.</p>
                    </div>
                </div>
                <div class="form-grid">
                    <div class="form-field">
                        <label for="incidentPlace">Lugar o referencia</label>
                        <input type="text" id="incidentPlace" name="place" maxlength="250" placeholder="Referencia general del lugar">
                    </div>
                    <div class="form-field">
                        <label for="incidentQuantity">Número de hechos relacionados</label>
                        <input type="number" id="incidentQuantity" name="quantity" min="1" max="999999" value="1">
                        <small class="field-error" data-error-for="incidentQuantity"></small>
                    </div>
                    <div class="form-field form-field-full">
                        <label for="incidentObservations">Observaciones internas</label>
                        <textarea id="incidentObservations" name="observations" rows="4" maxlength="3000" placeholder="Información complementaria pertinente."></textarea>
                    </div>
                </div>
            </article>
        </div>

        <aside class="form-side-column">
            <article class="panel form-summary-panel">
                <div class="summary-icon">
                    <i class="fa-solid fa-clipboard-check"></i>
                </div>
                <h2>Antes de guardar</h2>
                <p>Comprueba que la información sea correcta y que no se dupliquen registros existentes.</p>
                <ul class="form-checklist">
                    <li><i class="fa-regular fa-circle-check"></i> Tipo y fecha correctos</li>
                    <li><i class="fa-regular fa-circle-check"></i> Zona identificada</li>
                    <li><i class="fa-regular fa-circle-check"></i> Descripción objetiva</li>
                </ul>
                <div class="privacy-note">
                    <i class="fa-solid fa-shield-halved"></i>
                    <span>Evita incorporar contraseñas, documentos de identidad u otros datos personales que no sean necesarios.</span>
                </div>
            </article>

            <div class="form-actions form-actions-stacked">
                <button type="submit" class="button button-primary button-block" id="saveIncidentButton">
                    <i class="fa-solid fa-floppy-disk"></i> Guardar incidencia
                </button>
                <button type="button" class="button button-secondary button-block" id="clearIncidentForm">
                    Limpiar formulario
                </button>
            </div>
        </aside>
    </form>
</section>
`;

/* ---------------------------------------------------------------------------
 * Desplegables dinámicos
 * ------------------------------------------------------------------------- */

function fillSelects() {
    const typeSelect = $("#incidentType");
    const zoneSelect = $("#incidentZone");

    if (typeSelect) {
        const types = DataStore.types.active();
        typeSelect.innerHTML =
            `<option value="">Seleccionar tipo</option>` +
            types.map((t) => `<option value="${escapeOption(t.name)}">${escapeOption(t.name)}</option>`).join("");
    }

    if (zoneSelect) {
        const zones = DataStore.zones.active();
        zoneSelect.innerHTML =
            `<option value="">Seleccionar zona</option>` +
            zones.map((z) => `<option value="${escapeOption(z.name)}">${escapeOption(z.name)}</option>`).join("");
    }
}

function escapeOption(value) {
    return String(value ?? "").replace(/"/g, "&quot;");
}

/* ---------------------------------------------------------------------------
 * Validación
 * ------------------------------------------------------------------------- */

function validateForm() {
    const data = {
        type: Forms.valueOf("incidentType"),
        date: Forms.valueOf("incidentDate"),
        time: Forms.valueOf("incidentTime"),
        zone: Forms.valueOf("incidentZone"),
        title: Forms.valueOf("incidentTitle"),
        description: Forms.valueOf("incidentDescription"),
        quantity: Forms.valueOf("incidentQuantity"),
    };

    const result = Validators.schema(data, Validators.SCHEMAS.incident);

    /* Limpiar errores previos */
    Object.keys(Validators.SCHEMAS.incident).forEach((fieldId) => {
        Forms.setFieldError(`incident${capitalize(fieldId)}`, "");
    });

    /* Mapear errores del esquema a los ids reales del formulario */
    const fieldMap = {
        type: "incidentType",
        date: "incidentDate",
        time: "incidentTime",
        zone: "incidentZone",
        title: "incidentTitle",
        description: "incidentDescription",
        quantity: "incidentQuantity",
    };

    Object.entries(result.errors).forEach(([field, message]) => {
        const id = fieldMap[field] || `incident${capitalize(field)}`;
        Forms.setFieldError(id, message);
    });

    return {
        valid: result.valid,
        data,
    };
}

function capitalize(value) {
    if (!value) return "";
    return value.charAt(0).toUpperCase() + value.slice(1);
}

/* ---------------------------------------------------------------------------
 * Guardado
 * ------------------------------------------------------------------------- */

function handleSubmit(event) {
    event.preventDefault();

    if (!Permissions.can("incident.create")) {
        Toast.error("Acción no permitida", "Tu rol no puede registrar incidencias.");
        return;
    }

    const { valid } = validateForm();
    if (!valid) {
        Toast.warning("Revisa el formulario", "Hay campos obligatorios sin completar o incorrectos.");
        return;
    }

    const record = DataStore.incidents.create({
        type: Forms.valueOf("incidentType"),
        date: Forms.valueOf("incidentDate"),
        time: Forms.valueOf("incidentTime"),
        zone: Forms.valueOf("incidentZone"),
        sector: Forms.valueOf("incidentSector"),
        source: Forms.valueOf("incidentSource"),
        title: Forms.valueOf("incidentTitle"),
        description: Forms.valueOf("incidentDescription"),
        place: Forms.valueOf("incidentPlace"),
        quantity: Number(Forms.valueOf("incidentQuantity") || 1),
        observations: Forms.valueOf("incidentObservations"),
        severity: "",
    });

    DataStore.audit.log(
        "create",
        "incident",
        record.id,
        `Creación de incidencia ${record.code}`,
        { type: record.type, zone: record.zone }
    );

    Toast.success("Incidencia registrada", `Código ${record.code} guardado.`);
    resetForm();
}

/* ---------------------------------------------------------------------------
 * Reset del formulario
 * ------------------------------------------------------------------------- */

function resetForm() {
    const form = document.getElementById("incidentForm");
    if (form) {
        form.reset();
        Forms.clearErrors(form);
    }
    const dateInput = $("#incidentDate");
    if (dateInput) dateInput.value = todayISO();
    const quantityInput = $("#incidentQuantity");
    if (quantityInput) quantityInput.value = "1";
    Forms.updateCounter("incidentDescription");
}

/* ---------------------------------------------------------------------------
 * Render
 * ------------------------------------------------------------------------- */

function render() {
    fillSelects();

    const dateInput = $("#incidentDate");
    if (dateInput && !dateInput.value) {
        dateInput.value = todayISO();
    }

    const quantityInput = $("#incidentQuantity");
    if (quantityInput && !quantityInput.value) {
        quantityInput.value = "1";
    }

    Forms.bindCounters();
}

/* ---------------------------------------------------------------------------
 * Inicialización
 * ------------------------------------------------------------------------- */

function init() {
    fillSelects();

    const form = $("#incidentForm");
    if (form) {
        form.addEventListener("submit", handleSubmit);
    }

    const clearBtn = $("#clearIncidentForm");
    if (clearBtn) {
        clearBtn.addEventListener("click", () => {
            resetForm();
            Toast.info("Formulario limpiado", "Puedes empezar a registrar de nuevo.");
        });
    }

    const dateInput = $("#incidentDate");
    if (dateInput) dateInput.value = todayISO();

    Events.on("section:change", ({ id }) => {
        if (id === "registrar") render();
    });
}

/* ---------------------------------------------------------------------------
 * Exportación
 * ------------------------------------------------------------------------- */

export default {
    id: "registrar",
    label: "Registrar incidencia",
    template,
    init,
    render,
    resetForm,
};