/**
 * ============================================================================
 * src/sections/historial.js
 * ============================================================================
 *
 * PROPÓSITO
 *   Sección "Historial de cambios": auditoría de las operaciones realizadas
 *   sobre los registros del sistema. Muestra un resumen de actividad y el
 *   listado cronológico de eventos, con filtros por usuario, operación y
 *   rango de fechas. Cada evento puede abrirse para ver su detalle.
 *
 * RESPONSABILIDADES
 *   - Mostrar resumen de actividad (total, usuarios activos, último evento).
 *   - Listar los eventos de auditoría ordenados del más reciente al más antiguo.
 *   - Filtrar por texto, tipo de operación y rango de fechas.
 *   - Abrir el detalle de un evento en un modal.
 *   - Reaccionar a cambios en los datos y al entrar a la sección.
 *
 * DEPENDENCIAS
 *   - core/datastore.js    → eventos de auditoría.
 *   - core/session.js      → etiquetas de rol para mostrar.
 *   - core/events.js       → escucha "section:change" y "datastore:change".
 *   - core/utils.js        → helpers de fechas y DOM.
 *   - ui/modal.js          → modal de detalle del evento.
 *
 * USADO POR
 *   - main.js              → registra la sección al arrancar.
 *
 * EXPORTA
 *   - default              → objeto de sección con id, label, template,
 *                            init() y render().
 *
 * EVENTOS
 *   - Escucha: "section:change"    → re-render al entrar a "historial".
 *   - Escucha: "datastore:change"  → re-render al registrarse nuevos eventos.
 */

import { DataStore } from "@core/datastore.js";
import { ROLES } from "@core/session.js";
import { Events } from "@core/events.js";
import { $, escapeHTML, formatDateTime } from "@core/utils.js";
import { Modal } from "@ui/modal.js";

/* ---------------------------------------------------------------------------
 * Estado de filtros
 * ------------------------------------------------------------------------- */

const state = {
    search: "",
    action: "",
    dateFrom: "",
    dateTo: "",
};

/* ---------------------------------------------------------------------------
 * Etiquetas y estilos por tipo de operación
 * ------------------------------------------------------------------------- */

const ACTION_LABELS = {
    create: "Creación",
    update: "Modificación",
    delete: "Eliminación",
    restore: "Restauración",
    import: "Importación",
    admin: "Administración",
    export: "Exportación",
};

const ACTION_CLASSES = {
    create: "success",
    update: "warning",
    delete: "danger",
    restore: "success",
    import: "neutral",
    admin: "neutral",
    export: "neutral",
};

/* ---------------------------------------------------------------------------
 * Plantilla HTML
 * ------------------------------------------------------------------------- */

const template = `
<section class="page-section" id="section-historial" data-section="historial" aria-labelledby="title-historial" hidden>
    <div class="page-heading">
        <div>
            <div class="eyebrow">AUDITORÍA DEL SISTEMA</div>
            <h1 id="title-historial">Historial de cambios</h1>
            <p>Consulta las operaciones realizadas sobre los registros y la configuración.</p>
        </div>
    </div>

    <div class="audit-notice">
        <div class="audit-notice-icon">
            <i class="fa-solid fa-shield-halved"></i>
        </div>
        <div>
            <strong>Trazabilidad de las operaciones</strong>
            <p>Cada evento debe registrar el usuario responsable, la fecha, el tipo de operación y el elemento afectado. El historial no debe poder alterarse libremente desde la interfaz.</p>
        </div>
    </div>

    <div class="audit-summary-grid">
        <article class="audit-summary-card">
            <span>Eventos registrados</span>
            <strong id="auditTotalEvents">0</strong>
        </article>
        <article class="audit-summary-card">
            <span>Usuarios con actividad</span>
            <strong id="auditActiveUsers">0</strong>
        </article>
        <article class="audit-summary-card">
            <span>Último evento</span>
            <strong id="auditLastEvent">—</strong>
        </article>
    </div>

    <article class="panel">
        <div class="panel-header">
            <div>
                <h2>Registro de actividad</h2>
                <p>Eventos ordenados por fecha.</p>
            </div>
        </div>

        <div class="filters-grid audit-filters">
            <div class="form-field filter-search">
                <label for="auditSearch">Buscar actividad</label>
                <div class="input-with-icon">
                    <i class="fa-solid fa-magnifying-glass"></i>
                    <input type="search" id="auditSearch" placeholder="Usuario, acción o elemento...">
                </div>
            </div>
            <div class="form-field">
                <label for="auditActionFilter">Tipo de operación</label>
                <select id="auditActionFilter">
                    <option value="">Todas las operaciones</option>
                    <option value="create">Creación</option>
                    <option value="update">Modificación</option>
                    <option value="delete">Eliminación</option>
                    <option value="restore">Restauración</option>
                    <option value="import">Importación</option>
                    <option value="admin">Administración</option>
                </select>
            </div>
            <div class="form-field">
                <label for="auditDateFrom">Desde</label>
                <input type="date" id="auditDateFrom">
            </div>
            <div class="form-field">
                <label for="auditDateTo">Hasta</label>
                <input type="date" id="auditDateTo">
            </div>
        </div>

        <div class="table-wrapper">
            <table class="data-table">
                <thead>
                    <tr>
                        <th scope="col">Fecha y hora</th>
                        <th scope="col">Usuario</th>
                        <th scope="col">Operación</th>
                        <th scope="col">Elemento</th>
                        <th scope="col">Descripción</th>
                        <th scope="col">Detalle</th>
                    </tr>
                </thead>
                <tbody id="auditTableBody">
                    <tr>
                        <td colspan="6" class="table-empty">No hay eventos de auditoría disponibles.</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </article>
</section>
`;

/* ---------------------------------------------------------------------------
 * Filtrado
 * ------------------------------------------------------------------------- */

function filterEvents() {
    const query = state.search.trim().toLowerCase();

    return DataStore.audit.list().filter((event) => {
        if (query) {
            const haystack = [
                event.userName,
                event.description,
                event.entity,
            ].join(" ").toLowerCase();
            if (!haystack.includes(query)) return false;
        }
        if (state.action && event.action !== state.action) return false;
        if (state.dateFrom && event.timestamp.slice(0, 10) < state.dateFrom) return false;
        if (state.dateTo && event.timestamp.slice(0, 10) > state.dateTo) return false;
        return true;
    });
}

/* ---------------------------------------------------------------------------
 * Render del resumen
 * ------------------------------------------------------------------------- */

function renderSummary() {
    const all = DataStore.audit.list();

    const totalEl = $("#auditTotalEvents");
    if (totalEl) totalEl.textContent = all.length;

    const users = new Set(all.map((event) => event.userName));
    const usersEl = $("#auditActiveUsers");
    if (usersEl) usersEl.textContent = users.size;

    const lastEl = $("#auditLastEvent");
    if (lastEl) {
        lastEl.textContent = all.length
            ? formatDateTime(all[0].timestamp)
            : "—";
    }
}

/* ---------------------------------------------------------------------------
 * Render de la tabla
 * ------------------------------------------------------------------------- */

function renderTable() {
    const list = filterEvents();
    const tbody = $("#auditTableBody");
    if (!tbody) return;

    if (!list.length) {
        tbody.innerHTML = `
            <tr>
                <td colspan="6" class="table-empty">No hay eventos que coincidan con los filtros.</td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = list.slice(0, 200).map((event) => {
        const roleLabel = ROLES[event.userRole]?.label || event.userRole || "";
        const actionLabel = ACTION_LABELS[event.action] || event.action;
        const actionClass = ACTION_CLASSES[event.action] || "neutral";

        return `
            <tr>
                <td>${formatDateTime(event.timestamp)}</td>
                <td>
                    ${escapeHTML(event.userName)}
                    <div class="table-secondary-text">${escapeHTML(roleLabel)}</div>
                </td>
                <td><span class="status-badge ${actionClass}">${escapeHTML(actionLabel)}</span></td>
                <td>${escapeHTML(event.entity)}</td>
                <td>${escapeHTML(event.description)}</td>
                <td>
                    <button type="button"
                            class="table-action-button"
                            data-audit-view="${escapeHTML(event.id)}"
                            title="Ver detalle">
                        <i class="fa-regular fa-eye"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join("");

    tbody.querySelectorAll("[data-audit-view]").forEach((button) => {
        button.addEventListener("click", () => showEventDetail(button.dataset.auditView));
    });
}

/* ---------------------------------------------------------------------------
 * Detalle del evento
 * ------------------------------------------------------------------------- */

function showEventDetail(id) {
    const event = DataStore.audit.list().find((item) => item.id === id);
    if (!event) return;

    const roleLabel = ROLES[event.userRole]?.label || event.userRole || "";
    const actionLabel = ACTION_LABELS[event.action] || event.action;

    const metaKeys = Object.keys(event.meta || {});
    const metaBlock = metaKeys.length
        ? `
            <div class="modal-detail-item full">
                <span>Metadatos</span>
                <strong>${escapeHTML(JSON.stringify(event.meta, null, 2))}</strong>
            </div>
        `
        : "";

    const body = `
        <div class="modal-detail-grid">
            <div class="modal-detail-item">
                <span>Fecha</span>
                <strong>${formatDateTime(event.timestamp)}</strong>
            </div>
            <div class="modal-detail-item">
                <span>Usuario</span>
                <strong>${escapeHTML(event.userName)}</strong>
            </div>
            <div class="modal-detail-item">
                <span>Rol</span>
                <strong>${escapeHTML(roleLabel)}</strong>
            </div>
            <div class="modal-detail-item">
                <span>Operación</span>
                <strong>${escapeHTML(actionLabel)}</strong>
            </div>
            <div class="modal-detail-item">
                <span>Entidad</span>
                <strong>${escapeHTML(event.entity)}</strong>
            </div>
            <div class="modal-detail-item">
                <span>ID afectado</span>
                <strong>${escapeHTML(event.entityId || "—")}</strong>
            </div>
            <div class="modal-detail-item full">
                <span>Descripción</span>
                <strong>${escapeHTML(event.description)}</strong>
            </div>
            ${metaBlock}
        </div>
    `;

    Modal.open({
        eyebrow: "EVENTO DE AUDITORÍA",
        title: event.description,
        body,
    });
}

/* ---------------------------------------------------------------------------
 * Render completo
 * ------------------------------------------------------------------------- */

function render() {
    renderSummary();
    renderTable();
}

/* ---------------------------------------------------------------------------
 * Inicialización
 * ------------------------------------------------------------------------- */

function init() {
    const search = $("#auditSearch");
    if (search) {
        let timer = null;
        search.addEventListener("input", (event) => {
            clearTimeout(timer);
            timer = setTimeout(() => {
                state.search = event.target.value;
                renderTable();
            }, 200);
        });
    }

    const actionFilter = $("#auditActionFilter");
    if (actionFilter) {
        actionFilter.addEventListener("change", (event) => {
            state.action = event.target.value;
            renderTable();
        });
    }

    const fromInput = $("#auditDateFrom");
    if (fromInput) {
        fromInput.addEventListener("change", (event) => {
            state.dateFrom = event.target.value;
            renderTable();
        });
    }

    const toInput = $("#auditDateTo");
    if (toInput) {
        toInput.addEventListener("change", (event) => {
            state.dateTo = event.target.value;
            renderTable();
        });
    }

    Events.on("section:change", ({ id }) => {
        if (id === "historial") render();
    });

    Events.on("datastore:change", () => {
        const section = document.getElementById("section-historial");
        if (section && section.classList.contains("active")) {
            render();
        }
    });
}

/* ---------------------------------------------------------------------------
 * Exportación
 * ------------------------------------------------------------------------- */

export default {
    id: "historial",
    label: "Historial de cambios",
    template,
    init,
    render,
};