/**
 * ============================================================================
 * src/sections/importar.js
 * ============================================================================
 *
 * PROPÓSITO
 *   Sección "Importar datos": carga por lote de incidencias desde archivos
 *   CSV o Excel. Valida columnas, detecta errores y duplicados, y ofrece una
 *   vista previa antes de confirmar la incorporación definitiva.
 *
 * RESPONSABILIDADES
 *   - Aceptar archivos CSV y Excel (drag & drop o selector).
 *   - Leer el contenido con SheetJS y mapear columnas flexibles al modelo
 *     interno de incidencia.
 *   - Validar fila por fila (fecha, tipo, zona, título, descripción).
 *   - Detectar duplicados comparando con los registros existentes.
 *   - Mostrar resumen de validación y vista previa con estado por fila.
 *   - Incorporar las filas válidas y no duplicadas al DataStore.
 *   - Registrar la importación en el historial de auditoría.
 *
 * DEPENDENCIAS
 *   - core/datastore.js    → crear incidencias en lote, tipos, zonas, auditoría.
 *   - core/events.js       → escucha "section:change".
 *   - core/utils.js        → helpers de DOM y fechas.
 *   - ui/toast.js          → notificaciones.
 *   - XLSX (SheetJS)       → lectura de archivos CSV y Excel.
 *
 * USADO POR
 *   - main.js              → registra la sección al arrancar.
 *
 * EXPORTA
 *   - default              → objeto de sección con id, label, template,
 *                            init() y render().
 *
 * EVENTOS
 *   - Escucha: "section:change"    → conserva el estado al entrar.
 */

import { DataStore } from "@core/datastore.js";
import { Events } from "@core/events.js";
import { $, escapeHTML } from "@core/utils.js";
import { Toast } from "@ui/toast.js";

/* ---------------------------------------------------------------------------
 * Estado interno
 * ------------------------------------------------------------------------- */

const state = {
    parsedRows: [],
    validation: null,
};

/* ---------------------------------------------------------------------------
 * Plantilla HTML
 * ------------------------------------------------------------------------- */

const template = `
<section class="page-section" id="section-importar" data-section="importar" aria-labelledby="title-importar" hidden>
    <div class="page-heading">
        <div>
            <div class="eyebrow">CARGA DE INFORMACIÓN</div>
            <h1 id="title-importar">Importar datos</h1>
            <p>Incorpora registros desde archivos tabulares y valida su contenido antes de guardarlos.</p>
        </div>
    </div>

    <div class="import-steps">
        <div class="import-step active">
            <span class="import-step-number">1</span>
            <div>
                <strong>Seleccionar archivo</strong>
                <span>CSV o Excel compatible</span>
            </div>
        </div>
        <div class="import-step">
            <span class="import-step-number">2</span>
            <div>
                <strong>Validar datos</strong>
                <span>Columnas, errores y duplicados</span>
            </div>
        </div>
        <div class="import-step">
            <span class="import-step-number">3</span>
            <div>
                <strong>Confirmar</strong>
                <span>Revisar antes de incorporar</span>
            </div>
        </div>
    </div>

    <article class="panel import-upload-panel">
        <div class="panel-header">
            <div>
                <h2>Archivo de origen</h2>
                <p>La importación no debe modificar registros existentes sin confirmación.</p>
            </div>
        </div>

        <div class="import-dropzone" id="importDropzone" tabindex="0" role="button" aria-label="Seleccionar archivo para importar">
            <input type="file" id="importFile" accept=".csv,.xlsx,.xls" hidden>
            <div class="import-upload-icon">
                <i class="fa-solid fa-cloud-arrow-up"></i>
            </div>
            <h3>Selecciona un archivo para comenzar</h3>
            <p>Arrastra el archivo aquí o pulsa para buscarlo en tu dispositivo.</p>
            <span class="import-file-types">Formatos previstos: CSV y Excel</span>
            <button type="button" class="button button-secondary" id="selectImportFile">
                <i class="fa-solid fa-folder-open"></i> Seleccionar archivo
            </button>
        </div>

        <div id="selectedImportFile" class="selected-import-file" hidden>
            <i class="fa-solid fa-file-csv"></i>
            <div>
                <strong id="importFileName">Archivo seleccionado</strong>
                <span id="importFileSize">Tamaño del archivo</span>
            </div>
            <button type="button" class="icon-button" id="removeImportFile" aria-label="Quitar archivo seleccionado">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>

        <div class="import-format-note">
            <i class="fa-solid fa-circle-info"></i>
            <div>
                <strong>Antes de importar</strong>
                <p>Las columnas deben corresponder a los campos admitidos por el sistema. Los registros importados deben validarse y deduplicarse antes de su incorporación definitiva.</p>
            </div>
        </div>
    </article>

    <article class="panel import-preview-panel">
        <div class="panel-header">
            <div>
                <h2>Revisión de datos</h2>
                <p>Vista previa y validación del contenido del archivo.</p>
            </div>
        </div>

        <div class="import-validation-summary" id="importValidationSummary">
            <div class="validation-item">
                <span>Filas leídas</span>
                <strong id="importRowsRead">0</strong>
            </div>
            <div class="validation-item">
                <span>Filas válidas</span>
                <strong id="importRowsValid">0</strong>
            </div>
            <div class="validation-item">
                <span>Filas con errores</span>
                <strong id="importRowsInvalid">0</strong>
            </div>
            <div class="validation-item">
                <span>Posibles duplicados</span>
                <strong id="importRowsDuplicates">0</strong>
            </div>
        </div>

        <div class="table-wrapper">
            <table class="data-table">
                <thead id="importPreviewHead">
                    <tr>
                        <th scope="col">Estado</th>
                        <th scope="col">Fecha</th>
                        <th scope="col">Tipo</th>
                        <th scope="col">Zona</th>
                        <th scope="col">Descripción</th>
                    </tr>
                </thead>
                <tbody id="importPreviewBody">
                    <tr>
                        <td colspan="5" class="table-empty">Selecciona un archivo para revisar su contenido.</td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="form-actions">
            <button type="button" class="button button-secondary" id="validateImport" disabled>
                <i class="fa-solid fa-list-check"></i> Validar archivo
            </button>
            <button type="button" class="button button-primary" id="confirmImport" disabled>
                <i class="fa-solid fa-database"></i> Confirmar importación
            </button>
        </div>
    </article>
</section>
`;

/* ---------------------------------------------------------------------------
 * Utilidades internas
 * ------------------------------------------------------------------------- */

function setStep(step) {
    document.querySelectorAll(".import-step").forEach((el, index) => {
        el.classList.toggle("active", index === step - 1);
    });
}

function resetCounters() {
    const ids = ["importRowsRead", "importRowsValid", "importRowsInvalid", "importRowsDuplicates"];
    ids.forEach((id) => {
        const el = document.getElementById(id);
        if (el) el.textContent = "0";
    });
}

function readCell(row, ...candidates) {
    const keys = Object.keys(row);
    for (const candidate of candidates) {
        const foundKey = keys.find(
            (key) => key.toLowerCase().trim() === candidate.toLowerCase()
        );
        if (foundKey && row[foundKey] !== "" && row[foundKey] != null) {
            return row[foundKey];
        }
    }
    return "";
}

function mapRow(row) {
    return {
        date: String(readCell(row, "fecha", "date", "fecha del hecho") || "").trim().slice(0, 10),
        time: String(readCell(row, "hora", "time") || "").trim(),
        type: String(readCell(row, "tipo", "type", "categoria", "categoría") || "").trim(),
        zone: String(readCell(row, "zona", "zone", "sector") || "").trim(),
        title: String(readCell(row, "titulo", "título", "title", "asunto") || "").trim(),
        description: String(readCell(row, "descripcion", "descripción", "description", "detalle") || "").trim(),
        severity: String(readCell(row, "clasificacion", "clasificación", "severity", "gravedad") || "").trim(),
        source: String(readCell(row, "fuente", "source") || "").trim(),
    };
}

/* ---------------------------------------------------------------------------
 * Lectura del archivo
 * ------------------------------------------------------------------------- */

function handleFile(file) {
    if (!file) return;

    const name = file.name.toLowerCase();
    const valid = name.endsWith(".csv") || name.endsWith(".xlsx") || name.endsWith(".xls");

    if (!valid) {
        Toast.error("Formato no admitido", "Usa un archivo CSV o Excel.");
        return;
    }

    const fileInfo = $("#selectedImportFile");
    const fileName = $("#importFileName");
    const fileSize = $("#importFileSize");

    if (fileInfo) fileInfo.hidden = false;
    if (fileName) fileName.textContent = file.name;
    if (fileSize) fileSize.textContent = `${(file.size / 1024).toFixed(1)} KB`;

    setStep(2);

    const reader = new FileReader();
    reader.onload = (event) => {
        try {
            const data = event.target.result;
            const workbook = XLSX.read(data, { type: "array" });
            const sheet = workbook.Sheets[workbook.SheetNames[0]];
            const rows = XLSX.utils.sheet_to_json(sheet, { defval: "" });

            state.parsedRows = rows;
            state.validation = null;

            renderPreviewRows(rows);

            const validateBtn = $("#validateImport");
            if (validateBtn) validateBtn.disabled = false;

            const confirmBtn = $("#confirmImport");
            if (confirmBtn) confirmBtn.disabled = true;

            Toast.info("Archivo leído", `${rows.length} filas detectadas.`);
        } catch (error) {
            console.error(error);
            Toast.error("Error al leer el archivo", "Revisa el formato del documento.");
        }
    };
    reader.readAsArrayBuffer(file);
}

/* ---------------------------------------------------------------------------
 * Validación
 * ------------------------------------------------------------------------- */

function validateRows() {
    const incidents = DataStore.incidents.list();
    const existingKeys = new Set(
        incidents.map((incident) => `${incident.date}|${incident.title}`)
    );
    const existingTypeNames = new Set(
        DataStore.types.active().map((type) => type.name.toLowerCase())
    );
    const existingZoneNames = new Set(
        DataStore.zones.active().map((zone) => zone.name.toLowerCase())
    );

    const results = state.parsedRows.map((raw, index) => {
        const mapped = mapRow(raw);
        const errors = [];

        if (!mapped.date || !/^\d{4}-\d{2}-\d{2}$/.test(mapped.date)) {
            errors.push("Fecha inválida");
        }
        if (!mapped.type) errors.push("Falta tipo");
        else if (!existingTypeNames.has(mapped.type.toLowerCase())) {
            errors.push(`Tipo no reconocido: ${mapped.type}`);
        }
        if (!mapped.zone) errors.push("Falta zona");
        else if (!existingZoneNames.has(mapped.zone.toLowerCase())) {
            errors.push(`Zona no reconocida: ${mapped.zone}`);
        }
        if (!mapped.title) errors.push("Falta título");
        if (!mapped.description) errors.push("Falta descripción");

        const key = `${mapped.date}|${mapped.title}`;
        const duplicate = existingKeys.has(key);

        return { index, raw, mapped, errors, duplicate };
    });

    const valid = results.filter((item) => !item.errors.length).length;
    const invalid = results.filter((item) => item.errors.length).length;
    const duplicates = results.filter((item) => !item.errors.length && item.duplicate).length;

    return { results, valid, invalid, duplicates };
}

/* ---------------------------------------------------------------------------
 * Render de la tabla de vista previa
 * ------------------------------------------------------------------------- */

function renderPreviewRows(rows) {
    const tbody = $("#importPreviewBody");
    if (!tbody) return;

    if (!rows.length) {
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="table-empty">El archivo no contiene filas.</td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = rows.slice(0, 50).map((row, index) => {
        const mapped = mapRow(row);
        return `
            <tr>
                <td>#${index + 1}</td>
                <td>${escapeHTML(mapped.date)}</td>
                <td>${escapeHTML(mapped.type)}</td>
                <td>${escapeHTML(mapped.zone)}</td>
                <td>${escapeHTML((mapped.title || mapped.description).slice(0, 60))}</td>
            </tr>
        `;
    }).join("");

    resetCounters();
    const readEl = $("#importRowsRead");
    if (readEl) readEl.textContent = rows.length;

    const validEl = $("#importRowsValid");
    if (validEl) validEl.textContent = "—";
    const invalidEl = $("#importRowsInvalid");
    if (invalidEl) invalidEl.textContent = "—";
    const duplicatesEl = $("#importRowsDuplicates");
    if (duplicatesEl) duplicatesEl.textContent = "—";
}

function renderValidationTable(validation) {
    const tbody = $("#importPreviewBody");
    if (!tbody) return;

    tbody.innerHTML = validation.results.slice(0, 100).map((result) => {
        let badge;
        if (result.errors.length) {
            badge = `<span class="status-badge danger">Error</span>`;
        } else if (result.duplicate) {
            badge = `<span class="status-badge warning">Duplicado</span>`;
        } else {
            badge = `<span class="status-badge success">Válido</span>`;
        }

        const mapped = result.mapped;
        const extra = result.errors.length
            ? `<div class="table-secondary-text" style="color:#c24141">${escapeHTML(result.errors.join(" · "))}</div>`
            : "";

        return `
            <tr>
                <td>${badge}</td>
                <td>${escapeHTML(mapped.date)}</td>
                <td>${escapeHTML(mapped.type)}</td>
                <td>${escapeHTML(mapped.zone)}</td>
                <td>
                    ${escapeHTML((mapped.title || mapped.description || "").slice(0, 60))}
                    ${extra}
                </td>
            </tr>
        `;
    }).join("");
}

/* ---------------------------------------------------------------------------
 * Acciones de validación
 * ------------------------------------------------------------------------- */

function validateImport() {
    if (!state.parsedRows.length) return;

    const validation = validateRows();
    state.validation = validation;

    const readEl = $("#importRowsRead");
    const validEl = $("#importRowsValid");
    const invalidEl = $("#importRowsInvalid");
    const duplicateEl = $("#importRowsDuplicates");

    if (readEl) readEl.textContent = validation.results.length;
    if (validEl) validEl.textContent = validation.valid;
    if (invalidEl) invalidEl.textContent = validation.invalid;
    if (duplicateEl) duplicateEl.textContent = validation.duplicates;

    renderValidationTable(validation);
    setStep(3);

    const confirmBtn = $("#confirmImport");
    if (confirmBtn) confirmBtn.disabled = validation.valid === 0;

    if (validation.valid === 0) {
        Toast.error("Sin filas válidas", "Corrige el archivo antes de importar.");
    } else {
        Toast.success("Validación completada", `${validation.valid} filas listas para importar.`);
    }
}

/* ---------------------------------------------------------------------------
 * Confirmación de la importación
 * ------------------------------------------------------------------------- */

function confirmImport() {
    const validation = state.validation;
    if (!validation || validation.valid === 0) return;

    const usableRows = validation.results
        .filter((result) => !result.errors.length && !result.duplicate)
        .map((result) => ({
            type: result.mapped.type,
            zone: result.mapped.zone,
            date: result.mapped.date,
            time: result.mapped.time,
            title: result.mapped.title,
            description: result.mapped.description,
            severity: result.mapped.severity,
            source: result.mapped.source || "Importación",
            sector: "",
            place: "",
            observations: "",
            quantity: 1,
        }));

    if (!usableRows.length) {
        Toast.warning("Nada que importar", "Todas las filas válidas están marcadas como duplicadas.");
        return;
    }

    DataStore.incidents.bulkCreate(usableRows);
    DataStore.audit.log(
        "import",
        "incident",
        null,
        `Importación de ${usableRows.length} incidencias desde archivo`
    );

    Toast.success("Importación completada", `${usableRows.length} incidencias añadidas.`);

    resetState();
}

/* ---------------------------------------------------------------------------
 * Reset del módulo
 * ------------------------------------------------------------------------- */

function resetState() {
    state.parsedRows = [];
    state.validation = null;

    const fileInfo = $("#selectedImportFile");
    if (fileInfo) fileInfo.hidden = true;

    const input = $("#importFile");
    if (input) input.value = "";

    const tbody = $("#importPreviewBody");
    if (tbody) {
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="table-empty">Selecciona un archivo para revisar su contenido.</td>
            </tr>
        `;
    }

    resetCounters();

    const validateBtn = $("#validateImport");
    if (validateBtn) validateBtn.disabled = true;

    const confirmBtn = $("#confirmImport");
    if (confirmBtn) confirmBtn.disabled = true;

    setStep(1);
}

/* ---------------------------------------------------------------------------
 * Render
 * ------------------------------------------------------------------------- */

function render() {
    if (!state.parsedRows.length) setStep(1);
    else if (!state.validation) setStep(2);
    else setStep(3);
}

/* ---------------------------------------------------------------------------
 * Inicialización
 * ------------------------------------------------------------------------- */

function init() {
    const dropzone = $("#importDropzone");
    const input = $("#importFile");

    if (dropzone && input) {
        dropzone.addEventListener("click", () => input.click());

        dropzone.addEventListener("keydown", (event) => {
            if (event.key === "Enter" || event.key === " ") {
                event.preventDefault();
                input.click();
            }
        });

        dropzone.addEventListener("dragover", (event) => {
            event.preventDefault();
            dropzone.classList.add("dragover");
        });

        dropzone.addEventListener("dragleave", () => {
            dropzone.classList.remove("dragover");
        });

        dropzone.addEventListener("drop", (event) => {
            event.preventDefault();
            dropzone.classList.remove("dragover");
            const file = event.dataTransfer?.files?.[0];
            if (file) handleFile(file);
        });

        input.addEventListener("change", (event) => {
            const file = event.target.files?.[0];
            if (file) handleFile(file);
        });
    }

    const selectBtn = $("#selectImportFile");
    if (selectBtn && input) {
        selectBtn.addEventListener("click", (event) => {
            event.stopPropagation();
            input.click();
        });
    }

    const removeBtn = $("#removeImportFile");
    if (removeBtn) {
        removeBtn.addEventListener("click", (event) => {
            event.stopPropagation();
            resetState();
        });
    }

    const validateBtn = $("#validateImport");
    if (validateBtn) validateBtn.addEventListener("click", validateImport);

    const confirmBtn = $("#confirmImport");
    if (confirmBtn) confirmBtn.addEventListener("click", confirmImport);

    Events.on("section:change", ({ id }) => {
        if (id === "importar") render();
    });
}

/* ---------------------------------------------------------------------------
 * Exportación
 * ------------------------------------------------------------------------- */

export default {
    id: "importar",
    label: "Importar datos",
    template,
    init,
    render,
};