/**
 * ============================================================================
 * src/sections/administracion.js
 * ============================================================================
 *
 * PROPÓSITO
 *   Sección "Administración": gestión de usuarios, zonas, tipos de incidencia,
 *   configuración general y copias de seguridad. Está reservada al rol con
 *   capacidad "admin".
 *
 * RESPONSABILIDADES
 *   - Mostrar pestañas internas: General, Usuarios, Zonas, Tipos y Copias.
 *   - Configurar los datos generales del sistema.
 *   - Gestionar usuarios (crear, editar, eliminar) con roles.
 *   - Gestionar zonas territoriales (crear, editar, eliminar).
 *   - Gestionar tipos de incidencia (crear, editar, eliminar).
 *   - Crear copias de seguridad en JSON y restaurar desde archivo.
 *   - Registrar cada operación en el historial de auditoría.
 *   - Reaccionar a cambios en los datos y al entrar a la sección.
 *
 * DEPENDENCIAS
 *   - core/datastore.js    → usuarios, zonas, tipos, configuración, auditoría.
 *   - core/session.js      → ROLES con etiquetas y capacidades.
 *   - core/permissions.js  → verificación de acceso administrativo.
 *   - core/validators.js   → validación de formularios modales.
 *   - core/events.js       → escucha "section:change" y "datastore:change".
 *   - core/utils.js        → helpers de descarga, DOM, fechas.
 *   - ui/toast.js          → notificaciones.
 *   - ui/modal.js          → formularios y confirmaciones.
 *   - ui/forms.js          → helpers de formularios.
 *
 * USADO POR
 *   - main.js              → registra la sección al arrancar.
 *
 * EXPORTA
 *   - default              → objeto de sección con id, label, template,
 *                            init(), render() y admin: true.
 *
 * EVENTOS
 *   - Escucha: "section:change"    → inicializa la pestaña activa.
 *   - Escucha: "datastore:change"  → refresca la tabla activa.
 */

import { DataStore, STORAGE_KEY } from "@core/datastore.js";
import { ROLES } from "@core/session.js";
import { Permissions } from "@core/permissions.js";
import { Validators } from "@core/validators.js";
import { Events } from "@core/events.js";
import {
    $,
    escapeHTML,
    formatDate,
    todayISO,
    downloadFile,
} from "@core/utils.js";
import { Toast } from "@ui/toast.js";
import { Modal } from "@ui/modal.js";
import { Forms } from "@ui/forms.js";

/* ---------------------------------------------------------------------------
 * Estado interno
 * ------------------------------------------------------------------------- */

const state = {
    activeTab: "general",
};

/* ---------------------------------------------------------------------------
 * Plantilla HTML
 * ------------------------------------------------------------------------- */

const template = `
<section class="page-section" id="section-administracion" data-section="administracion" aria-labelledby="title-administracion" hidden>
    <div class="page-heading">
        <div>
            <div class="eyebrow">CONFIGURACIÓN DEL SISTEMA</div>
            <h1 id="title-administracion">Administración</h1>
            <p>Gestiona los usuarios, las clasificaciones, las zonas y la configuración general.</p>
        </div>
    </div>

    <div class="admin-tabs" role="tablist" aria-label="Opciones de administración">
        <button type="button" class="admin-tab active" id="adminTabGeneral" data-admin-tab="general" role="tab" aria-selected="true" aria-controls="adminPanelGeneral">
            <i class="fa-solid fa-gear"></i> General
        </button>
        <button type="button" class="admin-tab" id="adminTabUsers" data-admin-tab="usuarios" role="tab" aria-selected="false" aria-controls="adminPanelUsers">
            <i class="fa-solid fa-users"></i> Usuarios y roles
        </button>
        <button type="button" class="admin-tab" id="adminTabZones" data-admin-tab="zonas" role="tab" aria-selected="false" aria-controls="adminPanelZones">
            <i class="fa-solid fa-map"></i> Zonas
        </button>
        <button type="button" class="admin-tab" id="adminTabTypes" data-admin-tab="tipos" role="tab" aria-selected="false" aria-controls="adminPanelTypes">
            <i class="fa-solid fa-tags"></i> Tipos de incidencia
        </button>
        <button type="button" class="admin-tab" id="adminTabBackup" data-admin-tab="copias" role="tab" aria-selected="false" aria-controls="adminPanelBackup">
            <i class="fa-solid fa-database"></i> Copias de seguridad
        </button>
    </div>

    <div class="admin-panel active" id="adminPanelGeneral" data-admin-panel="general" role="tabpanel" aria-labelledby="adminTabGeneral">
        <article class="panel">
            <div class="panel-header">
                <div>
                    <h2>Configuración general</h2>
                    <p>Identidad y parámetros básicos del sistema.</p>
                </div>
            </div>
            <form id="generalSettingsForm">
                <div class="form-grid">
                    <div class="form-field">
                        <label for="settingAppName">Nombre del sistema</label>
                        <input type="text" id="settingAppName" value="Huanta Segura" maxlength="100">
                    </div>
                    <div class="form-field">
                        <label for="settingInstitution">Institución responsable</label>
                        <input type="text" id="settingInstitution" maxlength="180" placeholder="Nombre de la institución">
                    </div>
                    <div class="form-field">
                        <label for="settingTimezone">Zona horaria</label>
                        <select id="settingTimezone">
                            <option value="America/Lima">Perú (America/Lima)</option>
                        </select>
                    </div>
                    <div class="form-field">
                        <label for="settingDateFormat">Formato de fecha</label>
                        <select id="settingDateFormat">
                            <option value="dd/mm/yyyy">DD/MM/AAAA</option>
                            <option value="yyyy-mm-dd">AAAA-MM-DD</option>
                        </select>
                    </div>
                </div>
                <div class="form-actions">
                    <button type="submit" class="button button-primary">
                        <i class="fa-solid fa-floppy-disk"></i> Guardar configuración
                    </button>
                </div>
            </form>
        </article>
    </div>

    <div class="admin-panel" id="adminPanelUsers" data-admin-panel="usuarios" role="tabpanel" aria-labelledby="adminTabUsers" hidden>
        <article class="panel">
            <div class="panel-header">
                <div>
                    <h2>Usuarios y permisos</h2>
                    <p>Administra el acceso al sistema según las responsabilidades de cada usuario.</p>
                </div>
                <button type="button" class="button button-primary" id="createUserButton">
                    <i class="fa-solid fa-user-plus"></i> Crear usuario
                </button>
            </div>
            <div class="table-wrapper">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th scope="col">Usuario</th>
                            <th scope="col">Correo electrónico</th>
                            <th scope="col">Rol</th>
                            <th scope="col">Estado</th>
                            <th scope="col">Acciones</th>
                        </tr>
                    </thead>
                    <tbody id="adminUsersTable">
                        <tr>
                            <td colspan="5" class="table-empty">No hay usuarios cargados.</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="notice notice-info">
                <i class="fa-solid fa-circle-info"></i>
                <div>
                    <strong>Control de acceso</strong>
                    <p>La interfaz no sustituye las reglas de seguridad de Firebase. Los permisos deben verificarse también en el servidor.</p>
                </div>
            </div>
        </article>
    </div>

    <div class="admin-panel" id="adminPanelZones" data-admin-panel="zonas" role="tabpanel" aria-labelledby="adminTabZones" hidden>
        <article class="panel">
            <div class="panel-header">
                <div>
                    <h2>Zonas territoriales</h2>
                    <p>Mantén las zonas utilizadas para clasificar las incidencias.</p>
                </div>
                <button type="button" class="button button-primary" id="createZoneButton">
                    <i class="fa-solid fa-plus"></i> Añadir zona
                </button>
            </div>
            <div class="table-wrapper">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th scope="col">Nombre de la zona</th>
                            <th scope="col">Código</th>
                            <th scope="col">Descripción</th>
                            <th scope="col">Estado</th>
                            <th scope="col">Acciones</th>
                        </tr>
                    </thead>
                    <tbody id="adminZonesTable">
                        <tr>
                            <td colspan="5" class="table-empty">No hay zonas configuradas.</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </article>
    </div>

    <div class="admin-panel" id="adminPanelTypes" data-admin-panel="tipos" role="tabpanel" aria-labelledby="adminTabTypes" hidden>
        <article class="panel">
            <div class="panel-header">
                <div>
                    <h2>Tipos de incidencia</h2>
                    <p>Define las categorías disponibles en el formulario de registro.</p>
                </div>
                <button type="button" class="button button-primary" id="createTypeButton">
                    <i class="fa-solid fa-plus"></i> Añadir tipo
                </button>
            </div>
            <div class="table-wrapper">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th scope="col">Nombre</th>
                            <th scope="col">Descripción</th>
                            <th scope="col">Estado</th>
                            <th scope="col">Acciones</th>
                        </tr>
                    </thead>
                    <tbody id="adminTypesTable">
                        <tr>
                            <td colspan="4" class="table-empty">No hay tipos de incidencia configurados.</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </article>
    </div>

    <div class="admin-panel" id="adminPanelBackup" data-admin-panel="copias" role="tabpanel" aria-labelledby="adminTabBackup" hidden>
        <div class="backup-grid">
            <article class="panel backup-card">
                <div class="backup-card-icon">
                    <i class="fa-solid fa-file-export"></i>
                </div>
                <h2>Crear copia de seguridad</h2>
                <p>Prepara una exportación de los datos autorizados para conservar una copia independiente.</p>
                <button type="button" class="button button-primary button-block" id="createBackupButton">
                    Crear copia
                </button>
            </article>
            <article class="panel backup-card">
                <div class="backup-card-icon">
                    <i class="fa-solid fa-file-import"></i>
                </div>
                <h2>Restaurar información</h2>
                <p>Revisa un archivo de respaldo antes de autorizar cualquier restauración.</p>
                <label for="restoreBackupFile" class="button button-secondary button-block">
                    Seleccionar respaldo
                </label>
                <input type="file" id="restoreBackupFile" accept=".json" hidden>
            </article>
        </div>
        <div class="notice notice-warning">
            <i class="fa-solid fa-triangle-exclamation"></i>
            <div>
                <strong>Las copias deben poder verificarse</strong>
                <p>Una descarga desde el navegador no equivale a un respaldo completo de Firebase. La estrategia definitiva deberá contemplar permisos, validación, integridad y recuperación.</p>
            </div>
        </div>
    </div>
</section>
`;

/* ---------------------------------------------------------------------------
 * Pestañas
 * ------------------------------------------------------------------------- */

function openTab(tab) {
    state.activeTab = tab;

    document.querySelectorAll(".admin-tab").forEach((button) => {
        const isActive = button.dataset.adminTab === tab;
        button.classList.toggle("active", isActive);
        button.setAttribute("aria-selected", isActive ? "true" : "false");
    });

    document.querySelectorAll(".admin-panel").forEach((panel) => {
        const isActive = panel.dataset.adminPanel === tab;
        panel.classList.toggle("active", isActive);
        panel.hidden = !isActive;
    });

    if (tab === "general") renderGeneral();
    if (tab === "usuarios") renderUsers();
    if (tab === "zonas") renderZones();
    if (tab === "tipos") renderTypes();
}

/* ---------------------------------------------------------------------------
 * Configuración general
 * ------------------------------------------------------------------------- */

function renderGeneral() {
    const settings = DataStore.settings.get();
    const nameEl = $("#settingAppName");
    const instEl = $("#settingInstitution");
    const tzEl = $("#settingTimezone");
    const dfEl = $("#settingDateFormat");

    if (nameEl) nameEl.value = settings.appName || "";
    if (instEl) instEl.value = settings.institution || "";
    if (tzEl) tzEl.value = settings.timezone || "America/Lima";
    if (dfEl) dfEl.value = settings.dateFormat || "dd/mm/yyyy";
}

function saveGeneral(event) {
    event.preventDefault();
    DataStore.settings.update({
        appName: Forms.valueOf("settingAppName"),
        institution: Forms.valueOf("settingInstitution"),
        timezone: Forms.valueOf("settingTimezone"),
        dateFormat: Forms.valueOf("settingDateFormat"),
    });
    DataStore.audit.log("admin", "settings", null, "Actualización de configuración general");
    Toast.success("Configuración guardada", "Los cambios se aplicaron al sistema.");
}

/* ---------------------------------------------------------------------------
 * Usuarios
 * ------------------------------------------------------------------------- */

function renderUsers() {
    const tbody = $("#adminUsersTable");
    if (!tbody) return;

    const users = DataStore.users.list();
    if (!users.length) {
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="table-empty">No hay usuarios cargados.</td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = users.map((user) => `
        <tr>
            <td>${escapeHTML(user.name)}</td>
            <td>${escapeHTML(user.email)}</td>
            <td><span class="role-badge">${escapeHTML(ROLES[user.role]?.label || user.role)}</span></td>
            <td><span class="status-badge ${user.status === "activo" ? "success" : "neutral"}">${escapeHTML(user.status)}</span></td>
            <td>
                <div class="table-actions">
                    <button type="button" class="table-action-button" data-user-edit="${escapeHTML(user.id)}" title="Editar">
                        <i class="fa-solid fa-pen"></i>
                    </button>
                    <button type="button" class="table-action-button danger" data-user-del="${escapeHTML(user.id)}" title="Eliminar">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join("");

    tbody.querySelectorAll("[data-user-edit]").forEach((button) =>
        button.addEventListener("click", () => openUserForm(button.dataset.userEdit)));
    tbody.querySelectorAll("[data-user-del]").forEach((button) =>
        button.addEventListener("click", () => confirmDeleteUser(button.dataset.userDel)));
}

function openUserForm(id = null) {
    const user = id ? DataStore.users.get(id) : null;

    const body = `
        <form class="modal-form" id="userForm">
            <div class="form-field">
                <label for="userNameField">Nombre completo</label>
                <input type="text" id="userNameField" value="${escapeHTML(user?.name || "")}" required>
            </div>
            <div class="form-field">
                <label for="userEmailField">Correo electrónico</label>
                <input type="email" id="userEmailField" value="${escapeHTML(user?.email || "")}" required>
            </div>
            <div class="form-field">
                <label for="userRoleField">Rol</label>
                <select id="userRoleField">
                    <option value="admin" ${user?.role === "admin" ? "selected" : ""}>Administrador</option>
                    <option value="operario" ${user?.role === "operario" || !user ? "selected" : ""}>Operario</option>
                    <option value="consulta" ${user?.role === "consulta" ? "selected" : ""}>Consulta</option>
                </select>
            </div>
        </form>
    `;

    const footer = `
        <button type="button" class="button button-secondary" data-modal-close>Cancelar</button>
        <button type="button" class="button button-primary" id="saveUserBtn">
            <i class="fa-solid fa-floppy-disk"></i> Guardar
        </button>
    `;

    Modal.open({
        eyebrow: user ? "EDITAR USUARIO" : "NUEVO USUARIO",
        title: user ? user.name : "Crear usuario",
        body,
        footer,
        onMount: ({ footer, close }) => {
            footer.querySelector("#saveUserBtn").addEventListener("click", () => {
                const data = {
                    name: Forms.valueOf("userNameField"),
                    email: Forms.valueOf("userEmailField"),
                    role: Forms.valueOf("userRoleField"),
                };
                const validation = Validators.schema(data, Validators.SCHEMAS.user);
                if (!validation.valid) {
                    Toast.warning("Revisa los datos", "Hay campos obligatorios o inválidos.");
                    return;
                }
                if (user) {
                    DataStore.users.update(user.id, data);
                    DataStore.audit.log("admin", "user", user.id, `Actualización de usuario ${data.name}`);
                } else {
                    const created = DataStore.users.create(data);
                    DataStore.audit.log("admin", "user", created.id, `Creación de usuario ${data.name}`);
                }
                Toast.success("Usuario guardado");
                renderUsers();
                close();
            });
        },
    });
}

function confirmDeleteUser(id) {
    const user = DataStore.users.get(id);
    if (!user) return;

    Modal.confirm({
        title: "Eliminar usuario",
        message: `¿Eliminar al usuario ${user.name}? Esta acción no se puede deshacer.`,
        confirmLabel: "Eliminar",
        danger: true,
        onConfirm: () => {
            DataStore.users.remove(id);
            DataStore.audit.log("admin", "user", id, `Eliminación de usuario ${user.name}`);
            Toast.success("Usuario eliminado");
            renderUsers();
        },
    });
}

/* ---------------------------------------------------------------------------
 * Zonas
 * ------------------------------------------------------------------------- */

function renderZones() {
    const tbody = $("#adminZonesTable");
    if (!tbody) return;

    const zones = DataStore.zones.list();
    if (!zones.length) {
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="table-empty">No hay zonas configuradas.</td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = zones.map((zone) => `
        <tr>
            <td>${escapeHTML(zone.name)}</td>
            <td>${escapeHTML(zone.code)}</td>
            <td>${escapeHTML(zone.description || "—")}</td>
            <td><span class="status-badge ${zone.active ? "success" : "neutral"}">${zone.active ? "Activa" : "Inactiva"}</span></td>
            <td>
                <div class="table-actions">
                    <button type="button" class="table-action-button" data-zone-edit="${escapeHTML(zone.id)}" title="Editar">
                        <i class="fa-solid fa-pen"></i>
                    </button>
                    <button type="button" class="table-action-button danger" data-zone-del="${escapeHTML(zone.id)}" title="Eliminar">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join("");

    tbody.querySelectorAll("[data-zone-edit]").forEach((button) =>
        button.addEventListener("click", () => openZoneForm(button.dataset.zoneEdit)));
    tbody.querySelectorAll("[data-zone-del]").forEach((button) =>
        button.addEventListener("click", () => confirmDeleteZone(button.dataset.zoneDel)));
}

function openZoneForm(id = null) {
    const zone = id ? DataStore.zones.get(id) : null;

    const body = `
        <form class="modal-form" id="zoneForm">
            <div class="form-field">
                <label for="zoneNameField">Nombre</label>
                <input type="text" id="zoneNameField" value="${escapeHTML(zone?.name || "")}" required>
            </div>
            <div class="form-field">
                <label for="zoneCodeField">Código</label>
                <input type="text" id="zoneCodeField" maxlength="6" value="${escapeHTML(zone?.code || "")}">
            </div>
            <div class="form-field">
                <label for="zoneDescriptionField">Descripción</label>
                <textarea id="zoneDescriptionField" rows="3">${escapeHTML(zone?.description || "")}</textarea>
            </div>
        </form>
    `;

    const footer = `
        <button type="button" class="button button-secondary" data-modal-close>Cancelar</button>
        <button type="button" class="button button-primary" id="saveZoneBtn">
            <i class="fa-solid fa-floppy-disk"></i> Guardar
        </button>
    `;

    Modal.open({
        eyebrow: zone ? "EDITAR ZONA" : "NUEVA ZONA",
        title: zone ? zone.name : "Añadir zona",
        body,
        footer,
        onMount: ({ footer, close }) => {
            footer.querySelector("#saveZoneBtn").addEventListener("click", () => {
                const data = {
                    name: Forms.valueOf("zoneNameField"),
                    code: Forms.valueOf("zoneCodeField"),
                    description: Forms.valueOf("zoneDescriptionField"),
                };
                const validation = Validators.schema(data, Validators.SCHEMAS.zone);
                if (!validation.valid) {
                    Toast.warning("Revisa los datos", "Hay campos obligatorios o inválidos.");
                    return;
                }
                if (zone) {
                    DataStore.zones.update(zone.id, data);
                    DataStore.audit.log("admin", "zone", zone.id, `Actualización de zona ${data.name}`);
                } else {
                    const created = DataStore.zones.create(data);
                    DataStore.audit.log("admin", "zone", created.id, `Creación de zona ${data.name}`);
                }
                Toast.success("Zona guardada");
                renderZones();
                close();
            });
        },
    });
}

function confirmDeleteZone(id) {
    const zone = DataStore.zones.get(id);
    if (!zone) return;

    Modal.confirm({
        title: "Eliminar zona",
        message: `¿Eliminar la zona ${zone.name}? Los registros existentes conservarán el nombre.`,
        confirmLabel: "Eliminar",
        danger: true,
        onConfirm: () => {
            DataStore.zones.remove(id);
            DataStore.audit.log("admin", "zone", id, `Eliminación de zona ${zone.name}`);
            Toast.success("Zona eliminada");
            renderZones();
        },
    });
}

/* ---------------------------------------------------------------------------
 * Tipos de incidencia
 * ------------------------------------------------------------------------- */

function renderTypes() {
    const tbody = $("#adminTypesTable");
    if (!tbody) return;

    const types = DataStore.types.list();
    if (!types.length) {
        tbody.innerHTML = `
            <tr>
                <td colspan="4" class="table-empty">No hay tipos configurados.</td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = types.map((type) => `
        <tr>
            <td>${escapeHTML(type.name)}</td>
            <td>${escapeHTML(type.description || "—")}</td>
            <td><span class="status-badge ${type.active ? "success" : "neutral"}">${type.active ? "Activo" : "Inactivo"}</span></td>
            <td>
                <div class="table-actions">
                    <button type="button" class="table-action-button" data-type-edit="${escapeHTML(type.id)}" title="Editar">
                        <i class="fa-solid fa-pen"></i>
                    </button>
                    <button type="button" class="table-action-button danger" data-type-del="${escapeHTML(type.id)}" title="Eliminar">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join("");

    tbody.querySelectorAll("[data-type-edit]").forEach((button) =>
        button.addEventListener("click", () => openTypeForm(button.dataset.typeEdit)));
    tbody.querySelectorAll("[data-type-del]").forEach((button) =>
        button.addEventListener("click", () => confirmDeleteType(button.dataset.typeDel)));
}

function openTypeForm(id = null) {
    const type = id ? DataStore.types.get(id) : null;

    const body = `
        <form class="modal-form" id="typeForm">
            <div class="form-field">
                <label for="typeNameField">Nombre</label>
                <input type="text" id="typeNameField" value="${escapeHTML(type?.name || "")}" required>
            </div>
            <div class="form-field">
                <label for="typeDescriptionField">Descripción</label>
                <textarea id="typeDescriptionField" rows="3">${escapeHTML(type?.description || "")}</textarea>
            </div>
        </form>
    `;

    const footer = `
        <button type="button" class="button button-secondary" data-modal-close>Cancelar</button>
        <button type="button" class="button button-primary" id="saveTypeBtn">
            <i class="fa-solid fa-floppy-disk"></i> Guardar
        </button>
    `;

    Modal.open({
        eyebrow: type ? "EDITAR TIPO" : "NUEVO TIPO",
        title: type ? type.name : "Añadir tipo",
        body,
        footer,
        onMount: ({ footer, close }) => {
            footer.querySelector("#saveTypeBtn").addEventListener("click", () => {
                const data = {
                    name: Forms.valueOf("typeNameField"),
                    description: Forms.valueOf("typeDescriptionField"),
                };
                const validation = Validators.schema(data, Validators.SCHEMAS.type);
                if (!validation.valid) {
                    Toast.warning("Revisa los datos", "Hay campos obligatorios o inválidos.");
                    return;
                }
                if (type) {
                    DataStore.types.update(type.id, data);
                    DataStore.audit.log("admin", "type", type.id, `Actualización de tipo ${data.name}`);
                } else {
                    const created = DataStore.types.create(data);
                    DataStore.audit.log("admin", "type", created.id, `Creación de tipo ${data.name}`);
                }
                Toast.success("Tipo guardado");
                renderTypes();
                close();
            });
        },
    });
}

function confirmDeleteType(id) {
    const type = DataStore.types.get(id);
    if (!type) return;

    Modal.confirm({
        title: "Eliminar tipo",
        message: `¿Eliminar el tipo ${type.name}? Los registros existentes conservarán el nombre.`,
        confirmLabel: "Eliminar",
        danger: true,
        onConfirm: () => {
            DataStore.types.remove(id);
            DataStore.audit.log("admin", "type", id, `Eliminación de tipo ${type.name}`);
            Toast.success("Tipo eliminado");
            renderTypes();
        },
    });
}

/* ---------------------------------------------------------------------------
 * Copias de seguridad
 * ------------------------------------------------------------------------- */

function createBackup() {
    const data = DataStore.getState();
    downloadFile(
        JSON.stringify(data, null, 2),
        `huanta-segura-backup-${todayISO()}.json`,
        "application/json"
    );
    DataStore.audit.log("admin", "backup", null, "Creación de copia de seguridad JSON");
    Toast.success("Copia creada", "Se descargó el archivo JSON con todos los datos.");
}

function restoreBackup(file) {
    if (!file) return;

    Modal.confirm({
        title: "Restaurar respaldo",
        message: "Restaurar reemplazará TODOS los datos actuales. ¿Continuar?",
        confirmLabel: "Restaurar",
        danger: true,
        onConfirm: () => {
            const reader = new FileReader();
            reader.onload = (event) => {
                try {
                    const data = JSON.parse(event.target.result);
                    if (!data || !Array.isArray(data.incidents)) {
                        throw new Error("Estructura inválida");
                    }
                    /* Persistir directamente el estado y recargar */
                    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
                    Toast.success("Respaldo restaurado", "La aplicación se recargará.");
                    setTimeout(() => location.reload(), 900);
                } catch (error) {
                    Toast.error("Error al restaurar", error.message);
                }
            };
            reader.readAsText(file);
        },
    });
}

/* ---------------------------------------------------------------------------
 * Render
 * ------------------------------------------------------------------------- */

function render() {
    if (!Permissions.isAdmin()) {
        Toast.error("Acceso restringido", "Solo un administrador puede abrir esta sección.");
        return;
    }
    openTab(state.activeTab);
}

/* ---------------------------------------------------------------------------
 * Inicialización
 * ------------------------------------------------------------------------- */

function init() {
    document.querySelectorAll("[data-admin-tab]").forEach((button) => {
        button.addEventListener("click", () => openTab(button.dataset.adminTab));
    });

    const settingsForm = $("#generalSettingsForm");
    if (settingsForm) settingsForm.addEventListener("submit", saveGeneral);

    const createUserBtn = $("#createUserButton");
    if (createUserBtn) createUserBtn.addEventListener("click", () => openUserForm());

    const createZoneBtn = $("#createZoneButton");
    if (createZoneBtn) createZoneBtn.addEventListener("click", () => openZoneForm());

    const createTypeBtn = $("#createTypeButton");
    if (createTypeBtn) createTypeBtn.addEventListener("click", () => openTypeForm());

    const backupBtn = $("#createBackupButton");
    if (backupBtn) backupBtn.addEventListener("click", createBackup);

    const restoreInput = $("#restoreBackupFile");
    if (restoreInput) {
        restoreInput.addEventListener("change", (event) => {
            const file = event.target.files?.[0];
            if (file) restoreBackup(file);
            event.target.value = "";
        });
    }

    Events.on("section:change", ({ id }) => {
        if (id === "administracion") {
            if (!Permissions.isAdmin()) {
                Toast.error("Acceso restringido", "Solo un administrador puede abrir Administración.");
                return;
            }
            openTab(state.activeTab);
        }
    });

    Events.on("datastore:change", () => {
        const section = document.getElementById("section-administracion");
        if (!section || !section.classList.contains("active")) return;
        if (state.activeTab === "usuarios") renderUsers();
        if (state.activeTab === "zonas") renderZones();
        if (state.activeTab === "tipos") renderTypes();
    });
}

/* ---------------------------------------------------------------------------
 * Exportación
 * ------------------------------------------------------------------------- */

export default {
    id: "administracion",
    label: "Administración",
    admin: true,
    template,
    init,
    render,
};