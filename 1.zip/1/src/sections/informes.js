/**
 * ============================================================================
 * src/sections/informes.js
 * ============================================================================
 *
 * PROPÓSITO
 *   Sección "Informes": construcción de documentos consolidados con filtros
 *   por rango de fechas, zona y tipo. Permite previsualizar el informe y
 *   exportarlo a impresión/PDF o a CSV según los parámetros elegidos.
 *
 * RESPONSABILIDADES
 *   - Rellenar los desplegables de zona y tipo desde el DataStore.
 *   - Construir la vista previa del informe con secciones seleccionables
 *     (resumen ejecutivo, tablas por tipo, por zona, temporal y detalle).
 *   - Imprimir el informe o descargarlo como CSV.
 *   - Registrar la generación en la auditoría.
 *   - Reaccionar a cambios en los datos y al entrar a la sección.
 *
 * DEPENDENCIAS
 *   - core/datastore.js    → incidencias, tipos, zonas, auditoría.
 *   - core/permissions.js  → capacidad "report.generate".
 *   - core/events.js       → escucha "section:change" y "datastore:change".
 *   - core/utils.js        → helpers de fechas, agrupación, CSV.
 *   - ui/toast.js          → notificaciones.
 *
 * USADO POR
 *   - main.js              → registra la sección al arrancar.
 *
 * EXPORTA
 *   - default              → objeto de sección con id, label, template,
 *                            init() y render().
 *
 * EVENTOS
 *   - Escucha: "section:change"    → re-render al entrar a "informes".
 *   - Escucha: "datastore:change"  → refresca los desplegables si cambian
 *                                    los catálogos de tipos o zonas.
 */

import { DataStore } from "@core/datastore.js";
import { Permissions } from "@core/permissions.js";
import { Events } from "@core/events.js";
import {
    $,
    escapeHTML,
    formatDate,
    formatDateTime,
    groupBy,
    monthKey,
    monthLabel,
    toCSV,
    downloadFile,
    todayISO,
} from "@core/utils.js";
import { Toast } from "@ui/toast.js";

/* ---------------------------------------------------------------------------
 * Plantilla HTML
 * ------------------------------------------------------------------------- */

const template = `
<section class="page-section" id="section-informes" data-section="informes" aria-labelledby="title-informes" hidden>
    <div class="page-heading">
        <div>
            <div class="eyebrow">DOCUMENTACIÓN</div>
            <h1 id="title-informes">Informes</h1>
            <p>Prepara documentos con resultados consolidados para su revisión y presentación.</p>
        </div>
    </div>

    <div class="report-layout">
        <article class="panel report-builder-panel">
            <div class="panel-header">
                <div>
                    <h2>Configurar informe</h2>
                    <p>Selecciona el alcance y contenido del documento.</p>
                </div>
            </div>

            <form id="reportForm">
                <div class="form-grid">
                    <div class="form-field form-field-full">
                        <label for="reportTitle">Título del informe</label>
                        <input type="text" id="reportTitle" maxlength="180"
                               value="Informe de incidencias de seguridad ciudadana" required>
                    </div>
                    <div class="form-field">
                        <label for="reportType">Contenido</label>
                        <select id="reportType">
                            <option value="general">Resumen general</option>
                            <option value="categories">Informe por tipos</option>
                            <option value="zones">Informe por zonas</option>
                            <option value="temporal">Informe temporal</option>
                            <option value="detailed">Listado detallado</option>
                        </select>
                    </div>
                    <div class="form-field">
                        <label for="reportFormat">Formato de salida</label>
                        <select id="reportFormat">
                            <option value="print">Imprimir / guardar como PDF</option>
                            <option value="csv">Exportar tabla CSV</option>
                        </select>
                    </div>
                    <div class="form-field">
                        <label for="reportDateFrom">Fecha inicial</label>
                        <input type="date" id="reportDateFrom">
                    </div>
                    <div class="form-field">
                        <label for="reportDateTo">Fecha final</label>
                        <input type="date" id="reportDateTo">
                    </div>
                    <div class="form-field">
                        <label for="reportZone">Zona</label>
                        <select id="reportZone">
                            <option value="">Todas las zonas</option>
                        </select>
                    </div>
                    <div class="form-field">
                        <label for="reportCategory">Tipo de incidencia</label>
                        <select id="reportCategory">
                            <option value="">Todos los tipos</option>
                        </select>
                    </div>
                </div>

                <div class="report-options">
                    <label class="checkbox-field">
                        <input type="checkbox" id="reportIncludeSummary" checked>
                        <span>Incluir resumen ejecutivo</span>
                    </label>
                    <label class="checkbox-field">
                        <input type="checkbox" id="reportIncludeTables" checked>
                        <span>Incluir tablas de resultados</span>
                    </label>
                    <label class="checkbox-field">
                        <input type="checkbox" id="reportIncludeCharts" checked>
                        <span>Incluir gráficos cuando corresponda</span>
                    </label>
                </div>

                <div class="form-actions">
                    <button type="button" class="button button-secondary" id="previewReport">
                        <i class="fa-regular fa-eye"></i> Generar vista previa
                    </button>
                    <button type="submit" class="button button-primary" id="generateReport">
                        <i class="fa-solid fa-file-export"></i> Generar informe
                    </button>
                </div>
            </form>
        </article>

        <article class="panel report-preview-panel">
            <div class="panel-header">
                <div>
                    <h2>Vista previa</h2>
                    <p>Previsualización del documento generado.</p>
                </div>
            </div>
            <div id="reportPreview" class="report-preview">
                <div class="report-preview-empty">
                    <i class="fa-solid fa-file-circle-check"></i>
                    <h3>Tu informe aparecerá aquí</h3>
                    <p>Define los parámetros y genera una vista previa antes de exportar.</p>
                </div>
            </div>
        </article>
    </div>
</section>
`;

/* ---------------------------------------------------------------------------
 * Filtrado de incidencias según el formulario
 * ------------------------------------------------------------------------- */

function filterIncidents() {
    const from = $("#reportDateFrom")?.value || "";
    const to = $("#reportDateTo")?.value || "";
    const zone = $("#reportZone")?.value || "";
    const type = $("#reportCategory")?.value || "";

    return DataStore.incidents.list().filter((incident) => {
        if (from && incident.date < from) return false;
        if (to && incident.date > to) return false;
        if (zone && incident.zone !== zone) return false;
        if (type && incident.type !== type) return false;
        return true;
    });
}

/* ---------------------------------------------------------------------------
 * Construcción del contenido del informe
 * ------------------------------------------------------------------------- */

function buildReportHTML() {
    const title = $("#reportTitle")?.value.trim() || "Informe de incidencias";
    const kind = $("#reportType")?.value || "general";
    const from = $("#reportDateFrom")?.value || "";
    const to = $("#reportDateTo")?.value || "";
    const zone = $("#reportZone")?.value || "";
    const type = $("#reportCategory")?.value || "";
    const includeSummary = $("#reportIncludeSummary")?.checked ?? true;
    const includeTables = $("#reportIncludeTables")?.checked ?? true;

    const list = filterIncidents();

    const periodText = [
        from ? `Desde ${formatDate(from)}` : "",
        to ? `Hasta ${formatDate(to)}` : "",
    ].filter(Boolean).join(" · ") || "Sin rango de fechas especificado";

    const scopeText = [
        zone ? `Zona: ${zone}` : "",
        type ? `Tipo: ${type}` : "",
    ].filter(Boolean).join(" · ") || "Ámbito completo";

    let sections = "";

    if (includeSummary) {
        const byType = groupBy(list, (incident) => incident.type);
        const byZone = groupBy(list, (incident) => incident.zone);
        const topType = Object.entries(byType).sort((a, b) => b[1].length - a[1].length)[0];
        const topZone = Object.entries(byZone).sort((a, b) => b[1].length - a[1].length)[0];

        sections += `
            <h4>Resumen ejecutivo</h4>
            <p>
                Se registraron <strong>${list.length}</strong> incidencias dentro del ámbito seleccionado.
                ${topType ? `La categoría más frecuente fue <strong>${escapeHTML(topType[0])}</strong> con ${topType[1].length} casos.` : ""}
                ${topZone ? `La zona con más registros fue <strong>${escapeHTML(topZone[0])}</strong> con ${topZone[1].length} casos.` : ""}
            </p>
        `;
    }

    if (includeTables && (kind === "general" || kind === "categories" || kind === "detailed")) {
        const byType = groupBy(list, (incident) => incident.type);
        const rows = Object.entries(byType)
            .map(([name, arr]) => ({ name, count: arr.length }))
            .sort((a, b) => b.count - a.count);

        sections += `
            <h4>Distribución por tipo</h4>
            <table>
                <thead><tr><th>Tipo</th><th>Cantidad</th><th>Porcentaje</th></tr></thead>
                <tbody>
                    ${rows.map((row) => `
                        <tr>
                            <td>${escapeHTML(row.name)}</td>
                            <td>${row.count}</td>
                            <td>${list.length ? Math.round((row.count / list.length) * 100) : 0}%</td>
                        </tr>
                    `).join("") || `<tr><td colspan="3">Sin datos</td></tr>`}
                </tbody>
            </table>
        `;
    }

    if (includeTables && (kind === "general" || kind === "zones")) {
        const byZone = groupBy(list, (incident) => incident.zone);
        const rows = Object.entries(byZone)
            .map(([name, arr]) => ({ name, count: arr.length }))
            .sort((a, b) => b.count - a.count);

        sections += `
            <h4>Distribución por zona</h4>
            <table>
                <thead><tr><th>Zona</th><th>Cantidad</th><th>Porcentaje</th></tr></thead>
                <tbody>
                    ${rows.map((row) => `
                        <tr>
                            <td>${escapeHTML(row.name)}</td>
                            <td>${row.count}</td>
                            <td>${list.length ? Math.round((row.count / list.length) * 100) : 0}%</td>
                        </tr>
                    `).join("") || `<tr><td colspan="3">Sin datos</td></tr>`}
                </tbody>
            </table>
        `;
    }

    if (includeTables && (kind === "general" || kind === "temporal")) {
        const byMonth = groupBy(list, (incident) => monthKey(incident.date));
        const rows = Object.entries(byMonth)
            .map(([key, arr]) => ({ key, count: arr.length }))
            .sort((a, b) => (a.key < b.key ? -1 : 1));

        sections += `
            <h4>Evolución temporal</h4>
            <table>
                <thead><tr><th>Mes</th><th>Cantidad</th></tr></thead>
                <tbody>
                    ${rows.map((row) => `
                        <tr>
                            <td>${monthLabel(row.key)}</td>
                            <td>${row.count}</td>
                        </tr>
                    `).join("") || `<tr><td colspan="2">Sin datos</td></tr>`}
                </tbody>
            </table>
        `;
    }

    if (kind === "detailed") {
        sections += `
            <h4>Listado detallado</h4>
            <table>
                <thead>
                    <tr>
                        <th>Código</th>
                        <th>Fecha</th>
                        <th>Tipo</th>
                        <th>Zona</th>
                        <th>Título</th>
                    </tr>
                </thead>
                <tbody>
                    ${list.slice(0, 200).map((incident) => `
                        <tr>
                            <td>${escapeHTML(incident.code)}</td>
                            <td>${formatDate(incident.date)}</td>
                            <td>${escapeHTML(incident.type)}</td>
                            <td>${escapeHTML(incident.zone)}</td>
                            <td>${escapeHTML(incident.title || "")}</td>
                        </tr>
                    `).join("") || `<tr><td colspan="5">Sin datos</td></tr>`}
                </tbody>
            </table>
        `;
    }

    return `
        <div class="report-document">
            <h3>${escapeHTML(title)}</h3>
            <div class="report-meta">
                ${escapeHTML(periodText)}<br>
                ${escapeHTML(scopeText)}<br>
                Generado: ${formatDateTime(new Date().toISOString())}
            </div>
            ${sections || "<p>No hay contenido para los parámetros seleccionados.</p>"}
        </div>
    `;
}

/* ---------------------------------------------------------------------------
 * Vista previa
 * ------------------------------------------------------------------------- */

function previewReport() {
    if (!Permissions.can("report.generate")) {
        Toast.error("Acción no permitida", "Tu rol no puede generar informes.");
        return;
    }

    const preview = $("#reportPreview");
    if (!preview) return;

    preview.innerHTML = buildReportHTML();
    Toast.info("Vista previa generada", "Revisa el documento antes de exportarlo.");
}

/* ---------------------------------------------------------------------------
 * Generar informe
 * ------------------------------------------------------------------------- */

function generateReport(event) {
    event.preventDefault();

    if (!Permissions.can("report.generate")) {
        Toast.error("Acción no permitida", "Tu rol no puede generar informes.");
        return;
    }

    const format = $("#reportFormat")?.value || "print";

    if (format === "print") {
        const preview = $("#reportPreview");
        if (preview) preview.innerHTML = buildReportHTML();
        DataStore.audit.log(
            "export",
            "report",
            null,
            "Generación de informe para impresión"
        );
        setTimeout(() => window.print(), 220);
    } else if (format === "csv") {
        const list = filterIncidents();
        const rows = [
            ["Código", "Fecha", "Tipo", "Zona", "Título", "Clasificación"],
            ...list.map((incident) => [
                incident.code,
                incident.date,
                incident.type,
                incident.zone,
                incident.title || "",
                incident.severity || "",
            ]),
        ];
        downloadFile(toCSV(rows), `informe-${todayISO()}.csv`);
        DataStore.audit.log(
            "export",
            "report",
            null,
            `Informe CSV (${list.length} registros)`
        );
        Toast.success("Informe exportado", "Se descargó el archivo CSV.");
    }
}

/* ---------------------------------------------------------------------------
 * Filtros dinámicos
 * ------------------------------------------------------------------------- */

function fillFilters() {
    const zoneSelect = $("#reportZone");
    const typeSelect = $("#reportCategory");

    if (zoneSelect) {
        const zones = DataStore.zones.active().map((zone) => zone.name);
        zoneSelect.innerHTML =
            `<option value="">Todas las zonas</option>` +
            zones.map((name) => `<option value="${escapeHTML(name)}">${escapeHTML(name)}</option>`).join("");
    }
    if (typeSelect) {
        const types = DataStore.types.active().map((type) => type.name);
        typeSelect.innerHTML =
            `<option value="">Todos los tipos</option>` +
            types.map((name) => `<option value="${escapeHTML(name)}">${escapeHTML(name)}</option>`).join("");
    }
}

/* ---------------------------------------------------------------------------
 * Render
 * ------------------------------------------------------------------------- */

function render() {
    fillFilters();
}

/* ---------------------------------------------------------------------------
 * Inicialización
 * ------------------------------------------------------------------------- */

function init() {
    fillFilters();

    const previewBtn = $("#previewReport");
    if (previewBtn) previewBtn.addEventListener("click", previewReport);

    const form = $("#reportForm");
    if (form) form.addEventListener("submit", generateReport);

    Events.on("section:change", ({ id }) => {
        if (id === "informes") fillFilters();
    });

    Events.on("datastore:change", () => {
        const section = document.getElementById("section-informes");
        if (section && section.classList.contains("active")) {
            fillFilters();
        }
    });
}

/* ---------------------------------------------------------------------------
 * Exportación
 * ------------------------------------------------------------------------- */

export default {
    id: "informes",
    label: "Informes",
    template,
    init,
    render,
};