/**
 * ============================================================================
 * src/sections/mapa.js
 * ============================================================================
 *
 * PROPÓSITO
 *   Sección "Mapa por zonas": análisis territorial de las incidencias. Muestra
 *   un lienzo esquemático del territorio y un resumen por zona con el volumen
 *   de registros. Permite filtrar por rango de fechas, tipo y zona.
 *
 * RESPONSABILIDADES
 *   - Renderizar el lienzo del mapa y su estado actual.
 *   - Aplicar filtros por fechas, tipo y zona.
 *   - Calcular y mostrar el resumen por zona en orden descendente.
 *   - Reflejar el estado sin datos cuando no hay resultados.
 *   - Reaccionar a cambios en los datos y al entrar a la sección.
 *
 * DEPENDENCIAS
 *   - core/datastore.js    → incidencias, tipos, zonas.
 *   - core/events.js       → escucha "section:change" y "datastore:change".
 *   - core/utils.js        → helpers de agrupación y DOM.
 *   - ui/toast.js          → avisos al aplicar filtros.
 *
 * USADO POR
 *   - main.js              → registra la sección al arrancar.
 *
 * EXPORTA
 *   - default              → objeto de sección con id, label, template,
 *                            init() y render().
 *
 * EVENTOS
 *   - Escucha: "section:change"    → re-render al entrar a "mapa".
 *   - Escucha: "datastore:change"  → re-render al cambiar datos.
 */

import { DataStore } from "@core/datastore.js";
import { Events } from "@core/events.js";
import { $, escapeHTML, groupBy } from "@core/utils.js";
import { Toast } from "@ui/toast.js";

/* ---------------------------------------------------------------------------
 * Estado de la vista
 * ------------------------------------------------------------------------- */

const state = {
    dateFrom: "",
    dateTo: "",
    type: "",
    zone: "",
};

/* ---------------------------------------------------------------------------
 * Plantilla HTML
 * ------------------------------------------------------------------------- */

const template = `
<section class="page-section" id="section-mapa" data-section="mapa" aria-labelledby="title-mapa" hidden>
    <div class="page-heading">
        <div>
            <div class="eyebrow">ANÁLISIS TERRITORIAL</div>
            <h1 id="title-mapa">Mapa por zonas</h1>
            <p>Examina dónde se distribuyen geográficamente las incidencias registradas.</p>
        </div>
    </div>

    <article class="panel map-filters-panel">
        <div class="map-filter-grid">
            <div class="form-field">
                <label for="mapDateFrom">Desde</label>
                <input type="date" id="mapDateFrom">
            </div>
            <div class="form-field">
                <label for="mapDateTo">Hasta</label>
                <input type="date" id="mapDateTo">
            </div>
            <div class="form-field">
                <label for="mapTypeFilter">Tipo de incidencia</label>
                <select id="mapTypeFilter">
                    <option value="">Todos los tipos</option>
                </select>
            </div>
            <div class="form-field">
                <label for="mapZoneFilter">Zona</label>
                <select id="mapZoneFilter">
                    <option value="">Todas las zonas</option>
                </select>
            </div>
            <button type="button" class="button button-primary map-apply-button" id="applyMapFilters">
                <i class="fa-solid fa-filter"></i> Aplicar filtros
            </button>
        </div>
    </article>

    <div class="map-layout">
        <article class="panel map-panel">
            <div class="panel-header">
                <div>
                    <h2>Distribución territorial</h2>
                    <p>Representación de incidencias según su ubicación registrada.</p>
                </div>
                <span class="map-status" id="mapDataStatus">Sin datos geográficos</span>
            </div>
            <div class="map-canvas" id="incidentMap">
                <div class="map-placeholder">
                    <div class="map-placeholder-icon">
                        <i class="fa-solid fa-map-location-dot"></i>
                    </div>
                    <h3>Mapa de incidencias</h3>
                    <p>Aquí se mostrará el mapa territorial cuando se configure una fuente geográfica válida y existan datos de ubicación.</p>
                    <span>La representación geográfica debe basarse en coordenadas o límites de zonas reales.</span>
                </div>
            </div>
            <div class="map-legend">
                <span class="map-legend-title">Referencia</span>
                <span class="map-legend-item">
                    <span class="legend-dot legend-dot-low"></span> Menor concentración
                </span>
                <span class="map-legend-item">
                    <span class="legend-dot legend-dot-medium"></span> Concentración intermedia
                </span>
                <span class="map-legend-item">
                    <span class="legend-dot legend-dot-high"></span> Mayor concentración
                </span>
            </div>
        </article>

        <aside class="panel map-zones-panel">
            <div class="panel-header">
                <div>
                    <h2>Resumen por zona</h2>
                    <p>Registros dentro del filtro actual.</p>
                </div>
            </div>
            <div id="mapZoneSummary" class="map-zone-summary">
                <div class="empty-state-compact">
                    <i class="fa-solid fa-location-dot"></i>
                    <span>El resumen aparecerá al cargar los datos.</span>
                </div>
            </div>
        </aside>
    </div>
</section>
`;

/* ---------------------------------------------------------------------------
 * Filtrado
 * ------------------------------------------------------------------------- */

function filterIncidents() {
    return DataStore.incidents.list().filter((incident) => {
        if (state.dateFrom && incident.date < state.dateFrom) return false;
        if (state.dateTo && incident.date > state.dateTo) return false;
        if (state.type && incident.type !== state.type) return false;
        if (state.zone && incident.zone !== state.zone) return false;
        return true;
    });
}

/* ---------------------------------------------------------------------------
 * Render del resumen por zona
 * ------------------------------------------------------------------------- */

function renderZoneSummary(list) {
    const container = $("#mapZoneSummary");
    if (!container) return;

    const byZone = groupBy(list, (incident) => incident.zone);
    const entries = Object.entries(byZone)
        .map(([name, arr]) => ({ name, count: arr.length }))
        .sort((a, b) => b.count - a.count);

    if (!entries.length) {
        container.innerHTML = `
            <div class="empty-state-compact">
                <i class="fa-solid fa-location-dot"></i>
                <span>No hay incidencias para los filtros aplicados.</span>
            </div>
        `;
        return;
    }

    const max = entries[0]?.count || 1;

    container.innerHTML = entries.map((entry, index) => {
        const percent = max ? Math.round((entry.count / max) * 100) : 0;
        return `
            <div class="map-zone-row">
                <span class="map-zone-rank">${index + 1}</span>
                <div class="map-zone-info">
                    <strong>${escapeHTML(entry.name)}</strong>
                    <span>${percent}% del máximo registrado</span>
                </div>
                <span class="map-zone-count">${entry.count}</span>
            </div>
        `;
    }).join("");
}

/* ---------------------------------------------------------------------------
 * Estado del panel superior
 * ------------------------------------------------------------------------- */

function renderStatus(list) {
    const statusEl = $("#mapDataStatus");
    if (!statusEl) return;
    statusEl.textContent = list.length
        ? `${list.length} incidencias analizadas`
        : "Sin datos geográficos";
}

/* ---------------------------------------------------------------------------
 * Filtros
 * ------------------------------------------------------------------------- */

function fillFilters() {
    const typeSelect = $("#mapTypeFilter");
    const zoneSelect = $("#mapZoneFilter");

    if (typeSelect) {
        const types = DataStore.types.active().map((type) => type.name);
        typeSelect.innerHTML =
            `<option value="">Todos los tipos</option>` +
            types.map((name) => `<option value="${escapeHTML(name)}">${escapeHTML(name)}</option>`).join("");
    }
    if (zoneSelect) {
        const zones = DataStore.zones.active().map((zone) => zone.name);
        zoneSelect.innerHTML =
            `<option value="">Todas las zonas</option>` +
            zones.map((name) => `<option value="${escapeHTML(name)}">${escapeHTML(name)}</option>`).join("");
    }
}

/* ---------------------------------------------------------------------------
 * Render completo
 * ------------------------------------------------------------------------- */

function render() {
    const list = filterIncidents();
    renderStatus(list);
    renderZoneSummary(list);
}

/* ---------------------------------------------------------------------------
 * Inicialización
 * ------------------------------------------------------------------------- */

function init() {
    fillFilters();

    const applyBtn = $("#applyMapFilters");
    if (applyBtn) {
        applyBtn.addEventListener("click", () => {
            state.dateFrom = $("#mapDateFrom")?.value || "";
            state.dateTo = $("#mapDateTo")?.value || "";
            state.type = $("#mapTypeFilter")?.value || "";
            state.zone = $("#mapZoneFilter")?.value || "";
            render();
            Toast.info("Mapa actualizado", "Se aplicaron los filtros seleccionados.");
        });
    }

    Events.on("section:change", ({ id }) => {
        if (id === "mapa") {
            fillFilters();
            render();
        }
    });

    Events.on("datastore:change", () => {
        const section = document.getElementById("section-mapa");
        if (section && section.classList.contains("active")) {
            render();
        }
    });
}

/* ---------------------------------------------------------------------------
 * Exportación
 * ------------------------------------------------------------------------- */

export default {
    id: "mapa",
    label: "Mapa por zonas",
    template,
    init,
    render,
};