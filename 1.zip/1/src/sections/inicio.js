/**
 * ============================================================================
 * src/sections/inicio.js
 * ============================================================================
 *
 * PROPÓSITO
 *   Sección "Inicio": panel general con indicadores clave, evolución reciente
 *   de incidencias, distribución por tipo y últimas incidencias registradas.
 *   Resume el estado actual del sistema sin duplicar el análisis detallado
 *   que corresponde a la sección "Estadísticas".
 *
 * RESPONSABILIDADES
 *   - Mostrar 4 métricas: total, periodo actual, tipos y zonas con registros.
 *   - Dibujar gráfico de evolución de los últimos 6 o 12 meses (Chart.js).
 *   - Dibujar gráfico de dona con distribución por tipo.
 *   - Listar las últimas incidencias con acceso al detalle.
 *   - Reaccionar a cambios en los datos y al entrar a la sección.
 *
 * DEPENDENCIAS
 *   - core/datastore.js    → incidencias y usuarios.
 *   - core/events.js       → escucha "section:change" y "datastore:change".
 *   - core/utils.js        → helpers de fechas, agrupación, DOM.
 *   - ui/toast.js          → avisos al actualizar.
 *   - sections/registros.js → abre el detalle de una incidencia (modal).
 *
 * USADO POR
 *   - main.js              → registra la sección al arrancar.
 *
 * EXPORTA
 *   - default              → objeto de la sección con id, label, template,
 *                            init() y render().
 *
 * EVENTOS
 *   - Escucha: "section:change"    → re-render al entrar a "inicio".
 *   - Escucha: "datastore:change"  → re-render al cambiar datos.
 */

import { DataStore } from "@core/datastore.js";
import { Events } from "@core/events.js";
import {
    $,
    escapeHTML,
    formatDate,
    groupBy,
    monthKey,
    monthLabel,
    sortBy,
} from "@core/utils.js";
import { Toast } from "@ui/toast.js";
import Registros from "@sections/registros.js";

/* ---------------------------------------------------------------------------
 * Configuración
 * ------------------------------------------------------------------------- */

const PALETTE = [
    "#4f46e5",
    "#7c3aed",
    "#15805d",
    "#a96710",
    "#c24141",
    "#3677db",
    "#087e8b",
    "#8994a7",
];

/* ---------------------------------------------------------------------------
 * Estado interno de los gráficos
 * ------------------------------------------------------------------------- */

let trendChart = null;
let categoryChart = null;

/* ---------------------------------------------------------------------------
 * Plantilla HTML de la sección
 * ------------------------------------------------------------------------- */

const template = `
<section class="page-section active" id="section-inicio" data-section="inicio" aria-labelledby="title-inicio">
    <div class="page-heading">
        <div>
            <div class="eyebrow">CENTRO DE INFORMACIÓN</div>
            <h1 id="title-inicio">Inicio</h1>
            <p>Panorama general de las incidencias registradas en Huanta.</p>
        </div>
        <div class="page-heading-actions">
            <button type="button" class="button button-secondary" data-action="refresh-dashboard">
                <i class="fa-solid fa-arrows-rotate"></i> Actualizar
            </button>
            <a href="#registrar" class="button button-primary" data-section-link="registrar">
                <i class="fa-solid fa-plus"></i> Nueva incidencia
            </a>
        </div>
    </div>

    <div class="metrics-grid">
        <article class="metric-card">
            <div class="metric-top">
                <span class="metric-label">Incidencias registradas</span>
                <span class="metric-icon metric-icon-blue">
                    <i class="fa-solid fa-file-lines"></i>
                </span>
            </div>
            <div class="metric-value" id="metricTotal">0</div>
            <div class="metric-foot">
                <span class="metric-description">Total de registros almacenados</span>
            </div>
        </article>

        <article class="metric-card">
            <div class="metric-top">
                <span class="metric-label">Periodo actual</span>
                <span class="metric-icon metric-icon-violet">
                    <i class="fa-regular fa-calendar"></i>
                </span>
            </div>
            <div class="metric-value" id="metricCurrentPeriod">0</div>
            <div class="metric-foot">
                <span class="metric-description">Incidencias del mes en curso</span>
            </div>
        </article>

        <article class="metric-card">
            <div class="metric-top">
                <span class="metric-label">Tipos registrados</span>
                <span class="metric-icon metric-icon-amber">
                    <i class="fa-solid fa-layer-group"></i>
                </span>
            </div>
            <div class="metric-value" id="metricTypes">0</div>
            <div class="metric-foot">
                <span class="metric-description">Categorías con incidencias</span>
            </div>
        </article>

        <article class="metric-card">
            <div class="metric-top">
                <span class="metric-label">Zonas con registros</span>
                <span class="metric-icon metric-icon-green">
                    <i class="fa-solid fa-location-dot"></i>
                </span>
            </div>
            <div class="metric-value" id="metricZones">0</div>
            <div class="metric-foot">
                <span class="metric-description">Zonas que presentan incidencias registradas</span>
            </div>
        </article>
    </div>

    <div class="dashboard-grid">
        <article class="panel dashboard-trend-panel">
            <div class="panel-header">
                <div>
                    <h2>Evolución reciente</h2>
                    <p>Variación de registros por periodo.</p>
                </div>
                <a href="#estadisticas" class="text-link" data-section-link="estadisticas">
                    Ver estadísticas <i class="fa-solid fa-arrow-right"></i>
                </a>
            </div>
            <div class="chart-toolbar">
                <span class="chart-legend">
                    <span class="legend-dot legend-dot-primary"></span>
                    Incidencias registradas
                </span>
                <label class="visually-hidden" for="dashboardTrendPeriod">
                    Periodo del gráfico
                </label>
                <select id="dashboardTrendPeriod" class="select-control">
                    <option value="6">Últimos 6 meses</option>
                    <option value="12">Últimos 12 meses</option>
                </select>
            </div>
            <div class="chart-container chart-container-large" id="dashboardTrendChart" aria-label="Gráfico de evolución de incidencias">
                <div class="empty-chart">
                    <i class="fa-solid fa-chart-line"></i>
                    <span>El gráfico aparecerá cuando se carguen los datos.</span>
                </div>
            </div>
        </article>

        <article class="panel dashboard-categories-panel">
            <div class="panel-header">
                <div>
                    <h2>Distribución por tipo</h2>
                    <p>Composición de las incidencias registradas.</p>
                </div>
            </div>
            <div class="chart-container chart-container-donut" id="dashboardCategoryChart" aria-label="Distribución de incidencias por tipo">
                <div class="empty-chart">
                    <i class="fa-solid fa-chart-pie"></i>
                    <span>Sin datos para mostrar.</span>
                </div>
            </div>
            <div class="chart-legend-list" id="dashboardCategoryLegend"></div>
        </article>
    </div>

    <article class="panel">
        <div class="panel-header">
            <div>
                <h2>Últimas incidencias registradas</h2>
                <p>Los registros incorporados más recientemente.</p>
            </div>
            <a href="#registros" class="button button-secondary button-small" data-section-link="registros">
                Ver todos los registros <i class="fa-solid fa-arrow-right"></i>
            </a>
        </div>
        <div class="table-wrapper">
            <table class="data-table">
                <thead>
                    <tr>
                        <th scope="col">Código</th>
                        <th scope="col">Tipo de incidencia</th>
                        <th scope="col">Zona</th>
                        <th scope="col">Fecha</th>
                        <th scope="col">Operario</th>
                        <th scope="col">Acciones</th>
                    </tr>
                </thead>
                <tbody id="dashboardRecentRecords">
                    <tr>
                        <td colspan="6" class="table-empty">No hay incidencias registradas.</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </article>
</section>
`;

/* ---------------------------------------------------------------------------
 * Render: métricas
 * ------------------------------------------------------------------------- */

function renderMetrics() {
    const incidents = DataStore.incidents.list();
    const now = new Date();
    const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;

    const monthCount = incidents.filter((inc) => monthKey(inc.date) === currentMonth).length;
    const typesCount = new Set(incidents.map((inc) => inc.type)).size;
    const zonesCount = new Set(incidents.map((inc) => inc.zone)).size;

    const elTotal = $("#metricTotal");
    const elPeriod = $("#metricCurrentPeriod");
    const elTypes = $("#metricTypes");
    const elZones = $("#metricZones");

    if (elTotal) elTotal.textContent = incidents.length;
    if (elPeriod) elPeriod.textContent = monthCount;
    if (elTypes) elTypes.textContent = typesCount;
    if (elZones) elZones.textContent = zonesCount;
}

/* ---------------------------------------------------------------------------
 * Render: gráfico de evolución
 * ------------------------------------------------------------------------- */

function renderTrend() {
    const container = $("#dashboardTrendChart");
    if (!container) return;

    const monthsInput = $("#dashboardTrendPeriod");
    const months = Number(monthsInput?.value || 6);
    const incidents = DataStore.incidents.list();

    const keys = [];
    const now = new Date();
    for (let i = months - 1; i >= 0; i--) {
        const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
        keys.push(`${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`);
    }

    const counts = keys.map((key) =>
        incidents.filter((inc) => monthKey(inc.date) === key).length
    );

    container.innerHTML = '<canvas></canvas>';
    const canvas = container.querySelector("canvas");
    if (!canvas) return;

    if (trendChart) {
        trendChart.destroy();
        trendChart = null;
    }

    trendChart = new Chart(canvas, {
        type: "line",
        data: {
            labels: keys.map(monthLabel),
            datasets: [{
                label: "Incidencias",
                data: counts,
                borderColor: "#4f46e5",
                backgroundColor: "rgba(79, 70, 229, 0.10)",
                borderWidth: 2,
                tension: 0.35,
                fill: true,
                pointRadius: 3,
                pointBackgroundColor: "#4f46e5",
            }],
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: {
                    grid: { display: false },
                    ticks: { color: "#8a94a6", font: { size: 10 } },
                },
                y: {
                    beginAtZero: true,
                    ticks: { color: "#8a94a6", font: { size: 10 }, precision: 0 },
                    grid: { color: "#eef1f6" },
                },
            },
        },
    });
}

/* ---------------------------------------------------------------------------
 * Render: gráfico de dona y leyenda
 * ------------------------------------------------------------------------- */

function renderCategories() {
    const container = $("#dashboardCategoryChart");
    const legendEl = $("#dashboardCategoryLegend");
    if (!container || !legendEl) return;

    const incidents = DataStore.incidents.list();
    const byType = groupBy(incidents, (inc) => inc.type);
    const entries = Object.entries(byType)
        .map(([name, list]) => ({ name, count: list.length }))
        .sort((a, b) => b.count - a.count);

    if (!entries.length) {
        container.innerHTML = `
            <div class="empty-chart">
                <i class="fa-solid fa-chart-pie"></i>
                <span>Sin datos para mostrar.</span>
            </div>
        `;
        legendEl.innerHTML = "";
        if (categoryChart) { categoryChart.destroy(); categoryChart = null; }
        return;
    }

    container.innerHTML = '<canvas></canvas>';
    const canvas = container.querySelector("canvas");
    if (!canvas) return;

    if (categoryChart) {
        categoryChart.destroy();
        categoryChart = null;
    }

    categoryChart = new Chart(canvas, {
        type: "doughnut",
        data: {
            labels: entries.map((entry) => entry.name),
            datasets: [{
                data: entries.map((entry) => entry.count),
                backgroundColor: entries.map((_, index) => PALETTE[index % PALETTE.length]),
                borderWidth: 2,
                borderColor: "#fff",
            }],
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: "62%",
            plugins: { legend: { display: false } },
        },
    });

    legendEl.innerHTML = entries.map((entry, index) => `
        <div class="chart-legend-row">
            <span class="legend-dot" style="background:${PALETTE[index % PALETTE.length]}"></span>
            <span class="chart-legend-name">${escapeHTML(entry.name)}</span>
            <span class="chart-legend-value">${entry.count}</span>
        </div>
    `).join("");
}

/* ---------------------------------------------------------------------------
 * Render: últimas incidencias
 * ------------------------------------------------------------------------- */

function renderRecent() {
    const tbody = $("#dashboardRecentRecords");
    if (!tbody) return;

    const incidents = sortBy(
        DataStore.incidents.list(),
        (inc) => inc.createdAt,
        "desc"
    ).slice(0, 6);

    if (!incidents.length) {
        tbody.innerHTML = `
            <tr>
                <td colspan="6" class="table-empty">No hay incidencias registradas.</td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = incidents.map((inc) => {
        const user = DataStore.users.get(inc.createdBy);
        return `
            <tr>
                <td><span class="table-code">${escapeHTML(inc.code)}</span></td>
                <td>
                    <span class="table-primary-text">${escapeHTML(inc.title || inc.type)}</span>
                    <span class="table-secondary-text">${escapeHTML(inc.type)}</span>
                </td>
                <td>${escapeHTML(inc.zone)}</td>
                <td>${formatDate(inc.date)}</td>
                <td>${escapeHTML(user ? user.name : "—")}</td>
                <td>
                    <div class="table-actions">
                        <button type="button"
                                class="table-action-button"
                                data-home-view="${escapeHTML(inc.id)}"
                                title="Ver detalle">
                            <i class="fa-regular fa-eye"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    }).join("");

    tbody.querySelectorAll("[data-home-view]").forEach((button) => {
        button.addEventListener("click", () => {
            const id = button.dataset.homeView;
            if (typeof Registros.openDetail === "function") {
                Registros.openDetail(id);
            }
        });
    });
}

/* ---------------------------------------------------------------------------
 * Render completo
 * ------------------------------------------------------------------------- */

function render() {
    renderMetrics();
    renderTrend();
    renderCategories();
    renderRecent();
}

/* ---------------------------------------------------------------------------
 * Inicialización
 * ------------------------------------------------------------------------- */

function init() {
    const periodSelect = $("#dashboardTrendPeriod");
    if (periodSelect) {
        periodSelect.addEventListener("change", renderTrend);
    }

    const refreshButton = document.querySelector('[data-action="refresh-dashboard"]');
    if (refreshButton) {
        refreshButton.addEventListener("click", () => {
            render();
            Toast.info("Panel actualizado", "Los indicadores se recalcularon.");
        });
    }

    Events.on("section:change", ({ id }) => {
        if (id === "inicio") render();
    });
}

/* ---------------------------------------------------------------------------
 * Exportación
 * ------------------------------------------------------------------------- */

export default {
    id: "inicio",
    label: "Inicio",
    template,
    init,
    render,
};