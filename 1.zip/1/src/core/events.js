/**
 * ============================================================================
 * src/core/events.js
 * ============================================================================
 *
 * PROPÓSITO
 *   Bus de eventos interno de la aplicación. Permite que distintos módulos
 *   se comuniquen sin conocerse directamente, evitando dependencias cruzadas.
 *
 * RESPONSABILIDADES
 *   - Registrar manejadores para eventos con nombre.
 *   - Emitir eventos con datos adjuntos.
 *   - Permitir desuscribirse de un evento.
 *   - Mantener una única instancia del bus en toda la aplicación.
 *
 * DEPENDENCIAS
 *   - Ninguna. Módulo independiente.
 *
 * USADO POR
 *   - core/datastore.js    → emite "datastore:change".
 *   - core/session.js      → emite "session:change".
 *   - core/router.js       → emite "section:change".
 *   - Secciones y UI       → escuchan eventos para reaccionar.
 *
 * EXPORTA
 *   - Events (objeto con métodos on, off, once, emit, clear).
 *
 * EVENTOS EMITIDOS (nombres reservados en el sistema)
 *   - "datastore:change"   → cambió la información almacenada.
 *   - "session:change"     → cambió el usuario o el rol activo.
 *   - "section:change"     → cambió la sección visible.
 *   - "modal:open"         → se abrió el modal genérico.
 *   - "modal:close"        → se cerró el modal genérico.
 */

const listeners = new Map();

/**
 * Registra un manejador para un evento.
 * Devuelve una función para cancelar la suscripción.
 */
function on(eventName, handler) {
    if (typeof handler !== "function") return () => {};
    if (!listeners.has(eventName)) listeners.set(eventName, new Set());
    listeners.get(eventName).add(handler);
    return () => off(eventName, handler);
}

/**
 * Elimina un manejador previamente registrado.
 */
function off(eventName, handler) {
    const set = listeners.get(eventName);
    if (!set) return;
    set.delete(handler);
    if (set.size === 0) listeners.delete(eventName);
}

/**
 * Registra un manejador que se ejecuta una sola vez.
 */
function once(eventName, handler) {
    const unsubscribe = on(eventName, (payload) => {
        unsubscribe();
        handler(payload);
    });
    return unsubscribe;
}

/**
 * Emite un evento con datos adjuntos.
 */
function emit(eventName, payload = null) {
    const set = listeners.get(eventName);
    if (!set) return;
    set.forEach((handler) => {
        try {
            handler(payload);
        } catch (error) {
            console.error(`Error en manejador del evento "${eventName}":`, error);
        }
    });
}

/**
 * Elimina todos los manejadores de un evento,
 * o todos los eventos si no se especifica nombre.
 */
function clear(eventName = null) {
    if (eventName) {
        listeners.delete(eventName);
    } else {
        listeners.clear();
    }
}

export const Events = {
    on,
    off,
    once,
    emit,
    clear,
};