/**
 * ============================================================================
 * src/core/utils.js
 * ============================================================================
 *
 * PROPÓSITO
 *   Funciones auxiliares reutilizables en toda la aplicación: selección del
 *   DOM, formato de fechas, manipulación de cadenas, generación de
 *   identificadores, exportación de archivos y utilidades de colecciones.
 *
 * RESPONSABILIDADES
 *   - Atajos de selección del DOM ($ y $$).
 *   - Escapado de HTML para plantillas seguras.
 *   - Formateo de fechas y horas en español.
 *   - Generación de identificadores únicos.
 *   - Conversión de arreglos a CSV y descarga de archivos.
 *   - Helpers de colecciones: groupBy, sortBy, sum, clamp.
 *
 * DEPENDENCIAS
 *   - Ninguna. Es un módulo de utilidades puras.
 *
 * USADO POR
 *   - Prácticamente todos los módulos del proyecto.
 *
 * EXPORTA
 *   - $, $$, escapeHTML, buildInitials, uid, todayISO, formatDate,
 *     formatDateTime, monthKey, monthLabel, debounce, throttle, toCSV,
 *     downloadFile, clamp, sum, groupBy, sortBy.
 *
 * EVENTOS
 *   - Ninguno.
 */

/* ---------------------------------------------------------------------------
 * Selección del DOM
 * ------------------------------------------------------------------------- */

export const $ = (selector, context = document) => context.querySelector(selector);
export const $$ = (selector, context = document) => Array.from(context.querySelectorAll(selector));

/* ---------------------------------------------------------------------------
 * Cadenas y seguridad
 * ------------------------------------------------------------------------- */

export function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, (char) => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;",
    }[char]));
}

export function buildInitials(name) {
    if (!name) return "??";
    return String(name)
        .trim()
        .split(/\s+/)
        .map((part) => part[0])
        .slice(0, 2)
        .join("")
        .toUpperCase();
}

/* ---------------------------------------------------------------------------
 * Identificadores
 * ------------------------------------------------------------------------- */

export function uid(prefix = "id") {
    const time = Date.now().toString(36);
    const random = Math.random().toString(36).slice(2, 8);
    return `${prefix}_${time}_${random}`;
}

/* ---------------------------------------------------------------------------
 * Fechas
 * ------------------------------------------------------------------------- */

export function todayISO() {
    return new Date().toISOString().slice(0, 10);
}

export function formatDate(iso) {
    if (!iso) return "—";
    const [year, month, day] = String(iso).split("-");
    if (!year || !month || !day) return iso;
    return `${day}/${month}/${year}`;
}

export function formatDateTime(iso) {
    if (!iso) return "—";
    const date = new Date(iso);
    if (Number.isNaN(date.getTime())) return iso;
    return date.toLocaleString("es-PE", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
    });
}

export function monthKey(iso) {
    if (!iso) return "";
    return String(iso).slice(0, 7);
}

export function monthLabel(key) {
    if (!key) return "";
    const [year, month] = String(key).split("-");
    const names = ["Ene", "Feb", "Mar", "Abr", "May", "Jun",
                   "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"];
    const index = Number(month) - 1;
    return `${names[index] || month} ${year}`;
}

/* ---------------------------------------------------------------------------
 * Control de frecuencia
 * ------------------------------------------------------------------------- */

export function debounce(fn, wait = 220) {
    let timer = null;
    return (...args) => {
        clearTimeout(timer);
        timer = setTimeout(() => fn(...args), wait);
    };
}

export function throttle(fn, wait = 200) {
    let last = 0;
    return (...args) => {
        const now = Date.now();
        if (now - last < wait) return;
        last = now;
        fn(...args);
    };
}

/* ---------------------------------------------------------------------------
 * Exportación de archivos
 * ------------------------------------------------------------------------- */

export function toCSV(rows) {
    return rows
        .map((row) =>
            row
                .map((value) => `"${String(value ?? "").replace(/"/g, '""')}"`)
                .join(",")
        )
        .join("\r\n");
}

export function downloadFile(content, filename, type = "text/csv;charset=utf-8;") {
    const blob = new Blob(["\ufeff" + content], { type });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);
    URL.revokeObjectURL(url);
}

/* ---------------------------------------------------------------------------
 * Números y colecciones
 * ------------------------------------------------------------------------- */

export function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
}

export function sum(arr) {
    return arr.reduce((accum, value) => accum + value, 0);
}

export function groupBy(arr, keyFn) {
    return arr.reduce((accum, item) => {
        const key = keyFn(item);
        if (!accum[key]) accum[key] = [];
        accum[key].push(item);
        return accum;
    }, {});
}

export function sortBy(arr, keyFn, direction = "asc") {
    const factor = direction === "asc" ? 1 : -1;
    return [...arr].sort((a, b) => {
        const va = keyFn(a);
        const vb = keyFn(b);
        if (va < vb) return -1 * factor;
        if (va > vb) return 1 * factor;
        return 0;
    });
}