/**
 * ============================================================================
 * src/core/session.js
 * ============================================================================
 *
 * PROPÓSITO
 *   Gestiona la sesión activa: usuario, rol actual y capacidades asociadas.
 *   Es la única fuente de verdad para decidir qué puede hacer el usuario
 *   dentro de la aplicación.
 *
 * RESPONSABILIDADES
 *   - Exponer el usuario y el rol activos.
 *   - Definir los roles disponibles y sus capacidades.
 *   - Comprobar si el usuario puede realizar una acción (can).
 *   - Notificar cambios de sesión mediante el bus de eventos.
 *
 * DEPENDENCIAS
 *   - core/datastore.js    → lectura y actualización de la sesión persistida.
 *   - core/events.js       → emisión del evento "session:change".
 *
 * USADO POR
 *   - ui/sidebar.js        → oculta opciones según rol.
 *   - Secciones             → antes de mostrar acciones sensibles.
 *   - main.js              → cabecera con nombre y rol.
 *
 * EXPORTA
 *   - Session              → objeto con la API pública.
 *   - ROLES                → catálogo de roles y sus capacidades.
 *
 * EVENTOS
 *   - Emite: "session:change" cada vez que cambia el usuario o el rol.
 */

import { DataStore } from "./datastore.js";
import { Events } from "./events.js";

/* ---------------------------------------------------------------------------
 * Catálogo de roles
 * ------------------------------------------------------------------------- */

export const ROLES = {
    admin: {
        label: "Administrador",
        description: "Acceso completo al sistema y su configuración.",
        capabilities: [
            "read",
            "create",
            "update",
            "delete",
            "restore",
            "admin",
            "import",
            "export",
        ],
    },
    operario: {
        label: "Operario",
        description: "Registra y mantiene incidencias.",
        capabilities: ["read", "create", "update", "export"],
    },
    consulta: {
        label: "Consulta",
        description: "Solo lectura y exportación.",
        capabilities: ["read", "export"],
    },
};

/* ---------------------------------------------------------------------------
 * API pública
 * ------------------------------------------------------------------------- */

function get() {
    return DataStore.session.get();
}

function currentUser() {
    const { userId } = get();
    if (!userId) return null;
    return DataStore.users.get(userId);
}

function currentRoleKey() {
    return get().role || "admin";
}

function roleLabel(roleKey = null) {
    const key = roleKey || currentRoleKey();
    return ROLES[key]?.label || "Sin rol";
}

function roleDescription(roleKey = null) {
    const key = roleKey || currentRoleKey();
    return ROLES[key]?.description || "";
}

function capabilities() {
    return [...(ROLES[currentRoleKey()]?.capabilities || [])];
}

function can(capability) {
    return capabilities().includes(capability);
}

function setUser(userId) {
    DataStore.session.setUser(userId);
    Events.emit("session:change", get());
}

function setRole(roleKey) {
    if (!ROLES[roleKey]) return false;
    DataStore.session.setRole(roleKey);
    Events.emit("session:change", get());
    return true;
}

/* ---------------------------------------------------------------------------
 * Exportación
 * ------------------------------------------------------------------------- */

export const Session = {
    get,
    currentUser,
    currentRoleKey,
    roleLabel,
    roleDescription,
    capabilities,
    can,
    setUser,
    setRole,
};