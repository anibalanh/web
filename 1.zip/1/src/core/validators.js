/**
 * ============================================================================
 * src/core/validators.js
 * ============================================================================
 *
 * PROPÓSITO
 *   Reúne las validaciones reutilizables de formularios y datos de entrada.
 *   Define reglas claras y mensajes en español, evitando duplicarlas en cada
 *   sección.
 *
 * RESPONSABILIDADES
 *   - Validar campos individuales (texto, fecha, hora, selección, número).
 *   - Validar formularios completos a partir de un esquema declarativo.
 *   - Devolver mensajes de error consistentes.
 *
 * DEPENDENCIAS
 *   - Ninguna. Módulo independiente.
 *
 * USADO POR
 *   - sections/registrar.js     → validación del formulario de incidencia.
 *   - sections/importar.js      → validación fila por fila.
 *   - sections/administracion.js → validación de formularios modales.
 *   - ui/forms.js               → helpers de presentación de errores.
 *
 * EXPORTA
 *   - Validators               → objeto con la API pública.
 *
 * EVENTOS
 *   - Ninguno.
 */

/* ---------------------------------------------------------------------------
 * Expresiones regulares
 * ------------------------------------------------------------------------- */

const RE_ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;
const RE_TIME = /^([01]\d|2[0-3]):[0-5]\d$/;
const RE_EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/* ---------------------------------------------------------------------------
 * Reglas atómicas
 * ------------------------------------------------------------------------- */

const rules = {
    required: (value) =>
        value !== undefined && value !== null && String(value).trim() !== ""
            ? null
            : "Este campo es obligatorio.",

    maxLength: (value, max) =>
        !value || String(value).length <= max
            ? null
            : `Máximo ${max} caracteres.`,

    minLength: (value, min) =>
        !value || String(value).length >= min
            ? null
            : `Mínimo ${min} caracteres.`,

    isoDate: (value) =>
        !value || RE_ISO_DATE.test(value)
            ? null
            : "La fecha debe tener el formato AAAA-MM-DD.",

    time: (value) =>
        !value || RE_TIME.test(value)
            ? null
            : "La hora debe tener el formato HH:MM.",

    email: (value) =>
        !value || RE_EMAIL.test(value)
            ? null
            : "El correo electrónico no es válido.",

    number: (value) =>
        value === "" || value === null || value === undefined || !Number.isNaN(Number(value))
            ? null
            : "Debe ser un número.",

    integer: (value) =>
        value === "" || value === null || value === undefined ||
        (Number.isInteger(Number(value)))
            ? null
            : "Debe ser un número entero.",

    positive: (value) =>
        value === "" || value === null || value === undefined || Number(value) > 0
            ? null
            : "Debe ser mayor que cero.",

    oneOf: (value, allowed) =>
        !value || (Array.isArray(allowed) && allowed.includes(value))
            ? null
            : `Debe ser uno de: ${allowed.join(", ")}.`,

    dateRange: (value, { from, to } = {}) => {
        if (!value) return null;
        if (from && value < from) return `La fecha no puede ser anterior a ${from}.`;
        if (to && value > to) return `La fecha no puede ser posterior a ${to}.`;
        return null;
    },
};

/* ---------------------------------------------------------------------------
 * API pública
 * ------------------------------------------------------------------------- */

/**
 * Valida un único campo aplicando una lista de reglas declarativas.
 * Cada regla es un objeto: { type: "required", args: ... }.
 * Devuelve el primer mensaje de error encontrado, o null si todo es válido.
 */
function field(value, ruleList = []) {
    for (const rule of ruleList) {
        const fn = rules[rule.type];
        if (!fn) continue;
        const message = fn(value, rule.args);
        if (message) return message;
    }
    return null;
}

/**
 * Valida un objeto completo contra un esquema declarativo.
 * El esquema tiene la forma: { nombreCampo: [ { type, args }, ... ], ... }
 * Devuelve un objeto { valid, errors } donde errors es { campo: mensaje }.
 */
function schema(data, definition = {}) {
    const errors = {};
    for (const [key, ruleList] of Object.entries(definition)) {
        const message = field(data?.[key], ruleList);
        if (message) errors[key] = message;
    }
    return {
        valid: Object.keys(errors).length === 0,
        errors,
    };
}

/**
 * Verifica si un valor es un objeto plano (no nulo, no array).
 */
function isPlainObject(value) {
    return (
        value !== null &&
        typeof value === "object" &&
        !Array.isArray(value)
    );
}

/**
 * Comprueba que un rango de fechas sea coherente (from <= to).
 */
function validDateRange(from, to) {
    if (!from || !to) return true;
    return from <= to;
}

/**
 * Verifica que un correo sea válido (útil en formularios rápidos).
 */
function isEmail(value) {
    return RE_EMAIL.test(String(value || ""));
}

/**
 * Verifica que una fecha ISO tenga el formato correcto.
 */
function isISODate(value) {
    return RE_ISO_DATE.test(String(value || ""));
}

/**
 * Verifica que una hora tenga el formato HH:MM.
 */
function isTime(value) {
    return RE_TIME.test(String(value || ""));
}

/* ---------------------------------------------------------------------------
 * Esquemas predefinidos del dominio
 * ------------------------------------------------------------------------- */

const SCHEMAS = {
    incident: {
        type: [
            { type: "required" },
            { type: "maxLength", args: 120 },
        ],
        date: [
            { type: "required" },
            { type: "isoDate" },
        ],
        time: [
            { type: "time" },
        ],
        zone: [
            { type: "required" },
            { type: "maxLength", args: 120 },
        ],
        title: [
            { type: "required" },
            { type: "maxLength", args: 180 },
        ],
        description: [
            { type: "required" },
            { type: "maxLength", args: 5000 },
        ],
        severity: [
            { type: "oneOf", args: ["", "Leve", "Moderada", "Grave"] },
        ],
        quantity: [
            { type: "integer" },
            { type: "positive" },
        ],
    },

    zone: {
        name: [
            { type: "required" },
            { type: "maxLength", args: 120 },
        ],
        code: [
            { type: "maxLength", args: 6 },
        ],
        description: [
            { type: "maxLength", args: 250 },
        ],
    },

    type: {
        name: [
            { type: "required" },
            { type: "maxLength", args: 120 },
        ],
        description: [
            { type: "maxLength", args: 250 },
        ],
    },

    user: {
        name: [
            { type: "required" },
            { type: "maxLength", args: 120 },
        ],
        email: [
            { type: "required" },
            { type: "email" },
        ],
        role: [
            { type: "required" },
            { type: "oneOf", args: ["admin", "operario", "consulta"] },
        ],
    },
};

/* ---------------------------------------------------------------------------
 * Exportación
 * ------------------------------------------------------------------------- */

export const Validators = {
    field,
    schema,
    rules,
    isPlainObject,
    validDateRange,
    isEmail,
    isISODate,
    isTime,
    SCHEMAS,
};