/**
 * ============================================================================
 * src/core/permissions.js
 * ============================================================================
 *
 * PROPÓSITO
 *   Centraliza las reglas de negocio sobre quién puede hacer qué dentro del
 *   sistema. Es el punto único de consulta antes de mostrar, habilitar o
 *   ejecutar una acción sensible.
 *
 * RESPONSABILIDADES
 *   - Definir qué capacidad se necesita para cada acción del dominio.
 *   - Exponer verificaciones legibles para las secciones y la UI.
 *   - Redirigir siempre a Session.can() como fuente única de verdad.
 *
 * DEPENDENCIAS
 *   - core/session.js      → consulta de capacidades del rol activo.
 *
 * USADO POR
 *   - Secciones             → antes de mostrar botones o ejecutar acciones.
 *   - ui/sidebar.js        → oculta opciones restringidas por rol.
 *   - core/router.js       → verifica acceso a secciones protegidas.
 *
 * EXPORTA
 *   - Permissions          → objeto con la API pública.
 *
 * EVENTOS
 *   - Ninguno.
 */

import { Session } from "./session.js";

/* ---------------------------------------------------------------------------
 * Mapa de acciones → capacidad requerida
 * ------------------------------------------------------------------------- */

const ACTION_CAPABILITY = {
    /* Incidencias */
    "incident.view": "read",
    "incident.create": "create",
    "incident.update": "update",
    "incident.delete": "delete",
    "incident.restore": "restore",
    "incident.export": "export",
    "incident.import": "import",

    /* Zonas */
    "zone.view": "read",
    "zone.create": "admin",
    "zone.update": "admin",
    "zone.delete": "admin",

    /* Tipos de incidencia */
    "type.view": "read",
    "type.create": "admin",
    "type.update": "admin",
    "type.delete": "admin",

    /* Usuarios */
    "user.view": "admin",
    "user.create": "admin",
    "user.update": "admin",
    "user.delete": "admin",

    /* Configuración */
    "settings.view": "admin",
    "settings.update": "admin",
    "backup.create": "admin",
    "backup.restore": "admin",

    /* Auditoría */
    "audit.view": "admin",

    /* Papelera */
    "trash.view": "read",
    "trash.purge": "delete",

    /* Informes y comparativas */
    "report.generate": "export",
    "comparison.run": "read",
};

/* ---------------------------------------------------------------------------
 * Verificaciones
 * ------------------------------------------------------------------------- */

/**
 * Comprueba si el rol activo puede ejecutar la acción indicada.
 * Si la acción no está mapeada, se deniega por defecto.
 */
function can(action) {
    const capability = ACTION_CAPABILITY[action];
    if (!capability) {
        console.warn(`Acción no reconocida en Permissions: "${action}"`);
        return false;
    }
    return Session.can(capability);
}

/**
 * Verifica si el rol activo es administrador.
 */
function isAdmin() {
    return Session.can("admin");
}

/**
 * Devuelve la capacidad asociada a una acción (para depuración).
 */
function capabilityFor(action) {
    return ACTION_CAPABILITY[action] || null;
}

/**
 * Aplica visibilidad a elementos con atributos data-permission.
 * Oculta los que el rol actual no puede ejecutar.
 * Atributo esperado: data-permission="incident.delete"
 */
function applyToDom(root = document) {
    const nodes = root.querySelectorAll("[data-permission]");
    nodes.forEach((node) => {
        const action = node.dataset.permission;
        const allowed = can(action);
        node.hidden = !allowed;
        if (!allowed) {
            node.setAttribute("aria-hidden", "true");
        } else {
            node.removeAttribute("aria-hidden");
        }
    });
}

/* ---------------------------------------------------------------------------
 * Exportación
 * ------------------------------------------------------------------------- */

export const Permissions = {
    can,
    isAdmin,
    capabilityFor,
    applyToDom,
};