/**
 * ============================================================================
 * src/core/datastore.js
 * ============================================================================
 *
 * PROPÓSITO
 *   Capa de acceso a datos de la aplicación. Encapsula toda la persistencia y
 *   expone una API estable para el resto del sistema. Hoy funciona sobre
 *   localStorage; en el futuro podrá respaldarse en Firestore sin cambiar la
 *   interfaz pública.
 *
 * RESPONSABILIDADES
 *   - Cargar, guardar y migrar el estado global en localStorage.
 *   - Exponer CRUD para incidencias, zonas, tipos y usuarios.
 *   - Gestionar la papelera (eliminación lógica y restauración).
 *   - Registrar eventos en el historial de auditoría.
 *   - Notificar cambios a través del bus de eventos.
 *
 * DEPENDENCIAS
 *   - core/utils.js        → helpers de identificadores y fechas.
 *   - core/events.js       → emisión del evento "datastore:change".
 *
 * USADO POR
 *   - core/session.js      → lectura y actualización de la sesión.
 *   - data/seed.js         → fuente de datos iniciales (recibe el estado).
 *   - Todas las secciones  → consultan y modifican información.
 *
 * EXPORTA
 *   - DataStore            → objeto con todos los métodos públicos.
 *   - STORAGE_KEY          → clave utilizada en localStorage.
 *
 * EVENTOS
 *   - Emite: "datastore:change" tras cualquier mutación persistida.
 */

import { uid, todayISO } from "./utils.js";
import { Events } from "./events.js";

export const STORAGE_KEY = "huanta-segura:v1";

/* ---------------------------------------------------------------------------
 * Estado en memoria
 * ------------------------------------------------------------------------- */

let state = null;

/* ---------------------------------------------------------------------------
 * Estructura base
 * ------------------------------------------------------------------------- */

function emptyState() {
    return {
        incidents: [],
        trash: [],
        audit: [],
        zones: [],
        types: [],
        users: [],
        settings: {
            appName: "Huanta Segura",
            institution: "Municipalidad Provincial de Huanta",
            timezone: "America/Lima",
            dateFormat: "dd/mm/yyyy",
        },
        session: {
            userId: null,
            role: "admin",
        },
        meta: {
            version: 1,
            createdAt: new Date().toISOString(),
        },
    };
}

/* ---------------------------------------------------------------------------
 * Persistencia
 * ------------------------------------------------------------------------- */

function load() {
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (!raw) return null;
        const parsed = JSON.parse(raw);
        if (!parsed || typeof parsed !== "object") return null;
        return parsed;
    } catch (error) {
        console.warn("No se pudo leer el estado guardado:", error);
        return null;
    }
}

function persist() {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (error) {
        console.warn("No se pudo guardar el estado:", error);
    }
}

function commit() {
    persist();
    Events.emit("datastore:change", state);
}

/* ---------------------------------------------------------------------------
 * Códigos de incidencia
 * ------------------------------------------------------------------------- */

function generateIncidentCode() {
    const year = new Date().getFullYear();
    const prefix = `HS-${year}-`;
    const used = state.incidents
        .map((item) => item.code)
        .filter((code) => typeof code === "string" && code.startsWith(prefix))
        .map((code) => Number(code.replace(prefix, "")))
        .filter((num) => !Number.isNaN(num));
    const next = (used.length ? Math.max(...used) : 0) + 1;
    return prefix + String(next).padStart(4, "0");
}

/* ---------------------------------------------------------------------------
 * Ciclo de vida
 * ------------------------------------------------------------------------- */

function init(seedFactory) {
    const existing = load();
    if (existing && Array.isArray(existing.incidents)) {
        state = existing;
    } else {
        state = emptyState();
        if (typeof seedFactory === "function") seedFactory(state);
        commit();
    }
    return state;
}

function reset(seedFactory) {
    state = emptyState();
    if (typeof seedFactory === "function") seedFactory(state);
    commit();
}

function getState() {
    return state;
}

/* ---------------------------------------------------------------------------
 * Incidencias
 * ------------------------------------------------------------------------- */

const incidents = {
    list() {
        return [...state.incidents];
    },

    get(id) {
        return state.incidents.find((item) => item.id === id) || null;
    },

    create(data) {
        const record = {
            id: uid("inc"),
            code: data.code || generateIncidentCode(),
            type: data.type || "",
            typeId: data.typeId || null,
            zone: data.zone || "",
            zoneId: data.zoneId || null,
            date: data.date || todayISO(),
            time: data.time || "",
            sector: data.sector || "",
            place: data.place || "",
            title: data.title || "",
            description: data.description || "",
            observations: data.observations || "",
            source: data.source || "",
            severity: data.severity || "",
            quantity: Number(data.quantity || 1),
            createdBy: data.createdBy || state.session.userId || null,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
        };
        state.incidents.unshift(record);
        commit();
        return record;
    },

    update(id, patch) {
        const index = state.incidents.findIndex((item) => item.id === id);
        if (index === -1) return null;
        state.incidents[index] = {
            ...state.incidents[index],
            ...patch,
            updatedAt: new Date().toISOString(),
        };
        commit();
        return state.incidents[index];
    },

    softDelete(id, deletedBy = null) {
        const index = state.incidents.findIndex((item) => item.id === id);
        if (index === -1) return null;
        const [record] = state.incidents.splice(index, 1);
        record.deletedAt = new Date().toISOString();
        record.deletedBy = deletedBy || state.session.userId || null;
        state.trash.unshift(record);
        commit();
        return record;
    },

    restore(id) {
        const index = state.trash.findIndex((item) => item.id === id);
        if (index === -1) return null;
        const [record] = state.trash.splice(index, 1);
        delete record.deletedAt;
        delete record.deletedBy;
        state.incidents.unshift(record);
        commit();
        return record;
    },

    hardDelete(id) {
        const index = state.trash.findIndex((item) => item.id === id);
        if (index === -1) return false;
        state.trash.splice(index, 1);
        commit();
        return true;
    },

    bulkCreate(rows) {
        const created = rows.map((data) => ({
            id: uid("inc"),
            code: data.code || generateIncidentCode(),
            type: data.type || "",
            typeId: data.typeId || null,
            zone: data.zone || "",
            zoneId: data.zoneId || null,
            date: data.date || todayISO(),
            time: data.time || "",
            sector: data.sector || "",
            place: data.place || "",
            title: data.title || "",
            description: data.description || "",
            observations: data.observations || "",
            source: data.source || "",
            severity: data.severity || "",
            quantity: Number(data.quantity || 1),
            createdBy: data.createdBy || state.session.userId || null,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
        }));
        state.incidents.unshift(...created);
        commit();
        return created;
    },
};

/* ---------------------------------------------------------------------------
 * Papelera
 * ------------------------------------------------------------------------- */

const trash = {
    list() {
        return [...state.trash];
    },

    get(id) {
        return state.trash.find((item) => item.id === id) || null;
    },
};

/* ---------------------------------------------------------------------------
 * Auditoría
 * ------------------------------------------------------------------------- */

const audit = {
    list() {
        return [...state.audit];
    },

    log(action, entity, entityId, description, meta = {}) {
        const user = state.users.find((item) => item.id === state.session.userId);
        const event = {
            id: uid("evt"),
            timestamp: new Date().toISOString(),
            userId: state.session.userId || null,
            userName: user?.name || "Sistema",
            userRole: state.session.role || null,
            action,
            entity,
            entityId,
            description,
            meta,
        };
        state.audit.unshift(event);
        if (state.audit.length > 2000) {
            state.audit.length = 2000;
        }
        commit();
        return event;
    },
};

/* ---------------------------------------------------------------------------
 * Zonas
 * ------------------------------------------------------------------------- */

const zones = {
    list() {
        return [...state.zones];
    },

    active() {
        return state.zones.filter((zone) => zone.active !== false);
    },

    get(id) {
        return state.zones.find((zone) => zone.id === id) || null;
    },

    create(data) {
        const zone = {
            id: uid("zone"),
            code: data.code || (data.name ? data.name.slice(0, 3).toUpperCase() : ""),
            name: data.name || "",
            description: data.description || "",
            active: data.active !== false,
            createdAt: new Date().toISOString(),
        };
        state.zones.push(zone);
        commit();
        return zone;
    },

    update(id, patch) {
        const index = state.zones.findIndex((zone) => zone.id === id);
        if (index === -1) return null;
        state.zones[index] = { ...state.zones[index], ...patch };
        commit();
        return state.zones[index];
    },

    remove(id) {
        const index = state.zones.findIndex((zone) => zone.id === id);
        if (index === -1) return false;
        state.zones.splice(index, 1);
        commit();
        return true;
    },
};

/* ---------------------------------------------------------------------------
 * Tipos de incidencia
 * ------------------------------------------------------------------------- */

const types = {
    list() {
        return [...state.types];
    },

    active() {
        return state.types.filter((type) => type.active !== false);
    },

    get(id) {
        return state.types.find((type) => type.id === id) || null;
    },

    create(data) {
        const type = {
            id: uid("type"),
            name: data.name || "",
            description: data.description || "",
            active: data.active !== false,
            createdAt: new Date().toISOString(),
        };
        state.types.push(type);
        commit();
        return type;
    },

    update(id, patch) {
        const index = state.types.findIndex((type) => type.id === id);
        if (index === -1) return null;
        state.types[index] = { ...state.types[index], ...patch };
        commit();
        return state.types[index];
    },

    remove(id) {
        const index = state.types.findIndex((type) => type.id === id);
        if (index === -1) return false;
        state.types.splice(index, 1);
        commit();
        return true;
    },
};

/* ---------------------------------------------------------------------------
 * Usuarios
 * ------------------------------------------------------------------------- */

const users = {
    list() {
        return [...state.users];
    },

    get(id) {
        return state.users.find((user) => user.id === id) || null;
    },

    create(data) {
        const user = {
            id: uid("user"),
            name: data.name || "",
            email: data.email || "",
            role: data.role || "operario",
            status: data.status || "activo",
            createdAt: new Date().toISOString(),
        };
        state.users.push(user);
        commit();
        return user;
    },

    update(id, patch) {
        const index = state.users.findIndex((user) => user.id === id);
        if (index === -1) return null;
        state.users[index] = { ...state.users[index], ...patch };
        commit();
        return state.users[index];
    },

    remove(id) {
        const index = state.users.findIndex((user) => user.id === id);
        if (index === -1) return false;
        state.users.splice(index, 1);
        commit();
        return true;
    },
};

/* ---------------------------------------------------------------------------
 * Configuración
 * ------------------------------------------------------------------------- */

const settings = {
    get() {
        return { ...state.settings };
    },

    update(patch) {
        state.settings = { ...state.settings, ...patch };
        commit();
        return state.settings;
    },
};

/* ---------------------------------------------------------------------------
 * Sesión (persistida dentro del estado)
 * ------------------------------------------------------------------------- */

const sessionStore = {
    get() {
        return { ...state.session };
    },

    setUser(userId) {
        state.session.userId = userId;
        commit();
    },

    setRole(role) {
        state.session.role = role;
        commit();
    },
};

/* ---------------------------------------------------------------------------
 * Exportación
 * ------------------------------------------------------------------------- */

export const DataStore = {
    init,
    reset,
    getState,

    incidents,
    trash,
    audit,
    zones,
    types,
    users,
    settings,
    session: sessionStore,
};