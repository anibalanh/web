/**
 * ============================================================================
 * src/core/router.js
 * ============================================================================
 *
 * PROPÓSITO
 *   Gestiona la navegación entre las secciones de la aplicación mediante el
 *   hash de la URL. Controla qué sección está visible, actualiza la barra
 *   lateral y notifica el cambio por el bus de eventos.
 *
 * RESPONSABILIDADES
 *   - Detectar la sección activa a partir del hash (#inicio, #registros, …).
 *   - Alternar la visibilidad de las secciones en el DOM.
 *   - Sincronizar la clase "active" de los enlaces de la barra lateral.
 *   - Actualizar la miga de pan (breadcrumb) del encabezado.
 *   - Restringir secciones según las capacidades del rol activo.
 *   - Emitir el evento "section:change" al cambiar de sección.
 *
 * DEPENDENCIAS
 *   - core/events.js       → emisión de "section:change".
 *   - core/session.js      → verificación de permisos por rol.
 *   - core/utils.js        → selección del DOM.
 *
 * USADO POR
 *   - main.js              → inicializa el router al arrancar.
 *   - ui/sidebar.js        → cierra el menú en móvil tras navegar.
 *   - Secciones             → pueden invocar Router.go(id) para redirigir.
 *
 * EXPORTA
 *   - Router               → objeto con la API pública.
 *
 * EVENTOS
 *   - Emite: "section:change" con { id, previousId }.
 */

import { $, $$ } from "./utils.js";
import { Events } from "./events.js";
import { Session } from "./session.js";

/* ---------------------------------------------------------------------------
 * Estado interno
 * ------------------------------------------------------------------------- */

const state = {
    sections: [],
    currentId: null,
    initialized: false,
};

/* ---------------------------------------------------------------------------
 * Utilidades internas
 * ------------------------------------------------------------------------- */

function readHash() {
    const raw = (location.hash || "#inicio").replace("#", "").trim();
    return raw || "inicio";
}

function findSection(id) {
    return state.sections.find((section) => section.id === id) || null;
}

function sectionRequiresAdmin(section) {
    return section && section.admin === true;
}

function canAccess(section) {
    if (!section) return false;
    if (sectionRequiresAdmin(section)) return Session.can("admin");
    return true;
}

function updateSidebarActive(id) {
    $$(".nav-item").forEach((item) => {
        const isActive = item.dataset.sectionLink === id;
        item.classList.toggle("active", isActive);
        if (isActive) {
            item.setAttribute("aria-current", "page");
        } else {
            item.removeAttribute("aria-current");
        }
    });
}

function updateBreadcrumb(section) {
    const crumb = $("#breadcrumbCurrent");
    if (!crumb) return;
    crumb.textContent = section?.label || "Inicio";
}

function updateVisibility(id) {
    state.sections.forEach((section) => {
        const el = document.getElementById(`section-${section.id}`);
        if (!el) return;
        const visible = section.id === id;
        el.classList.toggle("active", visible);
        el.hidden = !visible;
    });
}

function scrollToTop() {
    window.scrollTo({ top: 0, behavior: "smooth" });
}

function closeMobileSidebar() {
    if (window.innerWidth <= 900) {
        document.body.classList.add("sidebar-collapsed");
    }
}

/* ---------------------------------------------------------------------------
 * Navegación
 * ------------------------------------------------------------------------- */

function go(id, options = {}) {
    const section = findSection(id);

    if (!section) {
        if (!options.silent) go("inicio", { silent: true });
        return;
    }

    if (!canAccess(section)) {
        Events.emit("router:denied", { id });
        if (!options.silent) go("inicio", { silent: true });
        return;
    }

    const previousId = state.currentId;
    state.currentId = id;

    updateVisibility(id);
    updateSidebarActive(id);
    updateBreadcrumb(section);

    if (location.hash !== `#${id}`) {
        history.replaceState(null, "", `#${id}`);
    }

    closeMobileSidebar();
    scrollToTop();

    Events.emit("section:change", { id, previousId });
}

function current() {
    return state.currentId;
}

/* ---------------------------------------------------------------------------
 * Inicialización
 * ------------------------------------------------------------------------- */

function init(sections) {
    if (state.initialized) return;
    state.sections = Array.isArray(sections) ? sections : [];
    state.initialized = true;

    /* Enlaces con data-section-link navegan por hash sin recargar */
    $$("[data-section-link]").forEach((link) => {
        link.addEventListener("click", (event) => {
            const id = link.dataset.sectionLink;
            if (!id) return;
            event.preventDefault();
            go(id);
        });
    });

    /* Reaccionar a cambios manuales en el hash */
    window.addEventListener("hashchange", () => {
        const id = readHash();
        if (id !== state.currentId) go(id);
    });

    /* Cargar la sección inicial */
    const initial = readHash();
    go(initial, { silent: true });
}

/* ---------------------------------------------------------------------------
 * Exportación
 * ------------------------------------------------------------------------- */

export const Router = {
    init,
    go,
    current,
};