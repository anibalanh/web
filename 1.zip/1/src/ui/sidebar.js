/**
 * ============================================================================
 * src/ui/sidebar.js
 * ============================================================================
 *
 * PROPÓSITO
 *   Controla el comportamiento de la barra lateral: colapso en escritorio,
 *   apertura/cierre en móvil y persistencia de la preferencia del usuario.
 *
 * RESPONSABILIDADES
 *   - Alternar la clase "sidebar-collapsed" en <body> al pulsar el botón.
 *   - Cerrar automáticamente el menú en móvil tras navegar.
 *   - Guardar y restaurar la preferencia de colapso del usuario.
 *   - Reaccionar a cambios de tamaño de ventana.
 *
 * DEPENDENCIAS
 *   - core/utils.js        → selección del DOM.
 *   - core/events.js       → escucha "section:change" para cerrar en móvil.
 *
 * USADO POR
 *   - main.js              → inicializa la barra lateral al arrancar.
 *
 * EXPORTA
 *   - Sidebar              → objeto con la API pública.
 *
 * EVENTOS
 *   - Escucha: "section:change" → cierra el menú en móvil al navegar.
 */

import { $ } from "@core/utils.js";
import { Events } from "@core/events.js";

/* ---------------------------------------------------------------------------
 * Configuración
 * ------------------------------------------------------------------------- */

const STORAGE_KEY = "huanta-segura:sidebar";
const MOBILE_BREAKPOINT = 900;

/* ---------------------------------------------------------------------------
 * Estado interno
 * ------------------------------------------------------------------------- */

const state = {
    toggleBtn: null,
    initialized: false,
};

/* ---------------------------------------------------------------------------
 * Utilidades internas
 * ------------------------------------------------------------------------- */

function isMobile() {
    return window.innerWidth <= MOBILE_BREAKPOINT;
}

function isCollapsed() {
    return document.body.classList.contains("sidebar-collapsed");
}

function collapse() {
    document.body.classList.add("sidebar-collapsed");
}

function expand() {
    document.body.classList.remove("sidebar-collapsed");
}

function toggle() {
    if (isCollapsed()) {
        expand();
    } else {
        collapse();
    }
    persistPreference();
}

function persistPreference() {
    try {
        localStorage.setItem(
            STORAGE_KEY,
            isCollapsed() ? "collapsed" : "open"
        );
    } catch (error) {
        console.warn("No se pudo guardar la preferencia de la barra lateral:", error);
    }
}

function restorePreference() {
    let saved = null;
    try {
        saved = localStorage.getItem(STORAGE_KEY);
    } catch {
        saved = null;
    }

    if (isMobile()) {
        /* En móvil siempre arranca colapsada */
        collapse();
        return;
    }

    if (saved === "collapsed") {
        collapse();
    } else {
        expand();
    }
}

/* ---------------------------------------------------------------------------
 * API pública
 * ------------------------------------------------------------------------- */

function init() {
    if (state.initialized) return;

    state.toggleBtn = $("#sidebarToggle");

    if (state.toggleBtn) {
        state.toggleBtn.addEventListener("click", () => {
            toggle();
            if (state.toggleBtn) {
                state.toggleBtn.setAttribute(
                    "aria-expanded",
                    isCollapsed() ? "false" : "true"
                );
            }
        });
    }

    restorePreference();

    if (state.toggleBtn) {
        state.toggleBtn.setAttribute(
            "aria-expanded",
            isCollapsed() ? "false" : "true"
        );
    }

    /* Reaccionar a cambios de tamaño */
    window.addEventListener("resize", () => {
        if (isMobile()) {
            collapse();
        }
    });

    /* Cerrar en móvil al cambiar de sección */
    Events.on("section:change", () => {
        if (isMobile()) {
            collapse();
        }
    });

    state.initialized = true;
}

/* ---------------------------------------------------------------------------
 * Exportación
 * ------------------------------------------------------------------------- */

export const Sidebar = {
    init,
    collapse,
    expand,
    toggle,
    isCollapsed,
};