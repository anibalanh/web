/**
 * ============================================================================
 * src/ui/modal.js
 * ============================================================================
 *
 * PROPÓSITO
 *   Modal genérico reutilizable y diálogo de confirmación. Reemplaza el uso de
 *   alert() y confirm() nativos por una interfaz coherente con el sistema.
 *
 * RESPONSABILIDADES
 *   - Abrir y cerrar el modal controlando el foco y el scroll del body.
 *   - Insertar contenido HTML en cabecera, cuerpo y pie.
 *   - Ofrecer un diálogo de confirmación con acción al aceptar.
 *   - Cerrar al pulsar Escape, al hacer clic fuera o desde botones.
 *   - Ejecutar un callback onMount tras inyectar el contenido.
 *
 * DEPENDENCIAS
 *   - core/utils.js        → selección del DOM.
 *   - core/events.js       → emisión de eventos "modal:open" y "modal:close".
 *
 * USADO POR
 *   - Todas las secciones que necesiten mostrar detalles, formularios o
 *     confirmaciones.
 *
 * EXPORTA
 *   - Modal                → objeto con la API pública.
 *
 * EVENTOS
 *   - Emite: "modal:open"  con { title }.
 *   - Emite: "modal:close" sin datos.
 */

import { $ } from "@core/utils.js";
import { Events } from "@core/events.js";

/* ---------------------------------------------------------------------------
 * Estado interno
 * ------------------------------------------------------------------------- */

const state = {
    backdrop: null,
    dialog: null,
    eyebrowEl: null,
    titleEl: null,
    bodyEl: null,
    footerEl: null,
    closeBtn: null,
    cancelBtn: null,
    lastFocus: null,
    initialized: false,
    onCloseCallback: null,
};

/* ---------------------------------------------------------------------------
 * Utilidades internas
 * ------------------------------------------------------------------------- */

function getElements() {
    state.backdrop  = $("#modalBackdrop");
    state.dialog    = $("#generalModal");
    state.eyebrowEl = $("#modalEyebrow");
    state.titleEl   = $("#modalTitle");
    state.bodyEl    = $("#modalBody");
    state.footerEl  = $("#modalFooter");
    state.closeBtn  = $("#closeModalButton");
    state.cancelBtn = $("#cancelModalButton");
}

function lockBodyScroll() {
    document.body.style.overflow = "hidden";
}

function unlockBodyScroll() {
    document.body.style.overflow = "";
}

function focusFirst() {
    if (!state.dialog) return;
    const target = state.dialog.querySelector(
        "input:not([type=hidden]), select, textarea, button:not([disabled])"
    );
    if (target) {
        setTimeout(() => target.focus(), 40);
    }
}

function restoreFocus() {
    if (state.lastFocus && typeof state.lastFocus.focus === "function") {
        state.lastFocus.focus();
    }
}

/* ---------------------------------------------------------------------------
 * Apertura y cierre
 * ------------------------------------------------------------------------- */

function open({
    eyebrow = "HUANTA SEGURA",
    title = "Detalles",
    body = "",
    footer = "",
    onMount = null,
    onClose = null,
} = {}) {
    if (!state.backdrop) getElements();
    if (!state.backdrop) return;

    state.lastFocus = document.activeElement;
    state.onCloseCallback = typeof onClose === "function" ? onClose : null;

    if (state.eyebrowEl) state.eyebrowEl.textContent = eyebrow;
    if (state.titleEl) state.titleEl.textContent = title;
    if (state.bodyEl) state.bodyEl.innerHTML = body;

    if (state.footerEl) {
        state.footerEl.innerHTML = footer && footer.trim()
            ? footer
            : `<button type="button" class="button button-secondary" data-modal-close>Cerrar</button>`;
    }

    state.backdrop.hidden = false;
    lockBodyScroll();
    focusFirst();

    if (typeof onMount === "function") {
        onMount({
            body: state.bodyEl,
            footer: state.footerEl,
            close,
        });
    }

    Events.emit("modal:open", { title });
}

function close() {
    if (!state.backdrop || state.backdrop.hidden) return;

    state.backdrop.hidden = true;
    unlockBodyScroll();

    if (state.bodyEl) state.bodyEl.innerHTML = "";
    if (state.footerEl) state.footerEl.innerHTML = "";

    restoreFocus();

    if (typeof state.onCloseCallback === "function") {
        try {
            state.onCloseCallback();
        } catch (error) {
            console.error("Error en onClose del modal:", error);
        }
    }
    state.onCloseCallback = null;

    Events.emit("modal:close");
}

/* ---------------------------------------------------------------------------
 * Confirmación
 * ------------------------------------------------------------------------- */

function confirm({
    title = "Confirmar",
    message = "",
    confirmLabel = "Confirmar",
    cancelLabel = "Cancelar",
    danger = false,
    onConfirm = null,
    onCancel = null,
} = {}) {
    const body = `
        <p style="margin:0;font-size:12px;line-height:1.7;color:#5b677c">
            ${message}
        </p>
    `;

    const footer = `
        <button type="button" class="button button-secondary" data-modal-cancel>
            ${cancelLabel}
        </button>
        <button type="button" class="button ${danger ? "button-danger-outline" : "button-primary"}" data-modal-confirm>
            ${confirmLabel}
        </button>
    `;

    open({
        eyebrow: "CONFIRMACIÓN",
        title,
        body,
        footer,
        onMount: ({ footer }) => {
            const cancel = footer.querySelector("[data-modal-cancel]");
            const accept = footer.querySelector("[data-modal-confirm]");

            if (cancel) {
                cancel.addEventListener("click", () => {
                    if (typeof onCancel === "function") onCancel();
                    close();
                });
            }

            if (accept) {
                accept.addEventListener("click", () => {
                    close();
                    if (typeof onConfirm === "function") onConfirm();
                });
            }
        },
        onClose: () => {
            /* Si se cierra sin aceptar ni cancelar, no se llama a onCancel
               porque puede ser un cierre con Escape o clic en el fondo. */
        },
    });
}

/* ---------------------------------------------------------------------------
 * Inicialización
 * ------------------------------------------------------------------------- */

function init() {
    if (state.initialized) return;
    getElements();
    if (!state.backdrop) {
        console.warn("Modal: no se encontró #modalBackdrop en el DOM.");
        return;
    }

    /* Clic en el fondo cierra */
    state.backdrop.addEventListener("click", (event) => {
        if (event.target === state.backdrop) close();
    });

    /* Clic en botón [data-modal-close] cierra */
    state.backdrop.addEventListener("click", (event) => {
        const trigger = event.target.closest("[data-modal-close]");
        if (trigger) {
            event.preventDefault();
            close();
        }
    });

    /* Botones fijos de la cabecera y pie */
    if (state.closeBtn) {
        state.closeBtn.addEventListener("click", close);
    }
    if (state.cancelBtn) {
        state.cancelBtn.addEventListener("click", close);
    }

    /* Escape cierra */
    document.addEventListener("keydown", (event) => {
        if (event.key === "Escape" && !state.backdrop.hidden) {
            close();
        }
    });

    state.initialized = true;
}

/* ---------------------------------------------------------------------------
 * Exportación
 * ------------------------------------------------------------------------- */

export const Modal = {
    init,
    open,
    close,
    confirm,
};