/**
 * ============================================================================
 * src/ui/toast.js
 * ============================================================================
 *
 * PROPÓSITO
 *   Sistema de notificaciones flotantes no bloqueantes. Muestra mensajes
 *   breves de éxito, error, advertencia o información en la esquina inferior
 *   derecha de la pantalla.
 *
 * RESPONSABILIDADES
 *   - Renderizar notificaciones en el contenedor #toastContainer.
 *   - Aplicar el estilo según el tipo (success, error, warning, info).
 *   - Gestionar el cierre manual y automático.
 *   - Mantener una pila ordenada de notificaciones visibles.
 *
 * DEPENDENCIAS
 *   - core/utils.js        → escapeHTML y selección del DOM.
 *   - core/events.js       → emisión de "toast:show" (opcional).
 *
 * USADO POR
 *   - Todas las secciones y módulos que necesiten informar al usuario.
 *   - main.js              → inicializa el contenedor.
 *
 * EXPORTA
 *   - Toast                → objeto con la API pública.
 *
 * EVENTOS
 *   - Emite: "toast:show" con { type, title, message }.
 */

import { $, escapeHTML } from "@core/utils.js";
import { Events } from "@core/events.js";

/* ---------------------------------------------------------------------------
 * Configuración
 * ------------------------------------------------------------------------- */

const ICONS = {
    success: "fa-circle-check",
    error: "fa-circle-xmark",
    warning: "fa-triangle-exclamation",
    info: "fa-circle-info",
};

const DEFAULT_DURATION = 4200;
const EXIT_DURATION = 180;

/* ---------------------------------------------------------------------------
 * Estado interno
 * ------------------------------------------------------------------------- */

let container = null;
let initialized = false;

/* ---------------------------------------------------------------------------
 * Utilidades internas
 * ------------------------------------------------------------------------- */

function ensureContainer() {
    if (container && document.body.contains(container)) return container;
    container = $("#toastContainer");
    if (!container) {
        container = document.createElement("div");
        container.className = "toast-container";
        container.id = "toastContainer";
        container.setAttribute("aria-live", "polite");
        container.setAttribute("aria-atomic", "false");
        document.body.appendChild(container);
    }
    return container;
}

function buildToast(type, title, message) {
    const el = document.createElement("div");
    el.className = `toast ${type}`;
    el.setAttribute("role", type === "error" ? "alert" : "status");

    const icon = ICONS[type] || ICONS.info;

    el.innerHTML = `
        <span class="toast-icon">
            <i class="fa-solid ${icon}"></i>
        </span>
        <div class="toast-content">
            <strong>${escapeHTML(title)}</strong>
            ${message ? `<p>${escapeHTML(message)}</p>` : ""}
        </div>
        <button type="button" class="toast-close" aria-label="Cerrar notificación">
            <i class="fa-solid fa-xmark"></i>
        </button>
    `;

    return el;
}

function dismiss(el) {
    if (!el || el.dataset.dismissed === "true") return;
    el.dataset.dismissed = "true";
    el.style.opacity = "0";
    el.style.transform = "translateY(8px)";
    setTimeout(() => {
        if (el.parentNode) el.parentNode.removeChild(el);
    }, EXIT_DURATION);
}

/* ---------------------------------------------------------------------------
 * API pública
 * ------------------------------------------------------------------------- */

function show(type, title, message = "", duration = DEFAULT_DURATION) {
    const host = ensureContainer();
    if (!host) return null;

    const el = buildToast(type, title, message);

    const closeBtn = el.querySelector(".toast-close");
    if (closeBtn) {
        closeBtn.addEventListener("click", () => dismiss(el));
    }

    host.appendChild(el);

    if (duration > 0) {
        setTimeout(() => dismiss(el), duration);
    }

    Events.emit("toast:show", { type, title, message });
    return el;
}

function success(title, message = "", duration) {
    return show("success", title, message, duration);
}

function error(title, message = "", duration) {
    return show("error", title, message, duration);
}

function warning(title, message = "", duration) {
    return show("warning", title, message, duration);
}

function info(title, message = "", duration) {
    return show("info", title, message, duration);
}

function clear() {
    const host = ensureContainer();
    if (!host) return;
    Array.from(host.children).forEach((child) => dismiss(child));
}

function init() {
    if (initialized) return;
    ensureContainer();
    initialized = true;
}

/* ---------------------------------------------------------------------------
 * Exportación
 * ------------------------------------------------------------------------- */

export const Toast = {
    init,
    show,
    success,
    error,
    warning,
    info,
    clear,
};