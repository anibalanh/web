/**
 * ============================================================================
 * src/ui/forms.js
 * ============================================================================
 *
 * PROPÓSITO
 *   Helpers de formularios reutilizables: mostrar y limpiar errores de campo,
 *   leer valores del formulario, actualizar contadores de caracteres y marcar
 *   visualmente los campos inválidos.
 *
 * RESPONSABILIDADES
 *   - Localizar el contenedor de error asociado a un campo (data-error-for).
 *   - Mostrar y limpiar mensajes de error de forma consistente.
 *   - Leer y escribir valores de campos por id.
 *   - Reiniciar formularios restableciendo estado y errores.
 *   - Actualizar contadores de caracteres de textareas.
 *
 * DEPENDENCIAS
 *   - core/utils.js        → selección del DOM.
 *
 * USADO POR
 *   - sections/registrar.js
 *   - sections/administracion.js
 *   - Cualquier sección con formulario.
 *
 * EXPORTA
 *   - Forms                → objeto con la API pública.
 *
 * EVENTOS
 *   - Ninguno.
 */

import { $, $$ } from "@core/utils.js";

/* ---------------------------------------------------------------------------
 * Errores de campo
 * ------------------------------------------------------------------------- */

/**
 * Muestra un mensaje de error bajo el campo indicado.
 * Si el mensaje está vacío, limpia el estado de error.
 */
function setFieldError(fieldId, message = "") {
    const errorEl = document.querySelector(`[data-error-for="${fieldId}"]`);
    const fieldEl = document.getElementById(fieldId);

    if (errorEl) errorEl.textContent = message || "";

    if (fieldEl) {
        if (message) {
            fieldEl.setAttribute("aria-invalid", "true");
        } else {
            fieldEl.removeAttribute("aria-invalid");
        }
    }
}

/**
 * Limpia los errores de todos los campos de un formulario.
 */
function clearErrors(form) {
    if (!form) return;
    $$("[data-error-for]", form).forEach((el) => {
        el.textContent = "";
    });
    $$("[aria-invalid]", form).forEach((el) => {
        el.removeAttribute("aria-invalid");
    });
}

/**
 * Aplica un mapa de errores al formulario.
 * Se espera un objeto { idCampo: mensaje }.
 * Devuelve true si había al menos un error.
 */
function applyErrors(form, errors = {}) {
    if (!form) return false;
    clearErrors(form);
    const keys = Object.keys(errors);
    keys.forEach((fieldId) => {
        setFieldError(fieldId, errors[fieldId]);
    });
    if (keys.length) {
        const first = document.getElementById(keys[0]);
        if (first && typeof first.focus === "function") first.focus();
    }
    return keys.length > 0;
}

/* ---------------------------------------------------------------------------
 * Lectura y escritura de valores
 * ------------------------------------------------------------------------- */

/**
 * Devuelve el valor recortado de un campo por id.
 * Si el campo es numérico, no recorta el valor.
 */
function valueOf(fieldId, { trim = true } = {}) {
    const el = document.getElementById(fieldId);
    if (!el) return "";
    const raw = el.value ?? "";
    return trim ? String(raw).trim() : raw;
}

/**
 * Devuelve un objeto con los valores de los campos indicados.
 */
function readFields(fieldIds = []) {
    const data = {};
    fieldIds.forEach((id) => {
        data[id] = valueOf(id);
    });
    return data;
}

/**
 * Asigna un valor a un campo por id.
 */
function setValue(fieldId, value) {
    const el = document.getElementById(fieldId);
    if (!el) return;
    el.value = value ?? "";
}

/**
 * Marca o desmarca una casilla por id.
 */
function setChecked(fieldId, checked) {
    const el = document.getElementById(fieldId);
    if (!el) return;
    el.checked = Boolean(checked);
}

/**
 * Devuelve si una casilla está marcada.
 */
function isChecked(fieldId) {
    const el = document.getElementById(fieldId);
    return Boolean(el && el.checked);
}

/* ---------------------------------------------------------------------------
 * Limpieza y reinicio
 * ------------------------------------------------------------------------- */

/**
 * Reinicia un formulario, limpia errores y contadores asociados.
 * Se puede pasar un callback para volver a aplicar valores por defecto.
 */
function reset(formId, onAfterReset = null) {
    const form = document.getElementById(formId);
    if (!form) return;
    form.reset();
    clearErrors(form);
    $$("[data-counter-for]", form).forEach((counter) => {
        const targetId = counter.dataset.counterFor;
        const target = document.getElementById(targetId);
        if (target) {
            counter.textContent = `0 / ${target.maxLength || 0}`;
        }
    });
    if (typeof onAfterReset === "function") {
        onAfterReset(form);
    }
}

/* ---------------------------------------------------------------------------
 * Contadores de caracteres
 * ------------------------------------------------------------------------- */

/**
 * Actualiza el contador de un campo (por ejemplo, una textarea).
 * El contenedor del contador debe tener data-counter-for="fieldId".
 */
function updateCounter(fieldId) {
    const field = document.getElementById(fieldId);
    const counter = document.querySelector(`[data-counter-for="${fieldId}"]`);
    if (!field || !counter) return;
    const max = field.maxLength > 0 ? field.maxLength : "";
    counter.textContent = max
        ? `${field.value.length} / ${max}`
        : `${field.value.length}`;
}

/**
 * Enlaza automáticamente todos los contadores declarados con data-counter-for.
 */
function bindCounters(root = document) {
    const counters = root.querySelectorAll("[data-counter-for]");
    counters.forEach((counter) => {
        const fieldId = counter.dataset.counterFor;
        const field = document.getElementById(fieldId);
        if (!field) return;
        if (field.dataset.counterBound === "true") return;
        field.addEventListener("input", () => updateCounter(fieldId));
        field.dataset.counterBound = "true";
        updateCounter(fieldId);
    });
}

/* ---------------------------------------------------------------------------
 * Deshabilitado de botones durante operaciones
 * ------------------------------------------------------------------------- */

/**
 * Bloquea un botón mostrando un estado de carga simple.
 * Devuelve una función para restaurar el estado original.
 */
function lockButton(button, loadingLabel = "Procesando…") {
    if (!button) return () => {};
    const original = button.innerHTML;
    const wasDisabled = button.disabled;
    button.disabled = true;
    button.dataset.originalLabel = original;
    button.textContent = loadingLabel;

    return () => {
        button.disabled = wasDisabled;
        button.innerHTML = original;
    };
}

/* ---------------------------------------------------------------------------
 * Exportación
 * ------------------------------------------------------------------------- */

export const Forms = {
    setFieldError,
    clearErrors,
    applyErrors,
    valueOf,
    readFields,
    setValue,
    setChecked,
    isChecked,
    reset,
    updateCounter,
    bindCounters,
    lockButton,
};