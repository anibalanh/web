/**
 * ============================================================================
 * src/data/seed.js
 * ============================================================================
 *
 * PROPÓSITO
 *   Genera los datos iniciales de demostración para Huanta Segura. Se ejecuta
 *   únicamente cuando el DataStore no encuentra información guardada.
 *
 * RESPONSABILIDADES
 *   - Crear zonas reales de la ciudad de Huanta.
 *   - Crear los tipos de incidencia del sistema.
 *   - Crear los usuarios de demostración (admin, operarios, consulta).
 *   - Generar incidencias ficticias repartidas en los últimos meses.
 *   - Añadir eventos iniciales al historial de auditoría.
 *
 * DEPENDENCIAS
 *   - core/utils.js        → uid y helpers.
 *
 * USADO POR
 *   - core/datastore.js    → como función de inicialización (seedFactory).
 *   - main.js              → pasa esta función al DataStore.
 *
 * EXPORTA
 *   - seedData(state)      → muta el estado proporcionado con datos iniciales.
 *
 * EVENTOS
 *   - Ninguno. Solo construye el estado.
 */

import { uid } from "@core/utils.js";

/* ---------------------------------------------------------------------------
 * Utilidades internas
 * ------------------------------------------------------------------------- */

function randomOf(list) {
    return list[Math.floor(Math.random() * list.length)];
}

function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function daysAgoISO(daysAgo) {
    const date = new Date();
    date.setDate(date.getDate() - daysAgo);
    return date.toISOString().slice(0, 10);
}

function buildDateAt(daysAgo, hour, minute) {
    const date = new Date();
    date.setDate(date.getDate() - daysAgo);
    date.setHours(hour, minute, 0, 0);
    return date.toISOString();
}

function formatTime(hour, minute) {
    return `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
}

/* ---------------------------------------------------------------------------
 * Catálogos base
 * ------------------------------------------------------------------------- */

const ZONES_SOURCE = [
    ["Centro",            "CEN", "Zona céntrica de Huanta"],
    ["Mercado",           "MER", "Zona comercial y de abastos"],
    ["Miraflores",        "MIR", "Barrio Miraflores"],
    ["San José",          "SJO", "Barrio San José"],
    ["Hospital",          "HOS", "Sector del hospital"],
    ["Accoscca",          "ACC", "Sector Accoscca"],
    ["Comercio",          "COM", "Zona de comercio"],
    ["Quinrapa",          "QUI", "Sector Quinrapa"],
    ["Otros sectores",    "OTR", "Otras zonas de la ciudad"],
];

const TYPES_SOURCE = [
    ["Robo o hurto",                       "Sustracción de bienes"],
    ["Agresión física",                    "Violencia entre personas"],
    ["Violencia familiar",                 "Violencia intrafamiliar"],
    ["Vandalismo",                         "Daño a bienes públicos o privados"],
    ["Accidente de tránsito",              "Siniestros viales"],
    ["Alteración del orden público",       "Ruidos, escándalos, disturbios"],
    ["Consumo de alcohol en vía pública",  "Bebidas alcohólicas en la calle"],
    ["Otro",                               "Otras incidencias"],
];

const SOURCES = [
    "Registro directo",
    "Comunicación institucional",
    "Reporte ciudadano",
    "Documento o informe",
    "Otro",
];

const SEVERITIES = ["Leve", "Moderada", "Grave"];

const TITLES_BY_TYPE = {
    "Robo o hurto": [
        "Hurto en vía pública",
        "Sustracción de bicicleta",
        "Robo a transeúnte",
        "Hurto en vivienda",
    ],
    "Agresión física": [
        "Riña en la vía pública",
        "Agresión entre vecinos",
        "Discusión con violencia",
        "Agresión a trabajador",
    ],
    "Violencia familiar": [
        "Episodio de violencia intrafamiliar",
        "Llamado por violencia familiar",
        "Intervención por conflicto doméstico",
    ],
    "Vandalismo": [
        "Deterioro de mobiliario público",
        "Pintas en la vía",
        "Rotura de señalización",
        "Daños a vehículo",
    ],
    "Accidente de tránsito": [
        "Choque entre vehículos",
        "Atropello en intersección",
        "Despiste de vehículo menor",
    ],
    "Alteración del orden público": [
        "Ruidos molestos",
        "Escándalo en la vía pública",
        "Disturbios en establecimiento",
    ],
    "Consumo de alcohol en vía pública": [
        "Consumo en parque",
        "Grupo bebiendo en la calle",
        "Botellas en vía pública",
    ],
    "Otro": [
        "Situación reportada por vecinos",
        "Hecho menor reportado",
    ],
};

const DESCRIPTIONS = [
    "Registro generado a partir de la información disponible al momento del reporte.",
    "El hecho fue comunicado por un vecino a través del canal disponible.",
    "Se recibió una llamada informando la situación en la zona indicada.",
    "El personal asignado registró los datos conocidos del incidente.",
    "La incidencia se documentó según la información preliminar obtenida.",
];

/* ---------------------------------------------------------------------------
 * Construcción de catálogos
 * ------------------------------------------------------------------------- */

function buildZones() {
    const now = new Date().toISOString();
    return ZONES_SOURCE.map(([name, code, description]) => ({
        id: uid("zone"),
        name,
        code,
        description,
        active: true,
        createdAt: now,
    }));
}

function buildTypes() {
    const now = new Date().toISOString();
    return TYPES_SOURCE.map(([name, description]) => ({
        id: uid("type"),
        name,
        description,
        active: true,
        createdAt: now,
    }));
}

function buildUsers() {
    const now = new Date().toISOString();
    return [
        { name: "Administrador", email: "admin@huanta.gob.pe",    role: "admin",    status: "activo" },
        { name: "María Quispe",  email: "mquispe@huanta.gob.pe",  role: "operario", status: "activo" },
        { name: "Carlos Ríos",   email: "crios@huanta.gob.pe",    role: "operario", status: "activo" },
        { name: "Lucía Mendoza", email: "lmendoza@huanta.gob.pe", role: "consulta", status: "activo" },
    ].map((user) => ({
        id: uid("user"),
        createdAt: now,
        ...user,
    }));
}

/* ---------------------------------------------------------------------------
 * Construcción de incidencias
 * ------------------------------------------------------------------------- */

function buildIncidents(zones, types, users, total = 74) {
    const now = new Date();
    const incidents = [];

    for (let index = 0; index < total; index++) {
        const daysAgo = randomInt(0, 175);
        const hour = randomInt(6, 23);
        const minute = randomInt(0, 59);

        const type = randomOf(types);
        const zone = randomOf(zones);
        const user = randomOf(users);

        const titlePool = TITLES_BY_TYPE[type.name] || ["Incidencia registrada"];
        const title = randomOf(titlePool);
        const description = randomOf(DESCRIPTIONS);
        const source = randomOf(SOURCES);
        const severity = randomOf(SEVERITIES);

        const dateISO = daysAgoISO(daysAgo);
        const createdAt = buildDateAt(daysAgo, hour, minute);

        const year = new Date(createdAt).getFullYear();
        const code = `HS-${year}-${String(1000 + index).slice(-4)}`;

        incidents.push({
            id: uid("inc"),
            code,
            type: type.name,
            typeId: type.id,
            zone: zone.name,
            zoneId: zone.id,
            date: dateISO,
            time: formatTime(hour, minute),
            sector: "",
            place: "",
            title,
            description,
            observations: "",
            source,
            severity,
            quantity: 1,
            createdBy: user.id,
            createdAt,
            updatedAt: createdAt,
        });
    }

    /* Ordenar de más reciente a más antiguo */
    return incidents.sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
}

/* ---------------------------------------------------------------------------
 * Construcción de auditoría inicial
 * ------------------------------------------------------------------------- */

function buildAudit(incidents, users, limit = 25) {
    const events = [];
    const recent = incidents.slice(0, limit);

    recent.forEach((incident) => {
        const user = users.find((item) => item.id === incident.createdBy);
        events.push({
            id: uid("evt"),
            timestamp: incident.createdAt,
            userId: incident.createdBy,
            userName: user?.name || "Sistema",
            userRole: user?.role || "operario",
            action: "create",
            entity: "incident",
            entityId: incident.id,
            description: `Creación de incidencia ${incident.code}`,
            meta: {},
        });
    });

    return events;
}

/* ---------------------------------------------------------------------------
 * Semilla principal
 * ------------------------------------------------------------------------- */

export function seedData(state) {
    if (!state) return state;

    const zones = buildZones();
    const types = buildTypes();
    const users = buildUsers();
    const incidents = buildIncidents(zones, types, users);
    const audit = buildAudit(incidents, users);

    state.zones = zones;
    state.types = types;
    state.users = users;
    state.incidents = incidents;
    state.audit = audit;
    state.trash = [];

    state.settings = {
        appName: "Huanta Segura",
        institution: "Municipalidad Provincial de Huanta",
        timezone: "America/Lima",
        dateFormat: "dd/mm/yyyy",
    };

    state.session = {
        userId: users[0].id,
        role: "admin",
    };

    state.meta = {
        version: 1,
        createdAt: new Date().toISOString(),
    };

    return state;
}