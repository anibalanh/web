/**
 * ============================================================================
 * vite.config.js
 * ============================================================================
 *
 * PROPÓSITO
 *   Configuración del bundler Vite para el proyecto Huanta Segura.
 *
 * RESPONSABILIDADES
 *   - Definir la raíz del proyecto y el directorio de salida del build.
 *   - Exponer el servidor de desarrollo en la red local (útil para pruebas
 *     en dispositivos móviles dentro de la misma red).
 *   - Establecer rutas absolutas desde /src para imports limpios.
 *
 * DEPENDENCIAS
 *   - vite (paquete instalado en package.json).
 *
 * USADO POR
 *   - Scripts de npm: `dev`, `build`, `preview`.
 *
 * EXPORTA
 *   - Configuración por defecto consumida por Vite.
 *
 * EVENTOS
 *   - Ninguno.
 */

import { defineConfig } from "vite";
import { fileURLToPath, URL } from "node:url";

export default defineConfig({
    root: ".",
    publicDir: "public",
    base: "./",

    resolve: {
        alias: {
            "@": fileURLToPath(new URL("./src", import.meta.url)),
            "@core": fileURLToPath(new URL("./src/core", import.meta.url)),
            "@ui": fileURLToPath(new URL("./src/ui", import.meta.url)),
            "@sections": fileURLToPath(new URL("./src/sections", import.meta.url)),
            "@data": fileURLToPath(new URL("./src/data", import.meta.url)),
            "@styles": fileURLToPath(new URL("./src/styles", import.meta.url)),
        },
    },

    server: {
        host: true,
        port: 5173,
        open: true,
    },

    build: {
        outDir: "dist",
        emptyOutDir: true,
        sourcemap: true,
        target: "es2022",
        rollupOptions: {
            output: {
                manualChunks: {
                    chart: ["chart.js"],
                    xlsx: ["xlsx"],
                },
            },
        },
    },

    preview: {
        port: 4173,
        open: true,
    },
});